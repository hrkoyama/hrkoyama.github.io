import csv
import json
from pathlib import Path
import numpy as np
import pytest
from geometry import build,equilibrium,moments,C,W,OPP,circle_fraction
from native import Native,NativeFailure
from reference_step import step
from diagnostics import physical
from evolution import trajectory
from experiments import numeric_csv

@pytest.fixture(scope='session')
def native():
    instance=Native()
    try:yield instance
    finally:instance.close()

def initial(g):
    q=np.arange(g['n']);return equilibrium(1+.001*np.sin(.31*q),np.array([.002*np.cos(.17*q),.001*np.sin(.19*q)]))

def test_equilibrium_density():
    rho=np.array([.98,1.,1.02]);u=np.array([[.01,.02,-.01],[.02,0.,-.03]])
    np.testing.assert_allclose(equilibrium(rho,u).sum(axis=0),rho,rtol=0,atol=3e-16)

def test_equilibrium_momentum():
    rho=np.array([.98,1.,1.02]);u=np.array([[.01,.02,-.01],[.02,0.,-.03]])
    np.testing.assert_allclose(np.einsum('qd,qn->dn',C,equilibrium(rho,u)),rho*u,rtol=0,atol=6e-17)

def test_equilibrium_second_tensor_moment():
    rho=np.array([1.,1.02]);u=np.array([[.02,-.01],[-.01,.03]]);f=equilibrium(rho,u)
    actual=np.einsum('qa,qb,qn->abn',C,C,f)
    expected=np.einsum('an,bn,n->abn',u,u,rho)+np.eye(2)[:,:,None]*rho/3
    np.testing.assert_allclose(actual,expected,rtol=0,atol=2e-16)

def test_cavity_rest_state(native):
    g=build('cavity',6,1/6,.01,lid=0);f=equilibrium(np.ones(g['n']),np.zeros((2,g['n'])));old=f.copy()
    native.advance(f,g,.8,1);np.testing.assert_allclose(f,old,rtol=0,atol=3e-16)

def test_periodic_native_scalar_one_step(native):
    g=build('periodic',5,2*np.pi/5,.01);f=initial(g);expected=step(f,g,.8)
    native.advance(f,g,.8,1);np.testing.assert_allclose(f,expected,rtol=0,atol=3e-15)

def test_wall_native_scalar_one_step(native):
    g=build('cavity',5,.2,.01);f=initial(g);expected=step(f,g,.8)
    native.advance(f,g,.8,1);np.testing.assert_allclose(f,expected,rtol=0,atol=3e-15)

def test_curved_native_scalar_one_step(native):
    g=build('annulus',20,.05,.01);f=initial(g);expected=step(f,g,.8)
    native.advance(f,g,.8,1);np.testing.assert_allclose(f,expected,rtol=0,atol=3e-15)

def ledger(f):return np.r_[np.sum(f),np.sum(np.einsum('qd,qn->dn',C,f),axis=1)]

def test_closed_wall_mass_and_momentum_ledger(native):
    g=build('cavity',6,1/6,.01);f=initial(g);before=ledger(f);h=native.advance(f,g,.8,1)
    np.testing.assert_allclose(ledger(f)-before,h[0,3:6],rtol=0,atol=2e-13)

def test_open_boundary_mass_and_momentum_ledger(native):
    g=build('cylinder',0,.01,.001);f=initial(g);before=ledger(f);h=native.advance(f,g,.8,1)
    np.testing.assert_allclose((ledger(f)-before-h[0,3:6])/g['n'],0,rtol=0,atol=3e-14)

def test_rightward_lid_impulse_sign(native):
    g=build('cavity',6,1/6,.01,lid=.02);f=equilibrium(np.ones(g['n']),np.zeros((2,g['n'])))
    h=native.advance(f,g,.8,1);assert h[0,4]>0 and abs(h[0,3])<2e-15

def test_negative_density_failure_retains_candidate(native):
    g=build('cavity',5,.2,.01);f=initial(g);f[:,2]=-1
    with pytest.raises(NativeFailure) as error:native.advance(f,g,.8,1)
    np.testing.assert_array_equal(error.value.payload['f'],f)

def test_invalid_relaxation_is_rejected(native):
    g=build('cavity',5,.2,.01);f=initial(g)
    for tau in [.5,float('nan')]:
        with pytest.raises(ValueError):native.advance(f,g,tau,1)

def test_half_link_reduces_to_stationary_reversal(native):
    g=build('cavity',5,.2,.01,lid=0.);f=initial(g);rho,u=moments(f)
    post=f-(f-equilibrium(rho,u))/.8;native.advance(f,g,.8,1)
    for q in range(9):
        mask=g['kind'][q]>0;np.testing.assert_allclose(f[q,mask],post[OPP[q],mask],rtol=0,atol=3e-15)

def test_circle_fraction_known_intersections():
    assert circle_fraction([1.1,0],[-.4,0],np.zeros(2),1.)==pytest.approx(.25,abs=2e-15)
    assert circle_fraction([.6,0],[.8,0],np.zeros(2),1.)==pytest.approx(.5,abs=2e-15)

def test_simultaneous_corner_is_stationary_side_owned():
    g=build('cavity',5,.2,.01,lid=.02);j=int(np.flatnonzero((g['ix']==0)&(g['iy']==4))[0])
    assert g['wall_dot'][8,j]==0 and g['wall_dot'][7,j]==.02

def test_physical_pressure_units_and_gauge():
    g=build('periodic',4,.25,.05)
    # Use a nonconstant prescribed density independent of periodic trig aliases.
    p=np.linspace(-.003,.003,g['n']);f=equilibrium(1+3*(g['dt']/g['dx'])**2*p,np.zeros((2,g['n'])))
    _,u,actual=physical(f,g);np.testing.assert_allclose(actual,p-p.mean(),rtol=0,atol=8e-14)

def test_noninteger_or_mismatched_checkpoint_is_rejected(native,tmp_path):
    g=build('cavity',5,.2,.01);f=initial(g)
    with pytest.raises(ValueError):trajectory(native,g,.8,8,[4,7],f,tmp_path,'bad')
    with pytest.raises(ValueError):trajectory(native,g,.8,8,[4.,8],f,tmp_path,'bad')

def test_numeric_csv_rejects_nonfinite_and_ragged_rows(tmp_path):
    with pytest.raises(ArithmeticError):numeric_csv(tmp_path/'nan.csv',[{'x':float('nan')}])
    with pytest.raises(ArithmeticError):numeric_csv(tmp_path/'ragged.csv',[{'x':1.},{'y':2.}])

from analytic import annulus,qualify_annulus

def test_annulus_independent_cartesian_and_radial_NS_qualification():
    assert all(v<=2e-12 for v in qualify_annulus().values())

def test_annulus_inner_resisting_torque_by_traction_integral():
    radius=.2;a=annulus(np.array([.7]),np.array([.5]));A,B=a['A'],a['B']
    shear=.01*((A-B/radius**2)-(A*radius+B/radius)/radius)
    torque=2*np.pi*radius**2*shear
    assert torque<0 and abs(torque-a['torque'])<1e-17

def test_original_cylinder_ranges_not_later_web_precision():
    r=json.loads((Path(__file__).parent/'references/cylinder-original-intervals.json').read_text())
    assert r['original_outlet_user_selected'] and r['CD']==[5.57,5.59]
    assert r['CL']==[.0104,.0110] and r['pressure_difference']==[.1172,.1176]

def test_open_ZouHe_density_velocity_moments(native):
    g=build('cylinder',0,.01,.001);f=initial(g);old=f.copy();native.advance(f,g,.8,1);rho,u=moments(f);rr,uu=moments(old)
    np.testing.assert_allclose(u[0,g['inlet']],g['inlet_speed'],rtol=0,atol=3e-15)
    np.testing.assert_allclose(rho[g['outlet']],1.,rtol=0,atol=3e-15)
    np.testing.assert_allclose(u[1,g['outlet']],uu[1,g['source'][1,g['outlet']]],rtol=0,atol=3e-15)


# R3 additive curved-boundary regression; all original22testbodies above retained.
def quadratic_channel(q):
    g=build('couette',5,.2,.01,interpolation_order=2)
    wall=g['kind']>0;g['kind'][wall]=2;g['fraction'][wall]=q
    return g

def test_quadratic_curved_generic_Lagrange_oracle(native):
    for q in [1e-6,.25,.5-1e-8,.5,.5+1e-8,.75,1.]:
        g=quadratic_channel(q);f=initial(g);expected=step(f,g,.8)
        native.advance(f,g,.8,1);np.testing.assert_allclose(f,expected,rtol=0,atol=4e-15)

def test_quadratic_uniform_moving_wall_equilibrium(native):
    for q in [.25,.5,.75]:
        g=quadratic_channel(q);wall=g['kind']>0;u=np.array([.02,0.])
        for i,ci in enumerate(C):g['wall_dot'][i,wall[i]]=float(np.sum(-ci*u))
        f=equilibrium(np.ones(g['n']),np.tile(u[:,None],(1,g['n'])));old=f.copy()
        h=native.advance(f,g,.8,1)
        np.testing.assert_allclose(f,old,rtol=0,atol=4e-16)
        np.testing.assert_allclose(ledger(f)-ledger(old),h[0,3:6],rtol=0,atol=3e-14)

def test_all_nine_NEE_scalar_oracle_and_complete_open_ledger(native):
    g=build('cylinder',0,.01,.001,interpolation_order=2,outlet_mode='nee')
    f=initial(g);old=f.copy();expected=step(f,g,.8);h=native.advance(f,g,.8,1)
    np.testing.assert_allclose(f,expected,rtol=0,atol=4e-15)
    np.testing.assert_allclose((ledger(f)-ledger(old)-h[0,3:6])/g['n'],0,rtol=0,atol=3e-14)
    legacy=build('cylinder',0,.01,.001,interpolation_order=2);before=old.copy();native.advance(before,legacy,.8,1)
    known=np.array([0,1,2,4,5,8]);b=g['outlet'];delta=f[known[:,None],b]-before[known[:,None],b]
    assert np.max(abs(delta))>1e-8 # Replacing only the unknown3 is a different BC.

def test_all_nine_NEE_density_velocity_and_corner_ownership(native):
    g=build('cylinder',0,.01,.001,interpolation_order=2,outlet_mode='nee');f=initial(g);native.advance(f,g,.8,1)
    rho,u=moments(f);b=g['outlet'];a=g['source'][1,b]
    np.testing.assert_allclose(rho[b],1.,rtol=0,atol=4e-15)
    np.testing.assert_allclose(u[:,b],u[:,a],rtol=0,atol=4e-15)
    assert np.all(g['ix'][b]-g['ix'][a]==1) and np.all(g['iy'][b]==g['iy'][a])
    assert g['iy'][b[0]]==0 and g['iy'][b[-1]]==40

def test_quadratic_missing_second_neighbor_rejects_with_state(native):
    g=quadratic_channel(.25);j=int(np.flatnonzero(g['kind'].ravel()>0)[0]);g['back2'].ravel()[j]=-1
    f=initial(g)
    with pytest.raises(NativeFailure) as error:native.advance(f,g,.8,1)
    np.testing.assert_array_equal(error.value.payload['f'],f)

def test_quadratic_halfway_reduction_and_branch_continuity(native):
    g=quadratic_channel(.5);f=initial(g);a=f.copy();native.advance(a,g,.8,1)
    g['interpolation_order']=1;b=f.copy();native.advance(b,g,.8,1)
    np.testing.assert_allclose(a,b,rtol=0,atol=3e-15)
    near=[]
    for q in [.5-1e-10,.5+1e-10]:
        g=quadratic_channel(q);a=initial(g);native.advance(a,g,.8,1);near.append(a)
    np.testing.assert_allclose(near[0],near[1],rtol=0,atol=1e-10)
