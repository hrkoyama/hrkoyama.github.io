# RKDG AIエージェント実測結果

公開キットr2を別途取得しSHAを確認してください。この資料は保存データの再判定用です。元48ケースを新規再計算する操作ではありません。

```sh
# From this extracted result folder, with NumPy2.0.2 installed:
# sha256sum -c SHA256SUMS.txt   # macOS: shasum -a 256 -c SHA256SUMS.txt
python verify_saved.py --trial assembly --base /path/to/atlas-rkdg-agent-kit --output /path/to/new-audit
python verify_saved.py --trial repair --base /path/to/atlas-rkdg-agent-kit --output /path/to/new-audit
```

出力先は未使用フォルダにします。元48判定・波形4・49配列の240指標・負例の証拠・base295項目のSHAを確認します。実装コードはMIT。費用・課金トークン・詳細モデルIDは取得不可で、0円ではありません。各課題1試行、共有ホストで並行した報告時間です。元48は49本のPDE出力（時間参照1本を含む）、波形4は保存波形の診断です。既知の反転追加試験の5/6結果は今回の合格範囲外です。
