# Measured RKDG agent pilot

Download and SHA-verify base kit r2 separately. These commands reassess saved arrays; they do not rerun the full PDE campaign.

```sh
# From this extracted result folder, with NumPy2.0.2 installed:
# sha256sum -c SHA256SUMS.txt   # macOS: shasum -a 256 -c SHA256SUMS.txt
python verify_saved.py --trial assembly --base /path/to/atlas-rkdg-agent-kit --output /path/to/new-audit
python verify_saved.py --trial repair --base /path/to/atlas-rkdg-agent-kit --output /path/to/new-audit
```

Use unused output paths. Checks cover original48, waveform4, 240 metrics reconstructed from49 arrays, negative-control evidence and all295 base-file hashes. Code is MIT. Monetary cost, billable tokens and precise model ID are unavailable, not zero. One trial per task, overlapping on a shared host. The original48 rows use49 PDE outputs including a temporal reference. Four waveform diagnostics reuse stored arrays. The historical reflection5/6 result is outside this qualification.
