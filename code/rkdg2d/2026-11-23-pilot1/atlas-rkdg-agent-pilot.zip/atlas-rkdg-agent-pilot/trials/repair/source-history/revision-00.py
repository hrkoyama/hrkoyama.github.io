"""Unsplit Cartesian Euler RKDG with tensor Legendre Q1/Q2/Q3 elements.

This deliberately small implementation uses overintegrated weak volume terms,
HLL face fluxes, SSPRK(5,4), a characteristic TVB troubled-cell limiter and the
cell-average-preserving density/pressure scaling of Zhang & Shu (2010).
``degree=p`` means Qp (``(p+1)**2`` modes per conserved variable), not total-
degree Pp.  Shock limiting reduces troubled cells to limited linear polynomials;
the smooth-solution order claim consequently does not apply across shocks.

References: Cockburn & Shu, JCP 141 (1998), 199--224,
doi:10.1006/jcph.1998.5892; Zhang & Shu, JCP 229 (2010), 8918--8934,
doi:10.1016/j.jcp.2010.08.016; Spiteri & Ruuth, SINUM 40 (2002), 469--491,
doi:10.1137/S0036142901389025.
"""
from dataclasses import dataclass
import numpy as np
from numpy.polynomial.legendre import leggauss, legvander, legder, legval


GAMMA = 1.4


def conserved(rho, u=None, v=None, pressure=None, gamma=GAMMA):
    """Primitive components (or an array ending in [rho,u,v,p]) -> Euler U."""
    if u is None:
        rho, u, v, pressure = np.moveaxis(np.asarray(rho, dtype=float), -1, 0)
    rho, u, v, pressure = np.broadcast_arrays(rho, u, v, pressure)
    return np.stack((rho, rho*u, rho*v,
                     pressure/(gamma-1)+.5*rho*(u*u+v*v)), axis=-1)


def pressure(q, gamma=GAMMA):
    q = np.asarray(q)
    with np.errstate(divide='ignore', invalid='ignore'):
        return (gamma-1)*(q[..., 3]-.5*(q[..., 1]**2+q[..., 2]**2)/q[..., 0])


def primitive(q, gamma=GAMMA):
    q = np.asarray(q)
    p = pressure(q, gamma)
    if not np.all(np.isfinite(q)) or np.any(q[..., 0] <= 0) or np.any(p <= 0):
        raise ValueError('Nonphysical Euler state: density/pressure must be positive')
    return np.stack((q[..., 0], q[..., 1]/q[..., 0], q[..., 2]/q[..., 0], p), -1)


def entropy_wave(x, y, t=0., velocity=(1., .5), amplitude=.2, gamma=GAMMA):
    """Periodic unit-square exact Euler entropy wave with genuinely oblique phase."""
    u, v = velocity
    rho = 1+amplitude*np.sin(2*np.pi*((x-u*t)+(y-v*t)))
    return conserved(rho, u, v, 1., gamma)


def sod(x, y, axis=0, location=.5, gamma=GAMMA):
    s = np.asarray(x if axis == 0 else y)
    rho = np.where(s < location, 1., .125)
    p = np.where(s < location, 1., .1)
    return conserved(rho, 0., 0., p, gamma)


def shu_osher(x, y, axis=0, location=-4., gamma=GAMMA):
    s = np.asarray(x if axis == 0 else y)
    left = s < location
    rho = np.where(left, 3.857143, 1+.2*np.sin(5*s))
    normal = np.where(left, 2.629369, 0.)
    p = np.where(left, 10.33333, 1.)
    return conserved(rho, normal if axis == 0 else 0.,
                     normal if axis == 1 else 0., p, gamma)


def double_mach(x, y, t=0., gamma=GAMMA):
    """Woodward--Colella Mach-10 shock, [0,4] x [0,1], gamma=1.4."""
    if gamma != 1.4:
        raise ValueError('The fixed Double Mach benchmark requires gamma=1.4')
    hot = conserved(8., 8.25*np.sqrt(3)/2, -4.125, 116.5, gamma)
    cold = conserved(1.4, 0., 0., 1., gamma)
    behind = x < 1/6+(y+20*t)/np.sqrt(3)
    return np.where(behind[..., None], hot, cold)


@dataclass
class DGResult:
    coeff: np.ndarray
    time: float
    steps: int
    diagnostics: dict

    @property
    def q(self):
        """Conserved cell averages, with shape (nx,ny,4)."""
        return self.coeff[:, :, 0, 0, :]


class DG2D:
    """Modal tensor Qp Euler DG on a uniform Cartesian mesh.

    ``boundary`` is periodic, outflow or double-mach.  ``limiter='none'``
    disables the shock limiter, not physical-state checking/scaling.  The TVB
    rule acts on local Euler waves normalized to density units; its parameter
    has units of density per length squared and is scaled with h**2.
    All limiting preserves the four cell averages; negative averages cause
    time-step rejection, never a density/energy floor.
    """
    def __init__(self, nx, ny, degree, bounds=(0., 1., 0., 1.),
                 boundary='periodic', limiter='none', gamma=GAMMA,
                 tvb=100., quadrature=None):
        if (not isinstance(nx, (int, np.integer)) or isinstance(nx, bool) or nx < 1
                or not isinstance(ny, (int, np.integer)) or isinstance(ny, bool) or ny < 1
                or not isinstance(degree, (int, np.integer)) or isinstance(degree, bool)
                or degree not in (1, 2, 3)):
            raise ValueError('Require integer nx,ny>=1 and degree=1,2,3')
        if boundary not in ('periodic', 'outflow', 'double-mach'):
            raise ValueError('Unknown boundary condition')
        if limiter not in ('none', 'tvb'):
            raise ValueError('Unknown limiter')
        bounds = np.asarray(bounds, float)
        if bounds.shape != (4,) or not np.all(np.isfinite(bounds)) or bounds[1] <= bounds[0] or bounds[3] <= bounds[2]:
            raise ValueError('Require finite increasing rectangular bounds')
        if not np.isfinite(gamma) or gamma <= 1 or not np.isfinite(tvb) or tvb < 0:
            raise ValueError('Require gamma>1 and TVB>=0')
        if boundary == 'double-mach' and (gamma != 1.4 or not np.array_equal(bounds, [0., 4., 0., 1.])):
            raise ValueError('Double Mach requires [0,4]x[0,1] and gamma=1.4')
        self.nx, self.ny, self.degree = int(nx), int(ny), int(degree)
        self.bounds, self.boundary, self.limiter = tuple(bounds), boundary, limiter
        self.gamma, self.tvb = float(gamma), float(tvb)
        self.dx, self.dy = (bounds[1]-bounds[0])/nx, (bounds[3]-bounds[2])/ny
        self.x = bounds[0]+(np.arange(nx)+.5)*self.dx
        self.y = bounds[2]+(np.arange(ny)+.5)*self.dy
        nq = degree+2 if quadrature is None else quadrature
        if not isinstance(nq, (int, np.integer)) or nq < degree+2:
            raise ValueError('Use at least p+2 Gauss points per dimension')
        self.z, self.weights = leggauss(nq)
        self.basis = legvander(self.z, degree)
        self.derivatives = np.stack([legval(self.z, legder(np.eye(degree+1)[m]))
                                     for m in range(degree+1)], axis=1)
        self.wb = self.weights[:, None]*self.basis
        self.wd = self.weights[:, None]*self.derivatives
        self.signs = (-1.)**np.arange(degree+1)
        self._line_check_matrix = np.vstack((self.basis, self.signs,
                                            np.ones(degree+1)))
        scales = 2*np.arange(degree+1)+1
        self.scales = scales[:, None]*scales[None, :]
        self._shape = (nx, ny, degree+1, degree+1, 4)
        modes = (degree+1)**2
        self._sample_matrix = np.einsum('am,bn->abmn', self.basis, self.basis).reshape(-1, modes)
        ones = np.ones(degree+1)
        self._face_matrices = (
            np.einsum('m,an->amn', self.signs, self.basis).reshape(-1, modes),
            np.einsum('m,an->amn', ones, self.basis).reshape(-1, modes),
            np.einsum('am,n->amn', self.basis, self.signs).reshape(-1, modes),
            np.einsum('am,n->amn', self.basis, ones).reshape(-1, modes))
        corner_basis = legvander([-1., 1.], degree)
        corners = np.einsum('am,bn->abmn', corner_basis, corner_basis).reshape(-1, modes)
        self._check_matrix = np.concatenate((self._sample_matrix, *self._face_matrices, corners))
        self._volume_x = np.einsum('am,bn->mnab', self.wd, self.wb).reshape(modes, -1)
        self._volume_y = np.einsum('am,bn->mnab', self.wb, self.wd).reshape(modes, -1)
        self._stats = None

    def coordinates(self, z=None):
        z = self.z if z is None else np.atleast_1d(z)
        x = self.x[:, None, None, None]+.5*self.dx*z[None, None, :, None]
        y = self.y[None, :, None, None]+.5*self.dy*z[None, None, None, :]
        return np.broadcast_arrays(x, y)

    def project(self, initial):
        x, y = self.coordinates()
        q = np.asarray(initial(x, y), dtype=float)
        q = np.broadcast_to(q, x.shape+(4,))
        primitive(q, self.gamma)
        if self.boundary in ('periodic', 'outflow'):
            # Equality is exact: resolve a sampled invariant subspace without
            # deleting any represented finite transverse perturbation.
            if np.all(q == q[:, :1, :, :1, :]):
                return self._project_1d(q[:, 0, :, 0, :], 0)
            if np.all(q == q[:1, :, :1, :, :]):
                return self._project_1d(q[0, :, 0, :, :][..., [0, 2, 1, 3]], 1)
        c = .25*np.einsum('am,bn,ijabk->ijmnk', self.wb, self.wb, q,
                          optimize=True)*self.scales[None, None, :, :, None]
        return np.array(c, copy=True)

    def cell_average(self, coeff):
        return np.asarray(coeff)[:, :, 0, 0, :]

    def sample(self, coeff, z=None):
        if z is None:
            matrix, nq = self._sample_matrix, len(self.z)
        else:
            b = legvander(np.atleast_1d(z), self.degree)
            matrix = np.einsum('am,bn->abmn', b, b).reshape(-1, (self.degree+1)**2)
            nq = len(b)
        return self._contract(coeff, matrix).reshape(self.nx, self.ny, nq, nq, 4)

    def _contract(self, values, matrix):
        flat = np.asarray(values).reshape(self.nx, self.ny, -1, 4)
        # A single dense contraction amortizes path planning and Python calls;
        # matrices are prepared once for this p/quadrature pair.
        return np.einsum('ab,ijbk->ijak', matrix, flat, optimize=True)

    def _project_1d(self, samples, axis):
        """Project exact sampled 1D data in normal/tangential component order."""
        scales = 2*np.arange(self.degree+1)+1
        line = .5*np.einsum('am,iak->imk', self.wb, samples,
                            optimize=True)*scales[None, :, None]
        # Legendre moments of a cellwise constant are known analytically;
        # quadrature roundoff must not seed nonexistent polynomial modes.
        constant = np.all(samples == samples[:, :1, :], axis=(1, 2))
        line[constant] = 0.
        line[constant, 0, :] = samples[constant, 0, :]
        return self._embed_1d(line, axis)

    def _embedded_1d(self, coeff):
        """Return exact invariant data only; no tolerance or amplitude filter."""
        if self.boundary not in ('periodic', 'outflow'):
            return None
        c = np.asarray(coeff)
        if c.shape != self._shape:
            return None
        if not np.any(c[:, :, :, 1:, :]) and np.all(c == c[:, :1, :, :, :]):
            return 0, c[:, 0, :, 0, :].copy()
        if not np.any(c[:, :, 1:, :, :]) and np.all(c == c[:1, :, :, :, :]):
            return 1, c[0, :, 0, :, :][..., [0, 2, 1, 3]].copy()
        return None

    def _embed_1d(self, line, axis):
        c = np.zeros(self._shape, dtype=float)
        if axis == 0:
            c[:, :, :, 0, :] = line[:, None, :, :]
        else:
            c[:, :, 0, :, :] = line[None, :, :, :][..., [0, 2, 1, 3]]
        return c

    def _operator_1d(self, line, axis):
        """The same weak DG/HLL operator restricted to its exact 1D subspace."""
        q = np.einsum('am,imk->iak', self.basis, line, optimize=True)
        flux = self._flux(q, 0)[0]
        left = np.einsum('m,imk->ik', self.signs, line)
        right = line.sum(axis=1)
        ql = np.concatenate((right[-1:], right))
        qr = np.concatenate((left, left[:1]))
        if self.boundary == 'outflow':
            ql[0], qr[-1] = left[0], right[-1]
        face = self._hll(ql, qr, 0)
        h = self.dx if axis == 0 else self.dy
        span = self.bounds[3]-self.bounds[2] if axis == 0 else self.bounds[1]-self.bounds[0]
        # Subtract a cellwise reference flux and use integral P_m' =
        # 1-(-1)^m analytically.  This is algebraically the weak operator,
        # with exact free-stream cancellation instead of quadrature residue.
        reference = self._flux(line[:, 0, :], 0)[0]
        volume = np.einsum('am,iak->imk', self.wd,
                           flux-reference[:, None, :], optimize=True)
        residual = (volume-(face[1:]-reference)[:, None, :]
                    +self.signs[None, :, None]*(face[:-1]-reference)[:, None, :])
        rate = residual*((2*np.arange(self.degree+1)+1)/h)[None, :, None]
        # Preserve the telescoping cell-average balance directly.
        rate[:, 0, :] = (face[:-1]-face[1:])/h
        outward = span*(face[-1]-face[0])
        if axis == 1:
            outward = outward[[0, 2, 1, 3]]
        return self._embed_1d(rate, axis), outward

    def _stabilize_1d(self, line, axis):
        """Characteristic TVB/physical limiting in the exact 1D subspace."""
        c = np.array(line, dtype=float, copy=True)
        avg = c[:, 0, :].copy()
        pavg = self._pressure(avg)
        if np.any(avg[:, 0] <= 1e-13) or np.any(pavg <= 1e-13):
            raise ValueError('Nonphysical cell average: reject step, do not floor')
        limited = 0
        if self.limiter == 'tvb':
            minus, plus = np.roll(avg, 1, 0), np.roll(avg, -1, 0)
            if self.boundary == 'outflow':
                minus[0], plus[-1] = avg[0], avg[-1]
            da, db = avg-minus, plus-avg
            h = self.dx if axis == 0 else self.dy
            threshold = self.tvb*h**2
            dr = c.sum(axis=1)-avg
            dl = avg-np.einsum('m,imk->ik', self.signs, c)
            dr, dl, da, db = (self._to_characteristic(d, avg)
                              for d in (dr, dl, da, db))
            eps = 1e-12*np.maximum(1., abs(avg[:, 0]))[:, None]
            troubled = np.any((abs(dr-self._minmod(dr, da, db, threshold)) > eps)
                              | (abs(dl-self._minmod(dl, da, db, threshold)) > eps), axis=-1)
            limited = int(troubled.sum())
            if limited:
                slope = self._from_characteristic(
                    self._minmod(self._to_characteristic(c[:, 1, :], avg), da, db), avg)
                c[troubled] = 0.
                c[troubled, 0, :] = avg[troubled]
                c[troubled, 1, :] = slope[troubled]
        q = np.einsum('am,imk->iak', self._line_check_matrix, c, optimize=True)
        minrho = q[..., 0].min(axis=1)
        epsrho = np.minimum(1e-12, .1*avg[:, 0])
        theta = np.minimum(1., (avg[:, 0]-epsrho)/np.maximum(avg[:, 0]-minrho, 1e-300))
        density_bad = minrho < epsrho
        theta = np.where(density_bad, np.maximum(0., theta)*(1-1e-14), 1.)
        c *= theta[:, None, None]
        c[:, 0, :] = avg
        if np.any(density_bad):
            q = np.einsum('am,imk->iak', self._line_check_matrix, c, optimize=True)
        epsp = np.minimum(1e-12, .1*pavg)
        bad = np.any(self._pressure(q) < epsp[:, None], axis=1)
        if np.any(bad):
            qa = avg[bad][:, None, :]
            dq = q[bad]-qa
            lo, hi = np.zeros(int(bad.sum())), np.ones(int(bad.sum()))
            target = epsp[bad]
            for _ in range(32):
                mid = .5*(lo+hi)
                physical = np.all(self._pressure(qa+mid[:, None, None]*dq) >= target[:, None], axis=1)
                lo = np.where(physical, mid, lo)
                hi = np.where(physical, hi, mid)
            c[bad] *= (lo*(1-1e-14))[:, None, None]
            c[:, 0, :] = avg
            q = np.einsum('am,imk->iak', self._line_check_matrix, c, optimize=True)
        primitive(q, self.gamma)
        if self._stats is not None:
            st = self._stats
            repeats = self.ny if axis == 0 else self.nx
            st['limited_cell_stages'] += repeats*limited
            st['positivity_scaled_cell_stages'] += repeats*int(np.count_nonzero(density_bad | bad))
            st['minimum_density'] = min(st['minimum_density'], float(q[..., 0].min()))
            st['minimum_pressure'] = min(st['minimum_pressure'], float(self._pressure(q).min()))
            st['minimum_cell_average_density'] = min(st['minimum_cell_average_density'], float(avg[:, 0].min()))
            st['minimum_cell_average_pressure'] = min(st['minimum_cell_average_pressure'], float(pavg.min()))
        return self._embed_1d(c, axis)

    def _traces(self, c):
        # First tangential face coordinate follows y for x-normal faces.
        return tuple(self._contract(c, matrix) for matrix in self._face_matrices)

    def _checkpoints(self, c):
        return self._contract(c, self._check_matrix)

    def _pressure(self, q):
        return pressure(q, self.gamma)

    def _flux(self, q, axis):
        rho = q[..., 0]
        p = self._pressure(q)
        if not np.all(np.isfinite(q)) or np.any(rho <= 0) or np.any(p <= 0):
            raise ValueError('Nonphysical flux quadrature state')
        un = q[..., 1+axis]/rho
        f = q*un[..., None]
        f[..., 1+axis] += p
        f[..., 3] = (q[..., 3]+p)*un
        return f, un, np.sqrt(self.gamma*p/rho)

    def _hll(self, ql, qr, axis):
        fl, ul, cl = self._flux(ql, axis)
        fr, ur, cr = self._flux(qr, axis)
        sl = np.minimum(np.minimum(ul-cl, ur-cr), 0.)
        sr = np.maximum(np.maximum(ul+cl, ur+cr), 0.)
        flux = (sr[..., None]*fl-sl[..., None]*fr+
                (sl*sr)[..., None]*(qr-ql))/(sr-sl)[..., None]
        # Enforce the exact consistency identity F_HLL(U,U)=F(U),
        # avoiding a roundoff seed even for a constant physical state.
        return np.where(np.all(ql == qr, axis=-1)[..., None], fl, flux)

    def _boundary_traces(self, c, time):
        l, r, b, t = self._traces(c)
        xl = np.concatenate((r[-1:], r), axis=0)
        xr = np.concatenate((l, l[:1]), axis=0)
        yl = np.concatenate((t[:, -1:], t), axis=1)
        yr = np.concatenate((b, b[:, :1]), axis=1)
        if self.boundary != 'periodic':
            xl[0], xr[-1] = l[0], r[-1]
            yl[:, 0], yr[:, -1] = b[:, 0], t[:, -1]
        if self.boundary == 'double-mach':
            hot = conserved(8., 8.25*np.sqrt(3)/2, -4.125, 116.5)
            xl[0] = hot
            xface = self.x[:, None]+.5*self.dx*self.z
            yl[:, 0, :, 2] *= -1
            yl[:, 0] = np.where((xface < 1/6)[..., None], hot, yl[:, 0])
            yr[:, -1] = double_mach(xface, np.ones_like(xface), time)
        return xl, xr, yl, yr

    def _operator(self, c, time):
        embedded = self._embedded_1d(c)
        if embedded is not None:
            axis, line = embedded
            return self._operator_1d(line, axis)
        v = self.sample(c)
        fx = self._flux(v, 0)[0]
        fy = self._flux(v, 1)[0]
        xl, xr, yl, yr = self._boundary_traces(c, time)
        xf, yf = self._hll(xl, xr, 0), self._hll(yl, yr, 1)
        vx = self._contract(fx, self._volume_x).reshape(c.shape)
        vy = self._contract(fy, self._volume_y).reshape(c.shape)
        sr = np.einsum('an,ijak->ijnk', self.wb, xf[1:], optimize=True)
        sl = np.einsum('an,ijak->ijnk', self.wb, xf[:-1], optimize=True)
        st = np.einsum('am,ijak->ijmk', self.wb, yf[:, 1:], optimize=True)
        sb = np.einsum('am,ijak->ijmk', self.wb, yf[:, :-1], optimize=True)
        rx = vx-sr[:, :, None, :, :]+self.signs[None, None, :, None, None]*sl[:, :, None, :, :]
        ry = vy-st[:, :, :, None, :]+self.signs[None, None, None, :, None]*sb[:, :, :, None, :]
        derivative = (.5*rx/self.dx+.5*ry/self.dy)*self.scales[None, None, :, :, None]
        boundary = (.5*self.dy*np.einsum('a,jak->k', self.weights, xf[-1]-xf[0])+
                    .5*self.dx*np.einsum('a,iak->k', self.weights, yf[:, -1]-yf[:, 0]))
        return derivative, boundary

    def rhs(self, coeff, time=0.):
        """Unmodified spatial derivative; callers must provide physical traces."""
        return self._operator(np.asarray(coeff), time)[0]

    @staticmethod
    def _minmod(a, b, c, threshold=0.):
        s = np.sign(a)
        mm = s*np.minimum(np.minimum(abs(a), abs(b)), abs(c))
        mm = np.where((s == np.sign(b)) & (s == np.sign(c)), mm, 0.)
        return np.where(abs(a) <= threshold, a, mm)

    def _to_characteristic(self, delta, avg):
        """Local normal Euler wave amplitudes, all normalized to density units."""
        rho = avg[..., 0]
        u, v = avg[..., 1]/rho, avg[..., 2]/rho
        cs = np.sqrt(self.gamma*self._pressure(avg)/rho)
        drho = delta[..., 0]
        dp = (self.gamma-1)*(delta[..., 3]-u*delta[..., 1]-v*delta[..., 2]
                              +.5*(u*u+v*v)*drho)
        acoustic = dp/(cs*cs)
        velocity = (delta[..., 1]-u*drho)/cs
        return np.stack((.5*(acoustic-velocity), drho-acoustic,
                         (delta[..., 2]-v*drho)/cs,
                         .5*(acoustic+velocity)), axis=-1)

    def _from_characteristic(self, waves, avg):
        rho = avg[..., 0]
        u, v = avg[..., 1]/rho, avg[..., 2]/rho
        p = self._pressure(avg)
        cs = np.sqrt(self.gamma*p/rho)
        enthalpy = (avg[..., 3]+p)/rho
        minus, entropy, shear, plus = np.moveaxis(waves, -1, 0)
        drho = minus+entropy+plus
        return np.stack((drho, (u-cs)*minus+u*entropy+(u+cs)*plus,
                         v*drho+cs*shear,
                         (enthalpy-u*cs)*minus+.5*(u*u+v*v)*entropy
                         +v*cs*shear+(enthalpy+u*cs)*plus), axis=-1)

    def _tvb_limit(self, c, time):
        """Apply TVB limiting to local Euler waves in each normal direction."""
        avg = self.cell_average(c).copy()
        xm, xp = np.roll(avg, 1, 0), np.roll(avg, -1, 0)
        ym, yp = np.roll(avg, 1, 1), np.roll(avg, -1, 1)
        if self.boundary != 'periodic':
            xm[0], xp[-1] = avg[0], avg[-1]
            ym[:, 0], yp[:, -1] = avg[:, 0], avg[:, -1]
        if self.boundary == 'double-mach':
            hot = conserved(8., 8.25*np.sqrt(3)/2, -4.125, 116.5)
            xm[0] = hot
            ym[:, 0, 2] *= -1
            ym[:, 0] = np.where((self.x < 1/6)[:, None], hot, ym[:, 0])
            yp[:, -1] = double_mach(self.x, np.ones_like(self.x), time)
        # Average each face in its tangential direction.  The degree-zero
        # tangential Legendre coefficient is its exact polynomial face mean.
        dr = c[:, :, :, 0, :].sum(axis=2)-avg
        dl = avg-np.einsum('m,ijmk->ijk', self.signs, c[:, :, :, 0, :])
        dt = c[:, :, 0, :, :].sum(axis=2)-avg
        db = avg-np.einsum('n,ijnk->ijk', self.signs, c[:, :, 0, :, :])
        ax, bx, ay, by = avg-xm, xp-avg, avg-ym, yp-avg
        threshold_x, threshold_y = self.tvb*self.dx**2, self.tvb*self.dy**2
        permutation = [0, 2, 1, 3]
        avg_y = avg[..., permutation]
        dr, dl, ax, bx = (self._to_characteristic(d, avg) for d in (dr, dl, ax, bx))
        dt, db, ay, by = (self._to_characteristic(d[..., permutation], avg_y)
                          for d in (dt, db, ay, by))
        eps = 1e-12*np.maximum(1., abs(avg[..., 0]))[..., None]
        troubled = np.any((abs(dr-self._minmod(dr, ax, bx, threshold_x)) > eps) |
                          (abs(dl-self._minmod(dl, ax, bx, threshold_x)) > eps) |
                          (abs(dt-self._minmod(dt, ay, by, threshold_y)) > eps) |
                          (abs(db-self._minmod(db, ay, by, threshold_y)) > eps), axis=-1)
        count = int(troubled.sum())
        if count:
            sx = self._from_characteristic(
                self._minmod(self._to_characteristic(c[:, :, 1, 0, :], avg), ax, bx), avg)
            sy = self._from_characteristic(
                self._minmod(self._to_characteristic(c[:, :, 0, 1, :][..., permutation], avg_y), ay, by),
                avg_y)[..., permutation]
            c[troubled] = 0.
            c[:, :, 0, 0, :][troubled] = avg[troubled]
            c[:, :, 1, 0, :][troubled] = sx[troubled]
            c[:, :, 0, 1, :][troubled] = sy[troubled]
        return count

    def stabilize(self, coeff, time=0.):
        """Return a limited copy; preserve averages or reject nonphysical ones."""
        c = np.array(coeff, dtype=float, copy=True)
        if c.shape != self._shape or not np.all(np.isfinite(c)):
            raise ValueError('Invalid coefficient array')
        embedded = self._embedded_1d(c)
        if embedded is not None:
            axis, line = embedded
            return self._stabilize_1d(line, axis)
        avg = self.cell_average(c).copy()
        pavg = self._pressure(avg)
        if np.any(avg[..., 0] <= 1e-13) or np.any(pavg <= 1e-13):
            raise ValueError('Nonphysical cell average: reject step, do not floor')
        limited = self._tvb_limit(c, time) if self.limiter == 'tvb' else 0
        q = self._checkpoints(c)
        minrho = q[..., 0].min(axis=2)
        epsrho = np.minimum(1e-12, .1*avg[..., 0])
        theta = np.minimum(1., (avg[..., 0]-epsrho)/np.maximum(avg[..., 0]-minrho, 1e-300))
        density_bad = minrho < epsrho
        theta = np.where(density_bad, np.maximum(0., theta)*(1-1e-14), 1.)
        c *= theta[:, :, None, None, None]
        c[:, :, 0, 0, :] = avg
        if np.any(density_bad):
            q = self._checkpoints(c)
        pq = self._pressure(q)
        epsp = np.minimum(1e-12, .1*pavg)
        bad = np.any(pq < epsp[..., None], axis=2)
        if np.any(bad):
            qa = avg[bad][:, None, :]
            dq = q[bad]-qa
            lo, hi = np.zeros(int(bad.sum())), np.ones(int(bad.sum()))
            target = epsp[bad]
            for _ in range(32):
                mid = .5*(lo+hi)
                physical = np.all(self._pressure(qa+mid[:, None, None]*dq) >= target[:, None], axis=1)
                lo = np.where(physical, mid, lo)
                hi = np.where(physical, hi, mid)
            c[bad] *= (lo*(1-1e-14))[:, None, None, None]
            c[:, :, 0, 0, :] = avg
            q = self._checkpoints(c)
        primitive(q, self.gamma)
        if self._stats is not None:
            st = self._stats
            st['limited_cell_stages'] += limited
            st['positivity_scaled_cell_stages'] += int(np.count_nonzero(density_bad | bad))
            st['minimum_density'] = min(st['minimum_density'], float(q[..., 0].min()))
            st['minimum_pressure'] = min(st['minimum_pressure'], float(self._pressure(q).min()))
            st['minimum_cell_average_density'] = min(st['minimum_cell_average_density'], float(avg[..., 0].min()))
            st['minimum_cell_average_pressure'] = min(st['minimum_cell_average_pressure'], float(pavg.min()))
        return c

    def integral(self, coeff):
        return self.dx*self.dy*self.cell_average(coeff).sum(axis=(0, 1))

    def _stable_dt(self, c, cfl):
        embedded = self._embedded_1d(c)
        if embedded is not None:
            axis, line = embedded
            q = np.einsum('am,imk->iak', self._line_check_matrix, line, optimize=True)
            rho = q[..., 0]
            cs = np.sqrt(self.gamma*self._pressure(q)/rho)
            hn, ht = (self.dx, self.dy) if axis == 0 else (self.dy, self.dx)
            rate = np.max((abs(q[..., 1]/rho)+cs)/hn
                          +(abs(q[..., 2]/rho)+cs)/ht)
            return cfl/((2*self.degree+1)*rate)
        q = self._checkpoints(c)
        rho = q[..., 0]
        cs = np.sqrt(self.gamma*self._pressure(q)/rho)
        rate = np.max((abs(q[..., 1]/rho)+cs)/self.dx+
                      (abs(q[..., 2]/rho)+cs)/self.dy)
        return cfl/((2*self.degree+1)*rate)

    def _step(self, u, time, dt):
        """Advance SSPRK(5,4), limiting each stage at its actual stage time.

        The positive Shu--Osher coefficients are those of Spiteri--Ruuth.
        Affine combinations are evaluated about an existing state so their
        coefficients sum to one despite the published decimal roundoff.
        The same recurrences integrate the outward boundary flux; limiting
        preserves the cell averages and therefore adds no boundary term.
        """
        a1 = .391752226571890
        a21, b21 = .555629506348765, .368410593050371
        a32, b32 = .379898148511597, .251891774271694
        a43, b43 = .821920045606868, .544974750228521
        a53, a54 = .096059710526147, .386708617503269
        b53, b54 = .063692468666290, .216007483236906
        # Apply the affine updates to t'=1.  These abscissae are not
        # monotone: the third predictor precedes the second in time.
        c1 = a1
        c2 = a21*c1+b21
        c3 = a32*c2+b32
        c4 = a43*c3+b43

        k0, f0 = self._operator(u, time)
        u1 = self.stabilize(u+dt*a1*k0, time+c1*dt)
        k1, f1 = self._operator(u1, time+c1*dt)
        u2 = self.stabilize(u+a21*(u1-u)+dt*b21*k1, time+c2*dt)
        k2, f2 = self._operator(u2, time+c2*dt)
        u3 = self.stabilize(u+a32*(u2-u)+dt*b32*k2, time+c3*dt)
        k3, f3 = self._operator(u3, time+c3*dt)
        u4 = self.stabilize(u+a43*(u3-u)+dt*b43*k3, time+c4*dt)
        k4, f4 = self._operator(u4, time+c4*dt)
        # The u2 coefficient is 1-a53-a54, within published-coefficient
        # roundoff of .517231671970585.  The endpoint abscissa is 1.
        new = self.stabilize(u2+a53*(u3-u2)+a54*(u4-u2)
                             +dt*(b53*k3+b54*k4), time+dt)

        # gi is the accumulated outflow for predictor ui, divided by dt.
        g1 = a1*f0
        g2 = a21*g1+b21*f1
        g3 = a32*g2+b32*f2
        g4 = a43*g3+b43*f3
        outgoing = dt*(g2+a53*(g3-g2)+a54*(g4-g2)+b53*f3+b54*f4)
        return new, outgoing


    def evolve(self, coeff, final_time, cfl=.2, dt_max=None, initial_time=0.,
               max_steps=100000, callback=None):
        """Advance to an exact output time; failed stage averages halve dt.

        ``callback(time, coeff)`` runs after accepted complete steps. Diagnostics
        count all attempted limiter calls, and boundary integrals only accepted
        steps. ``dt_max`` enables independent temporal refinement.
        """
        if not np.isfinite(final_time) or not np.isfinite(initial_time) or final_time < initial_time:
            raise ValueError('Require finite final_time >= initial_time')
        if not np.isfinite(cfl) or not 0 < cfl <= .5:
            raise ValueError('Require 0<CFL<=.5')
        if dt_max is not None and (not np.isfinite(dt_max) or dt_max <= 0):
            raise ValueError('Require positive finite dt_max')
        self._stats = dict(limited_cell_stages=0, positivity_scaled_cell_stages=0,
                           rejected_steps=0, minimum_density=float('inf'),
                           minimum_pressure=float('inf'), minimum_cell_average_density=float('inf'),
                           minimum_cell_average_pressure=float('inf'), min_dt=float('inf'), max_dt=0.)
        try:
            u = self.stabilize(coeff, initial_time)
            initial = self.integral(u)
            boundary = np.zeros(4)
            time, steps = float(initial_time), 0
            while time < final_time:
                remaining = final_time-time
                # Accepted steps can leave only a roundoff-sized endpoint
                # remainder.  Preserve every meaningful step and snap the
                # reported time instead of attempting an underflowing step.
                if steps and remaining <= 4*np.finfo(float).eps*max(1., abs(final_time)):
                    time = float(final_time)
                    break
                if steps >= max_steps:
                    raise RuntimeError('Exceeded max_steps')
                dt = min(self._stable_dt(u, cfl), remaining,
                         float('inf') if dt_max is None else dt_max)
                for attempt in range(16):
                    try:
                        new, outgoing = self._step(u, time, dt)
                        break
                    except ValueError as exc:
                        if 'Nonphysical' not in str(exc):
                            raise
                        dt *= .5
                        self._stats['rejected_steps'] += 1
                else:
                    raise RuntimeError('Unable to maintain positive cell averages by dt reduction')
                if dt <= np.finfo(float).eps*max(1., abs(time)):
                    raise RuntimeError('Time step underflow')
                u = new
                boundary += outgoing
                time += dt
                steps += 1
                self._stats['min_dt'] = min(self._stats['min_dt'], dt)
                self._stats['max_dt'] = max(self._stats['max_dt'], dt)
                if callback is not None:
                    callback(time, u)
            final = self.integral(u)
            diagnostics = dict(self._stats)
            if not steps:
                diagnostics['min_dt'] = 0.
            diagnostics.update(initial_integral=initial.tolist(), final_integral=final.tolist(),
                               integrated_boundary_outflow=boundary.tolist(),
                               conservation_defect=(final-initial+boundary).tolist(),
                               basis='tensor Legendre Qp', degree=self.degree,
                               quadrature_points=len(self.z), temporal_method='SSPRK(5,4)',
                               boundary=self.boundary, limiter=self.limiter,
                               tvb_parameter=self.tvb,
                               limiter_variables=('density-normalized Euler characteristic'
                                                  if self.limiter == 'tvb' else 'none'))
            return DGResult(u, time, steps, diagnostics)
        finally:
            self._stats = None
