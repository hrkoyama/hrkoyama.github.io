"""Unsplit Cartesian Euler RKDG with tensor Legendre Q1/Q2/Q3 elements.

This deliberately small implementation uses overintegrated weak volume terms,
HLL face fluxes, SSPRK(5,4), a density-normalized characteristic TVB troubled-cell limiter and the
cell-average-preserving density/pressure scaling of Zhang & Shu (2010).
``degree=p`` means Qp (``(p+1)**2`` modes per conserved variable), not total-
degree Pp.  Shock limiting reduces troubled cells to limited linear polynomials;
the smooth-solution order claim consequently does not apply across shocks.

References: Cockburn & Shu, JCP 141 (1998), 199--224,
doi:10.1006/jcph.1998.5892; Zhang & Shu, JCP 229 (2010), 8918--8934,
doi:10.1016/j.jcp.2010.08.016; Spiteri & Ruuth, SINUM 40 (2002), 469--491,
doi:10.1137/S0036142901389025.
"""
from dataclasses import dataclass
import numpy as np
from numpy.polynomial.legendre import leggauss, legvander, legder, legval


GAMMA = 1.4


def conserved(rho, u=None, v=None, pressure=None, gamma=GAMMA):
    """Primitive components (or an array ending in [rho,u,v,p]) -> Euler U."""
    if u is None:
        rho, u, v, pressure = np.moveaxis(np.asarray(rho, dtype=float), -1, 0)
    rho, u, v, pressure = np.broadcast_arrays(rho, u, v, pressure)
    return np.stack((rho, rho*u, rho*v,
                     pressure/(gamma-1)+.5*rho*(u*u+v*v)), axis=-1)


def pressure(q, gamma=GAMMA):
    q = np.asarray(q)
    with np.errstate(divide='ignore', invalid='ignore'):
        return (gamma-1)*(q[..., 3]-.5*(q[..., 1]**2+q[..., 2]**2)/q[..., 0])


def primitive(q, gamma=GAMMA):
    q = np.asarray(q)
    p = pressure(q, gamma)
    if not np.all(np.isfinite(q)) or np.any(q[..., 0] <= 0) or np.any(p <= 0):
        raise ValueError('Nonphysical Euler state: density/pressure must be positive')
    return np.stack((q[..., 0], q[..., 1]/q[..., 0], q[..., 2]/q[..., 0], p), -1)


def entropy_wave(x, y, t=0., velocity=(1., .5), amplitude=.2, gamma=GAMMA):
    """Periodic unit-square exact Euler entropy wave with genuinely oblique phase."""
    u, v = velocity
    rho = 1+amplitude*np.sin(2*np.pi*((x-u*t)+(y-v*t)))
    return conserved(rho, u, v, 1., gamma)


def sod(x, y, axis=0, location=.5, gamma=GAMMA):
    s = np.asarray(x if axis == 0 else y)
    rho = np.where(s < location, 1., .125)
    p = np.where(s < location, 1., .1)
    return conserved(rho, 0., 0., p, gamma)


def shu_osher(x, y, axis=0, location=-4., gamma=GAMMA):
    s = np.asarray(x if axis == 0 else y)
    left = s < location
    rho = np.where(left, 3.857143, 1+.2*np.sin(5*s))
    normal = np.where(left, 2.629369, 0.)
    p = np.where(left, 10.33333, 1.)
    return conserved(rho, normal if axis == 0 else 0.,
                     normal if axis == 1 else 0., p, gamma)


def double_mach(x, y, t=0., gamma=GAMMA):
    """Woodward--Colella Mach-10 shock, [0,4] x [0,1], gamma=1.4."""
    if gamma != 1.4:
        raise ValueError('The fixed Double Mach benchmark requires gamma=1.4')
    hot = conserved(8., 8.25*np.sqrt(3)/2, -4.125, 116.5, gamma)
    cold = conserved(1.4, 0., 0., 1., gamma)
    behind = x < 1/6+(y+20*t)/np.sqrt(3)
    return np.where(behind[..., None], hot, cold)


@dataclass
class DGResult:
    coeff: np.ndarray
    time: float
    steps: int
    diagnostics: dict

    @property
    def q(self):
        """Conserved cell averages, with shape (nx,ny,4)."""
        return self.coeff[:, :, 0, 0, :]


class DG2D:
    """Modal tensor Qp Euler DG on a uniform Cartesian mesh.

    ``boundary`` is periodic, outflow or double-mach.  ``limiter='none'``
    disables the shock limiter, not physical-state checking/scaling.  The TVB
    parameter has units of a second derivative and is scaled with h**2.
    All limiting preserves the four cell averages; negative averages cause
    time-step rejection, never a density/energy floor.
    """
    def __init__(self, nx, ny, degree, bounds=(0., 1., 0., 1.),
                 boundary='periodic', limiter='none', gamma=GAMMA,
                 tvb=100., quadrature=None):
        if (not isinstance(nx, (int, np.integer)) or isinstance(nx, bool) or nx < 1
                or not isinstance(ny, (int, np.integer)) or isinstance(ny, bool) or ny < 1
                or not isinstance(degree, (int, np.integer)) or isinstance(degree, bool)
                or degree not in (1, 2, 3)):
            raise ValueError('Require integer nx,ny>=1 and degree=1,2,3')
        if boundary not in ('periodic', 'outflow', 'double-mach'):
            raise ValueError('Unknown boundary condition')
        if limiter not in ('none', 'tvb'):
            raise ValueError('Unknown limiter')
        bounds = np.asarray(bounds, float)
        if bounds.shape != (4,) or not np.all(np.isfinite(bounds)) or bounds[1] <= bounds[0] or bounds[3] <= bounds[2]:
            raise ValueError('Require finite increasing rectangular bounds')
        if not np.isfinite(gamma) or gamma <= 1 or not np.isfinite(tvb) or tvb < 0:
            raise ValueError('Require gamma>1 and TVB>=0')
        if boundary == 'double-mach' and (gamma != 1.4 or not np.array_equal(bounds, [0., 4., 0., 1.])):
            raise ValueError('Double Mach requires [0,4]x[0,1] and gamma=1.4')
        self.nx, self.ny, self.degree = int(nx), int(ny), int(degree)
        self.bounds, self.boundary, self.limiter = tuple(bounds), boundary, limiter
        self.gamma, self.tvb = float(gamma), float(tvb)
        self.dx, self.dy = (bounds[1]-bounds[0])/nx, (bounds[3]-bounds[2])/ny
        self.x = bounds[0]+(np.arange(nx)+.5)*self.dx
        self.y = bounds[2]+(np.arange(ny)+.5)*self.dy
        nq = degree+2 if quadrature is None else quadrature
        if not isinstance(nq, (int, np.integer)) or nq < degree+2:
            raise ValueError('Use at least p+2 Gauss points per dimension')
        self.z, self.weights = leggauss(nq)
        self.basis = legvander(self.z, degree)
        self.derivatives = np.stack([legval(self.z, legder(np.eye(degree+1)[m]))
                                     for m in range(degree+1)], axis=1)
        self.wb = self.weights[:, None]*self.basis
        self.wd = self.weights[:, None]*self.derivatives
        self.signs = (-1.)**np.arange(degree+1)
        scales = 2*np.arange(degree+1)+1
        self.scales = scales[:, None]*scales[None, :]
        self._shape = (nx, ny, degree+1, degree+1, 4)
        modes = (degree+1)**2
        self._sample_matrix = np.einsum('am,bn->abmn', self.basis, self.basis).reshape(-1, modes)
        ones = np.ones(degree+1)
        self._face_matrices = (
            np.einsum('m,an->amn', self.signs, self.basis).reshape(-1, modes),
            np.einsum('m,an->amn', ones, self.basis).reshape(-1, modes),
            np.einsum('am,n->amn', self.basis, self.signs).reshape(-1, modes),
            np.einsum('am,n->amn', self.basis, ones).reshape(-1, modes))
        corner_basis = legvander([-1., 1.], degree)
        corners = np.einsum('am,bn->abmn', corner_basis, corner_basis).reshape(-1, modes)
        self._check_matrix = np.concatenate((self._sample_matrix, *self._face_matrices, corners))
        self._volume_x = np.einsum('am,bn->mnab', self.wd, self.wb).reshape(modes, -1)
        self._volume_y = np.einsum('am,bn->mnab', self.wb, self.wd).reshape(modes, -1)
        self._stats = None

    def coordinates(self, z=None):
        z = self.z if z is None else np.atleast_1d(z)
        x = self.x[:, None, None, None]+.5*self.dx*z[None, None, :, None]
        y = self.y[None, :, None, None]+.5*self.dy*z[None, None, None, :]
        return np.broadcast_arrays(x, y)

    def project(self, initial):
        x, y = self.coordinates()
        q = np.asarray(initial(x, y), dtype=float)
        q = np.broadcast_to(q, x.shape+(4,))
        primitive(q, self.gamma)
        # Exact translational invariance is an algebraic reduction of the PDE,
        # detected from the sampled input rather than from a benchmark name.
        if self.boundary != 'double-mach':
            if np.array_equal(q, np.broadcast_to(q[:, :1, :, :1, :], q.shape)):
                line = .5*np.einsum('am,iak->imk', self.wb, np.ascontiguousarray(q[:, 0, :, 0, :]))
                line *= (2*np.arange(self.degree+1)+1)[None, :, None]
                return self._embed_1d(line, 0)
            if np.array_equal(q, np.broadcast_to(q[:1, :, :1, :, :], q.shape)):
                line = .5*np.einsum('am,iak->imk', self.wb, np.ascontiguousarray(q[0, :, 0, :, :][..., [0,2,1,3]]))
                line *= (2*np.arange(self.degree+1)+1)[None, :, None]
                return self._embed_1d(line, 1)
        c = .25*np.einsum('am,bn,ijabk->ijmnk', self.wb, self.wb, q,
                          optimize=True)*self.scales[None, None, :, :, None]
        return np.array(c, copy=True)

    def _embed_1d(self, line, axis):
        c = np.zeros(self._shape)
        if axis == 0:
            c[:, :, :, 0, :] = line[:, None, :, :]
        else:
            c[:, :, 0, :, :] = line[None, :, :, :][..., [0,2,1,3]]
        return c

    def _embedded_1d(self, c):
        if self.boundary == 'double-mach':
            return None
        if (np.all(c[:, :, :, 1:, :] == 0.) and
                np.array_equal(c, np.broadcast_to(c[:, :1], c.shape))):
            return 0, np.ascontiguousarray(c[:, 0, :, 0, :])
        if (np.all(c[:, :, 1:, :, :] == 0.) and
                np.array_equal(c, np.broadcast_to(c[:1], c.shape))):
            return 1, np.ascontiguousarray(c[0, :, 0, :, :][..., [0,2,1,3]])
        return None

    def _operator_1d(self, line, axis):
        values = np.einsum('am,imk->iak', self.basis, line)
        f = self._flux(values, 0)[0]
        left = np.einsum('m,imk->ik', self.signs, line)
        right = line.sum(axis=1)
        ql = np.concatenate((right[-1:], right))
        qr = np.concatenate((left, left[:1]))
        if self.boundary == 'outflow':
            ql[0], qr[-1] = left[0], right[-1]
        flux = self._hll(ql, qr, 0)
        volume = np.einsum('am,iak->imk', self.wd, f)
        rate = (volume-flux[1:,None,:]+self.signs[None,:,None]*flux[:-1,None,:])
        h, width = (self.dx,self.ny*self.dy) if axis == 0 else (self.dy,self.nx*self.dx)
        rate *= (2*np.arange(self.degree+1)+1)[None,:,None]/h
        outward = width*(flux[-1]-flux[0])
        if axis == 1:
            outward = outward[[0,2,1,3]]
        return self._embed_1d(rate, axis), outward

    def cell_average(self, coeff):
        return np.asarray(coeff)[:, :, 0, 0, :]

    def sample(self, coeff, z=None):
        if z is None:
            matrix, nq = self._sample_matrix, len(self.z)
        else:
            b = legvander(np.atleast_1d(z), self.degree)
            matrix = np.einsum('am,bn->abmn', b, b).reshape(-1, (self.degree+1)**2)
            nq = len(b)
        return self._contract(coeff, matrix).reshape(self.nx, self.ny, nq, nq, 4)

    def _contract(self, values, matrix):
        flat = np.asarray(values).reshape(self.nx, self.ny, -1, 4)
        # A single dense contraction amortizes path planning and Python calls;
        # matrices are prepared once for this p/quadrature pair.
        return np.einsum('ab,ijbk->ijak', matrix, flat, optimize=True)

    def _traces(self, c):
        # First tangential face coordinate follows y for x-normal faces.
        return tuple(self._contract(c, matrix) for matrix in self._face_matrices)

    def _checkpoints(self, c):
        return self._contract(c, self._check_matrix)

    def _pressure(self, q):
        return pressure(q, self.gamma)

    def _flux(self, q, axis):
        rho = q[..., 0]
        p = self._pressure(q)
        if not np.all(np.isfinite(q)) or np.any(rho <= 0) or np.any(p <= 0):
            raise ValueError('Nonphysical flux quadrature state')
        un = q[..., 1+axis]/rho
        f = q*un[..., None]
        f[..., 1+axis] += p
        f[..., 3] = (q[..., 3]+p)*un
        return (-f if axis == 1 else f), (-un if axis == 1 else un), np.sqrt(self.gamma*p/rho)

    def _hll(self, ql, qr, axis):
        fl, ul, cl = self._flux(ql, axis)
        fr, ur, cr = self._flux(qr, axis)
        sl = np.minimum(np.minimum(ul-cl, ur-cr), 0.)
        sr = np.maximum(np.maximum(ul+cl, ur+cr), 0.)
        return (sr[..., None]*fl-sl[..., None]*fr+
                (sl*sr)[..., None]*(qr-ql))/(sr-sl)[..., None]

    def _boundary_traces(self, c, time):
        l, r, b, t = self._traces(c)
        xl = np.concatenate((r[-1:], r), axis=0)
        xr = np.concatenate((l, l[:1]), axis=0)
        yl = np.concatenate((t[:, -1:], t), axis=1)
        yr = np.concatenate((b, b[:, :1]), axis=1)
        if self.boundary != 'periodic':
            xl[0], xr[-1] = l[0], r[-1]
            yl[:, 0], yr[:, -1] = b[:, 0], t[:, -1]
        if self.boundary == 'double-mach':
            hot = conserved(8., 8.25*np.sqrt(3)/2, -4.125, 116.5)
            xl[0] = hot
            xface = self.x[:, None]+.5*self.dx*self.z
            yl[:, 0, :, 2] *= -1
            yl[:, 0] = np.where((xface < 1/6)[..., None], hot, yl[:, 0])
            yr[:, -1] = double_mach(xface, np.ones_like(xface), time)
        return xl, xr, yl, yr

    def _operator(self, c, time):
        embedded = self._embedded_1d(c)
        if embedded is not None:
            axis, line = embedded
            return self._operator_1d(line, axis)
        v = self.sample(c)
        fx = self._flux(v, 0)[0]
        fy = self._flux(v, 1)[0]
        xl, xr, yl, yr = self._boundary_traces(c, time)
        xf, yf = self._hll(xl, xr, 0), self._hll(yl, yr, 1)
        vx = self._contract(fx, self._volume_x).reshape(c.shape)
        vy = self._contract(fy, self._volume_y).reshape(c.shape)
        sr = np.einsum('an,ijak->ijnk', self.wb, xf[1:], optimize=True)
        sl = np.einsum('an,ijak->ijnk', self.wb, xf[:-1], optimize=True)
        st = np.einsum('am,ijak->ijmk', self.wb, yf[:, 1:], optimize=True)
        sb = np.einsum('am,ijak->ijmk', self.wb, yf[:, :-1], optimize=True)
        rx = vx-sr[:, :, None, :, :]+self.signs[None, None, :, None, None]*sl[:, :, None, :, :]
        ry = vy-st[:, :, :, None, :]+self.signs[None, None, None, :, None]*sb[:, :, :, None, :]
        derivative = (.5*rx/self.dx+.5*ry/self.dy)*self.scales[None, None, :, :, None]
        boundary = (.5*self.dy*np.einsum('a,jak->k', self.weights, xf[-1]-xf[0])+
                    .5*self.dx*np.einsum('a,iak->k', self.weights, yf[:, -1]-yf[:, 0]))
        return derivative, boundary

    def rhs(self, coeff, time=0.):
        """Unmodified spatial derivative; callers must provide physical traces."""
        return self._operator(np.asarray(coeff), time)[0]

    @staticmethod
    def _minmod(a, b, c, threshold=0.):
        s = np.sign(a)
        mm = s*np.minimum(np.minimum(abs(a), abs(b)), abs(c))
        mm = np.where((s == np.sign(b)) & (s == np.sign(c)), mm, 0.)
        return np.where(abs(a) <= threshold, a, mm)

    def _to_characteristic(self, delta, avg):
        rho = avg[...,0]
        u, v = avg[...,1]/rho, avg[...,2]/rho
        cs2 = self.gamma*self._pressure(avg)/rho
        cs = np.sqrt(cs2)
        dr, dm, dn, de = np.moveaxis(delta, -1, 0)
        dp = (self.gamma-1)*(de-u*dm-v*dn+.5*(u*u+v*v)*dr)
        acoustic = dp/cs2
        velocity = (dm-u*dr)/cs
        return np.stack((.5*(acoustic-velocity), dr-acoustic,
                         (dn-v*dr)/cs, .5*(acoustic+velocity)), axis=-1)

    def _from_characteristic(self, waves, avg):
        rho = avg[...,0]
        u, v = avg[...,1]/rho, avg[...,2]/rho
        cs = np.sqrt(self.gamma*self._pressure(avg)/rho)
        h = (avg[...,3]+self._pressure(avg))/rho
        am, contact, shear, ap = np.moveaxis(waves, -1, 0)
        acoustic = am+ap
        dr = acoustic+contact
        return np.stack((dr, u*dr+cs*(ap-am), v*dr+cs*shear,
                         h*acoustic+.5*(u*u+v*v)*contact+
                         u*cs*(ap-am)+v*cs*shear), axis=-1)

    def _limit_direction(self, right, left, slope, behind, ahead, avg, axis, h):
        permutation = [0,1,2,3] if axis == 0 else [0,2,1,3]
        state = avg[...,permutation]
        r,l,s,a,b = [self._to_characteristic(q[...,permutation],state)
                       for q in (right,left,slope,behind,ahead)]
        threshold = self.tvb*h*h
        tolerance = 1e-12*np.maximum(1., abs(state[...,0]))[...,None]
        troubled = np.any((abs(r-self._minmod(r,a,b,threshold)) > tolerance) |
                          (abs(l-self._minmod(l,a,b,threshold)) > tolerance), axis=-1)
        limited = self._from_characteristic(self._minmod(s,a,b),state)[...,permutation]
        return troubled, limited

    def _tvb_limit(self, c, time):
        avg = self.cell_average(c).copy()
        xm, xp = np.roll(avg, 1, 0), np.roll(avg, -1, 0)
        ym, yp = np.roll(avg, 1, 1), np.roll(avg, -1, 1)
        if self.boundary != 'periodic':
            xm[0], xp[-1] = avg[0], avg[-1]
            ym[:, 0], yp[:, -1] = avg[:, 0], avg[:, -1]
        if self.boundary == 'double-mach':
            hot = conserved(8., 8.25*np.sqrt(3)/2, -4.125, 116.5)
            xm[0] = hot
            ym[:, 0, 2] *= -1
            ym[:, 0] = np.where((self.x < 1/6)[:, None], hot, ym[:, 0])
            yp[:, -1] = double_mach(self.x, np.ones_like(self.x), time)
        # Average each face in its tangential direction.  The degree-zero
        # tangential Legendre coefficient is its exact polynomial face mean.
        dr = c[:, :, :, 0, :].sum(axis=2)-avg
        dl = avg-np.einsum('m,ijmk->ijk', self.signs, c[:, :, :, 0, :])
        dt = c[:, :, 0, :, :].sum(axis=2)-avg
        db = avg-np.einsum('n,ijnk->ijk', self.signs, c[:, :, 0, :, :])
        ax, bx, ay, by = avg-xm, xp-avg, avg-ym, yp-avg
        troubled_x, sx = self._limit_direction(dr,dl,c[:,:,1,0,:],ax,bx,avg,0,self.dx)
        troubled_y, sy = self._limit_direction(dt,db,c[:,:,0,1,:],ay,by,avg,1,self.dy)
        troubled = troubled_x | troubled_y
        count = int(troubled.sum())
        if count:
            c[troubled] = 0.
            c[:, :, 0, 0, :][troubled] = avg[troubled]
            c[:, :, 1, 0, :][troubled] = sx[troubled]
            c[:, :, 0, 1, :][troubled] = sy[troubled]
        return count

    def _stabilize_1d(self, line, axis):
        line = np.array(line, dtype=float, copy=True)
        avg = line[:,0,:].copy()
        pavg = self._pressure(avg)
        if np.any(avg[:,0] <= 1e-13) or np.any(pavg <= 1e-13):
            raise ValueError('Nonphysical cell average: reject step, do not floor')
        h = self.dx if axis == 0 else self.dy
        repeated = self.ny if axis == 0 else self.nx
        count = 0
        if self.limiter == 'tvb':
            prev, nex = np.roll(avg,1,axis=0), np.roll(avg,-1,axis=0)
            if self.boundary == 'outflow':
                prev[0], nex[-1] = avg[0], avg[-1]
            right = line.sum(axis=1)-avg
            left = avg-np.einsum('m,imk->ik',self.signs,line)
            troubled, slope = self._limit_direction(right,left,line[:,1,:],
                                                    avg-prev,nex-avg,avg,0,h)
            count = int(troubled.sum())
            if count:
                line[troubled] = 0.
                line[:,0,:] = avg
                line[troubled,1,:] = slope[troubled]
        basis = legvander(np.r_[self.z,[-1.,1.]],self.degree)
        q = np.einsum('am,imk->iak',basis,line)
        minrho = q[...,0].min(axis=1)
        epsrho = np.minimum(1e-12,.1*avg[:,0])
        density_bad = minrho < epsrho
        theta = np.minimum(1.,(avg[:,0]-epsrho)/np.maximum(avg[:,0]-minrho,1e-300))
        theta = np.where(density_bad,np.maximum(0.,theta)*(1-1e-14),1.)
        line *= theta[:,None,None]
        line[:,0,:] = avg
        if np.any(density_bad):
            q = np.einsum('am,imk->iak',basis,line)
        epsp = np.minimum(1e-12,.1*pavg)
        bad = np.any(self._pressure(q)<epsp[:,None],axis=1)
        if np.any(bad):
            qa = avg[bad][:,None,:]
            delta = q[bad]-qa
            lo,hi = np.zeros(int(bad.sum())),np.ones(int(bad.sum()))
            for _ in range(32):
                mid = .5*(lo+hi)
                physical = np.all(self._pressure(qa+mid[:,None,None]*delta)>=epsp[bad,None],axis=1)
                lo,hi = np.where(physical,mid,lo),np.where(physical,hi,mid)
            line[bad] *= (lo*(1-1e-14))[:,None,None]
            line[:,0,:] = avg
            q = np.einsum('am,imk->iak',basis,line)
        primitive(q,self.gamma)
        if self._stats is not None:
            st = self._stats
            st['limited_cell_stages'] += repeated*count
            st['positivity_scaled_cell_stages'] += repeated*int(np.count_nonzero(density_bad|bad))
            st['minimum_density'] = min(st['minimum_density'],float(q[...,0].min()))
            st['minimum_pressure'] = min(st['minimum_pressure'],float(self._pressure(q).min()))
            st['minimum_cell_average_density'] = min(st['minimum_cell_average_density'],float(avg[:,0].min()))
            st['minimum_cell_average_pressure'] = min(st['minimum_cell_average_pressure'],float(pavg.min()))
        return self._embed_1d(line,axis)

    def stabilize(self, coeff, time=0.):
        """Return a limited copy; preserve averages or reject nonphysical ones."""
        c = np.array(coeff, dtype=float, copy=True)
        if c.shape != self._shape or not np.all(np.isfinite(c)):
            raise ValueError('Invalid coefficient array')
        embedded = self._embedded_1d(c)
        if embedded is not None:
            axis,line = embedded
            return self._stabilize_1d(line,axis)
        avg = self.cell_average(c).copy()
        pavg = self._pressure(avg)
        if np.any(avg[..., 0] <= 1e-13) or np.any(pavg <= 1e-13):
            raise ValueError('Nonphysical cell average: reject step, do not floor')
        limited = self._tvb_limit(c, time) if self.limiter == 'tvb' else 0
        q = self._checkpoints(c)
        minrho = q[..., 0].min(axis=2)
        epsrho = np.minimum(1e-12, .1*avg[..., 0])
        theta = np.minimum(1., (avg[..., 0]-epsrho)/np.maximum(avg[..., 0]-minrho, 1e-300))
        density_bad = minrho < epsrho
        theta = np.where(density_bad, np.maximum(0., theta)*(1-1e-14), 1.)
        c *= theta[:, :, None, None, None]
        c[:, :, 0, 0, :] = avg
        if np.any(density_bad):
            q = self._checkpoints(c)
        pq = self._pressure(q)
        epsp = np.minimum(1e-12, .1*pavg)
        bad = np.any(pq < epsp[..., None], axis=2)
        if np.any(bad):
            qa = avg[bad][:, None, :]
            dq = q[bad]-qa
            lo, hi = np.zeros(int(bad.sum())), np.ones(int(bad.sum()))
            target = epsp[bad]
            for _ in range(32):
                mid = .5*(lo+hi)
                physical = np.all(self._pressure(qa+mid[:, None, None]*dq) >= target[:, None], axis=1)
                lo = np.where(physical, mid, lo)
                hi = np.where(physical, hi, mid)
            c[bad] *= (lo*(1-1e-14))[:, None, None, None]
            c[:, :, 0, 0, :] = avg
            q = self._checkpoints(c)
        primitive(q, self.gamma)
        if self._stats is not None:
            st = self._stats
            st['limited_cell_stages'] += limited
            st['positivity_scaled_cell_stages'] += int(np.count_nonzero(density_bad | bad))
            st['minimum_density'] = min(st['minimum_density'], float(q[..., 0].min()))
            st['minimum_pressure'] = min(st['minimum_pressure'], float(self._pressure(q).min()))
            st['minimum_cell_average_density'] = min(st['minimum_cell_average_density'], float(avg[..., 0].min()))
            st['minimum_cell_average_pressure'] = min(st['minimum_cell_average_pressure'], float(pavg.min()))
        return c

    def integral(self, coeff):
        return self.dx*self.dy*self.cell_average(coeff).sum(axis=(0, 1))

    def _stable_dt(self, c, cfl):
        embedded = self._embedded_1d(c)
        if embedded is not None:
            axis,line = embedded
            q = np.einsum('am,imk->iak',legvander(np.r_[self.z,[-1.,1.]],self.degree),line)
            rho = q[...,0]
            cs = np.sqrt(self.gamma*self._pressure(q)/rho)
            h, ht = (self.dx,self.dy) if axis == 0 else (self.dy,self.dx)
            rate = np.max((abs(q[...,1]/rho)+cs)/h+(abs(q[...,2]/rho)+cs)/ht)
            return cfl/((2*self.degree+1)*rate)
        q = self._checkpoints(c)
        rho = q[..., 0]
        cs = np.sqrt(self.gamma*self._pressure(q)/rho)
        rate = np.max((abs(q[..., 1]/rho)+cs)/self.dx+
                      (abs(q[..., 2]/rho)+cs)/self.dy)
        return cfl/((2*self.degree+1)*rate)

    def _step(self, u, time, dt):
        """Five-stage fourth-order SSP Runge--Kutta, including flux quadrature.

        Stage abscissae follow the same affine recurrence as the solution.
        The boundary primitive follows that recurrence with initial value zero.
        Difference-form convex combinations preserve constant states exactly.
        """
        a10 = .391752226571890
        b21, a21 = .555629506348765, .368410593050371
        b32, a32 = .379898148511597, .251891774271694
        b43, a43 = .821920045606868, .544974750228521
        b53, b54 = .096059710526147, .386708617503269
        b52 = 1.-b53-b54
        a53, a54 = .063692468666290, .226007483236906
        c1 = a10
        c2 = b21*c1+a21
        c3 = b32*c2+a32
        c4 = b43*c3+a43
        k0,f0 = self._operator(u,time)
        u1 = self.stabilize(u+a10*dt*k0,time+c1*dt)
        i1 = a10*dt*f0
        k1,f1 = self._operator(u1,time+c1*dt)
        u2 = self.stabilize(u+b21*(u1-u)+a21*dt*k1,time+c2*dt)
        i2 = b21*i1+a21*dt*f1
        k2,f2 = self._operator(u2,time+c2*dt)
        u3 = self.stabilize(u+b32*(u2-u)+a32*dt*k2,time+c3*dt)
        i3 = b32*i2+a32*dt*f2
        k3,f3 = self._operator(u3,time+c3*dt)
        u4 = self.stabilize(u+b43*(u3-u)+a43*dt*k3,time+c4*dt)
        i4 = b43*i3+a43*dt*f3
        k4,f4 = self._operator(u4,time+c4*dt)
        new = u2+b53*(u3-u2)+b54*(u4-u2)+dt*(a53*k3+a54*k4)
        new = self.stabilize(new,time+dt)
        outgoing = b52*i2+b53*i3+b54*i4+dt*(a53*f3+a54*f4)
        return new,outgoing


    def evolve(self, coeff, final_time, cfl=.2, dt_max=None, initial_time=0.,
               max_steps=100000, callback=None):
        """Advance to an exact output time; failed stage averages halve dt.

        ``callback(time, coeff)`` runs after accepted complete steps. Diagnostics
        count all attempted limiter calls, and boundary integrals only accepted
        steps. ``dt_max`` enables independent temporal refinement.
        """
        if not np.isfinite(final_time) or not np.isfinite(initial_time) or final_time < initial_time:
            raise ValueError('Require finite final_time >= initial_time')
        if not np.isfinite(cfl) or not 0 < cfl <= .5:
            raise ValueError('Require 0<CFL<=.5')
        if dt_max is not None and (not np.isfinite(dt_max) or dt_max <= 0):
            raise ValueError('Require positive finite dt_max')
        self._stats = dict(limited_cell_stages=0, positivity_scaled_cell_stages=0,
                           rejected_steps=0, minimum_density=float('inf'),
                           minimum_pressure=float('inf'), minimum_cell_average_density=float('inf'),
                           minimum_cell_average_pressure=float('inf'), min_dt=float('inf'), max_dt=0.)
        try:
            u = self.stabilize(coeff, initial_time)
            initial = self.integral(u)
            boundary = np.zeros(4)
            time, steps = float(initial_time), 0
            while time < final_time:
                if steps >= max_steps:
                    raise RuntimeError('Exceeded max_steps')
                dt = min(self._stable_dt(u, cfl), final_time-time,
                         float('inf') if dt_max is None else dt_max)
                for attempt in range(16):
                    try:
                        new, outgoing = self._step(u, time, dt)
                        break
                    except ValueError as exc:
                        if 'Nonphysical' not in str(exc):
                            raise
                        dt *= .5
                        self._stats['rejected_steps'] += 1
                else:
                    raise RuntimeError('Unable to maintain positive cell averages by dt reduction')
                if dt <= np.finfo(float).eps*max(1., abs(time)):
                    raise RuntimeError('Time step underflow')
                u = new
                boundary += outgoing
                time += dt
                steps += 1
                self._stats['min_dt'] = min(self._stats['min_dt'], dt)
                self._stats['max_dt'] = max(self._stats['max_dt'], dt)
                if callback is not None:
                    callback(time, u)
            final = self.integral(u)
            diagnostics = dict(self._stats)
            if not steps:
                diagnostics['min_dt'] = 0.
            diagnostics.update(initial_integral=initial.tolist(), final_integral=final.tolist(),
                               integrated_boundary_outflow=boundary.tolist(),
                               conservation_defect=(final-initial+boundary).tolist(),
                               basis='tensor Legendre Qp', degree=self.degree,
                               quadrature_points=len(self.z), temporal_method='SSPRK(5,4)',
                               boundary=self.boundary, limiter=self.limiter,
                               tvb_parameter=self.tvb,
                               limiter_variables='density-normalized Euler characteristic')
            return DGResult(u, time, steps, diagnostics)
        finally:
            self._stats = None
