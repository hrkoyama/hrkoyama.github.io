Atlas RKDG agent-assembly demonstration / エージェント組み立て実演

This kit provides a Cartesian 2D ideal-gas Euler DG implementation, an
intentionally incomplete starter, an AI-assembled candidate, frozen scientific
acceptance rules, independent references, negative controls and measured data.
It is a bounded code-development demonstration using Atlas-supplied parts.
It is not a guarantee of arbitrary AI-generated scientific software.

日本語の説明: docs/rkdg.md    English: docs/rkdg-en.md
The current scientific results belong to outputs/rkdg-2026-11-23/accepted-v3/;
the separate post-shock wave-resolution report is
outputs/rkdg-2026-11-23/resolution-v3.json. A final ZIP is built only after BOTH
reports pass and their source/array bindings have been independently rechecked.
Read BUILD-STATE.json, verdict.json, metrics.json and raw-array-manifest.json.
A tree marked nonfinal-code-test-staging is only an isolated packaging test.
The older accepted/ directory is historical v2: its original 48 criteria passed,
but resolution-v2.json failed. Neither its history nor its limits were rewritten.
The failed first attempt and the actual repair source/patches are also retained.

現行版の計算記録は accepted-v3/、波形解像度の追加4診断は resolution-v3.json。
最終ZIPは両方の合格とソース・配列の照合を確認してから作成する。旧 accepted/ は
v2の履歴であり、元の48判定は合格したが追加の波形解像度診断では不合格だった。

Scope / 範囲
- 2D compressible Euler, gamma=1.4, uniform Cartesian grids, tensor Q1/Q2/Q3.
- HLL flux, overintegrated weak form, SSPRK(5,4), density-normalized
  characteristic TVB shock limiting and
  cell-average-preserving positivity scaling at declared discrete points.
- Oblique smooth entropy-wave order; x/y embedded Sod and Shu–Osher;
  Double Mach broad shock comparison and boundary-flux conservation.
- Shock cells may be reduced to limited linear polynomials. Smooth 2/3/4th
  order is not a global shock-convergence claim or an exact DMR solution.
- The wider Atlas also covers MHD, relativistic flow, particles/transport,
  molecular dynamics, thermostats, quantum chemistry/DFT, biology, stochastic
  calculation and foundational numerical methods. Verification depth varies.

Setup / 環境
Python >=3.9 and NumPy >=1.24 are needed for computation and evaluation.
pytest is optional for the structural regression tests; matplotlib is optional
for figure generation. Use an isolated environment. The recorded environment
in the delivered metrics is authoritative for the actual campaign.

Reproduce the complete fixed campaign / 全計算を再実行
Run these commands from the root of the unpacked distribution:

 python scripts/run_rkdg_campaign.py --solver agent-kits/rkdg2d/generated/rkdg2d.py --output outputs/recheck
 python scripts/run_rkdg_negative_control.py --solver agent-kits/rkdg2d/generated/rkdg2d.py --campaign outputs/recheck --output outputs/recheck-negative
 python validation/rkdg/evaluate.py outputs/recheck/metrics.json --solver agent-kits/rkdg2d/generated/rkdg2d.py --output outputs/recheck/verdict.json
 python validation/rkdg/resolution.py --campaign outputs/recheck --solver agent-kits/rkdg2d/generated/rkdg2d.py --output outputs/recheck/resolution-verdict.json

The original verdict and four additional ROI checks are separate records.
Do not replace the original acceptance contract with the supplemental contract.

Structural tests / 構造と評価器の回帰検査
 python -m pytest -q tests/test_rkdg*.py

All seven files are included. They test spatial/time integration, independent
references/evaluation, characteristic transforms, coordinate invariance,
supplemental resolution metrics and interchange corruption/rejection behavior.
They do not replace the full scientific campaign above. The root-repository
historical test log can include other modules absent from this minimal kit;
the isolated-distribution receipt specifies exactly what was run here.

Saved-result checking / 保存結果だけの照合
 python validation/rkdg/evaluate.py outputs/rkdg-2026-11-23/accepted-v3/metrics.json --solver agent-kits/rkdg2d/generated/rkdg2d.py --output outputs/saved-verdict.json
 python validation/rkdg/resolution.py --campaign outputs/rkdg-2026-11-23/accepted-v3 --solver agent-kits/rkdg2d/generated/rkdg2d.py --output outputs/saved-resolution-verdict.json
This does not rerun a numerical solver. A passing saved verdict and a fresh
scientific rerun are different checks. SHA256SUMS.txt binds the distributed files.

Port / MPI output checking / 多言語移植・MPI後の出力照合
PORT-AND-MPI-TASK.txt is a concrete task for the user's AI agent. It specifies
algorithm preservation, the same fixed physical tests, domain decomposition,
stage-wise halos, global CFL and a required execution/provenance report.
The JSON + CSV contract in docs/rkdg-interchange.md / -en.md permits Python,
C++, Fortran, Julia or another language to export owned modal coefficients.

 python validation/rkdg/interchange.py compare agent-kits/rkdg2d/interchange-example/partitions-1/manifest.json agent-kits/rkdg2d/interchange-example/partitions-4/manifest.json --output outputs/io-comparison.json
 python validation/rkdg/interchange.py check-reference outputs/rkdg-2026-11-23/accepted-v3/arrays/smooth-p2-n8.npz port-output/manifest.json --output outputs/port-comparison.json

The second command expects actual port output for that exact physical case;
it is a template, not a bundled passing port result. Output tolerances are a
separate I/O-equivalence contract and do not relax scientific acceptance.
所有セルだけを出力し、ゴーストセルを含めない。MPIの分割順序やCSV行順には依存せず、
全モードを比較する。還元順序による丸め差を許容し、ビット単位一致は要求しない。

Executed capability checks in this kit:
- Saved-array fixtures with 1, 2 and 4 partitions were exported from historical
  v2 smooth data and checked in arbitrary ownership/row orders. These are I/O
  simulations, not mpiexec runs. Their receipt preserves the v2 provenance.
- A real C++17 program independently writes a known analytic Q2 Euler
  polynomial; the Python checker compares every mode and global integral.
  Source, compiler receipt and emitted files are in interchange-example/cpp-io/.
- No foreign-language PDE solver or MPI PDE runtime has been executed.
  Passing the output fixture cannot establish correct MPI communication.
実施済みは分割出力の照合とC++17による独立した解析多項式の入出力確認。
他言語のPDE移植・MPIでのPDE実行は未実施として明記する。

Agent task / AIへの作業依頼
AGENT-TASK.txt is the actual initial task; AGENT-FOLLOWUP.txt records the
endpoint-roundoff repair and AGENT-REPAIR-2.txt records the measured symmetry
failure and its numerical repair request. Additional actual repairs and
acceptance failures are documented in generated/assembly-notes.txt and the
history records. starter/rkdg2d.py has no time integrator. generated/rkdg2d.py
contains the candidate actually evaluated. assembly.patch records its changes.
A new agent should work in its own candidate copy; it must not edit acceptance
rules, evaluation code, independent references or recorded successful results.

Independent references are provided as small frozen arrays. Regenerating them
is optional; the reference implementation and its input definitions are included.
Shu–Osher grid-change uncertainty is global relative density L1, not a pointwise
error bound. Double Mach reference resolves broad shock structure, not fine
vortices. Read the bilingual explanations before extending these cases.

License: MIT for the supplied original code; primary algorithm papers are cited
in the source/docs. No manuscript, private poster QR, or quantum-chemistry
calculation is included in this code kit.
