#!/usr/bin/env python3
"""Independent analytic modal fixture. No candidate PDE solver is imported."""
from pathlib import Path
import json
import sys
import numpy as np

ROOT = next(p for p in Path(__file__).resolve().parents if (p/'validation/rkdg/interchange.py').is_file())
sys.path.insert(0, str(ROOT))
from validation.rkdg.interchange import export_reference_npz


def main():
    if len(sys.argv) != 2:
        raise SystemExit('Usage: make_reference.py OUTPUT_DIRECTORY')
    out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
    npz = out/'polynomial-io-fixture.npz'
    if npz.exists(): raise SystemExit('Refusing to overwrite reference array')
    # rho=1+.12*x+.06*y, constant velocity(.3,-.2), pressure1, on3x2 cells.
    # Coefficients are analytic, not a copy of C++'s output or a PDE result.
    c = np.zeros((3,2,3,3,4))
    centers_x = (np.arange(3)+.5)/3
    centers_y = (np.arange(2)+.5)/2
    means = 1+.12*centers_x[:,None]+.06*centers_y[None,:]
    c[:,:,0,0,0] = means
    c[:,:,1,0,0] = .12/(2*3)
    c[:,:,0,1,0] = .06/(2*2)
    c[...,1] = .3*c[...,0]
    c[...,2] = -.2*c[...,0]
    c[...,3] = .5*(.3**2+.2**2)*c[...,0]
    c[:,:,0,0,3] += 2.5
    integral = c[:,:,0,0,:].mean(axis=(0,1)).tolist()
    config = {'nx':3,'ny':2,'degree':2,'bounds':[0.,1.,0.,1.],
              'boundary':'outflow','time':0.}
    diag = {'initial_integral':integral,'final_integral':integral,
            'integrated_boundary_outflow':[0.,0.,0.,0.]}
    np.savez(npz,coeff=c,config=json.dumps(config),diagnostics=json.dumps(diag))
    path = export_reference_npz(npz,out/'python-reference',case='polynomial-io-fixture')
    print(path)


if __name__ == '__main__': main()
