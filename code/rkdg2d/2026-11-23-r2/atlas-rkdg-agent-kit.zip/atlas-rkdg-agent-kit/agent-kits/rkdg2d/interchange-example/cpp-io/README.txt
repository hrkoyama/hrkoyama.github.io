Actual C++17 output-format smoke test / C++出力形式の実追試

writer.cpp computes analytic tensor Legendre coefficients for
rho=1+0.12*x+0.06*y, velocity=(0.3,-0.2), pressure=1, gamma=1.4,
on 3x2 Cartesian cells with degree 2. It writes all four conserved fields to
two non-contiguous owned-cell CSV partitions with reversed row/mode order.
It uses C++17 standard library only. No PDE time stepping and no MPI call occurs.
The execution_kind is foreign-language-io-fixture, not solver-output.

make_reference.py independently constructs the analytic modal coefficients in
Python/NumPy; it doesnot read C++ output and imports no candidate PDE solver.
The shared checker compares Python's serialreference with C++'s two outputfiles.
comparison.json and verification.json record actual execution and numeric results.
The compiler binary was temporary; source and results are preserved here.

Reproduce from distribution root (choose fresh output directories):

 mkdir -p build
 c++ -std=c++17 -O2 agent-kits/rkdg2d/interchange-example/cpp-io/writer.cpp -o build/rkdg-io-writer
 python agent-kits/rkdg2d/interchange-example/cpp-io/make_reference.py outputs/cpp-io-reference
 build/rkdg-io-writer outputs/cpp-io-output
 python validation/rkdg/interchange.py compare outputs/cpp-io-reference/python-reference/manifest.json outputs/cpp-io-output/manifest.json --output outputs/cpp-io-verdict.json

This validates actual C++ formatting and the language-neutral loader/field comparison.
It doesNOTvalidate a C++ Eulerport, MPI communication, parallel timestepping,
performance, or all48 physical RKDG tests. Those require their own solver executions.

実際にC++17コードをコンパイル・実行し、独立なPython解析係数と照合した。
これは入出力の言語互換性の追試であり、C++流体コードやMPI計算の検証ではない。
