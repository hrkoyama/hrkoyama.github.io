Saved RKDG coefficient fixtures, partitioned into 1/2/4 CSV files.
These are formatter/loader equivalence checks, not MPI or foreign-language PDE runs.
Sourcearray: outputs/rkdg-2026-11-23/accepted/arrays/smooth-p2-n8.npz
SHA256: 937a91a8569c55e8a91082a5f20905e310b745bc92ba02299c27d3f591069997
See verification.json and docs/rkdg-interchange.md / rkdg-interchange-en.md.
