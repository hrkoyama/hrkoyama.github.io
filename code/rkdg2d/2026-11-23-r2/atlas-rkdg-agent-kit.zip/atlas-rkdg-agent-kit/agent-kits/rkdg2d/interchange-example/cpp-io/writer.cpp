// Analytic modal-output fixture, not a PDE solver and not an MPI program.
// C++17, standard library only. All modes of each owned cell stay in one file.
#include <array>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <locale>
#include <sstream>
#include <stdexcept>
#include <string>

namespace fs = std::filesystem;

std::array<double, 4> coefficient(int i, int j, int m, int n) {
    // rho = 1 + .12*x + .06*y, u=.3, v=-.2, pressure=1, gamma=1.4.
    // Standard Legendre P1(xi)=xi; x=xc+(dx/2)*xi and y=yc+(dy/2)*eta.
    constexpr double u = .3, v = -.2, dx = 1./3., dy = 1./2.;
    const double xc = (i+.5)*dx, yc = (j+.5)*dy;
    double rho = 0.;
    if (m == 0 && n == 0) rho = 1.+.12*xc+.06*yc;
    if (m == 1 && n == 0) rho = .12*dx/2.;
    if (m == 0 && n == 1) rho = .06*dy/2.;
    const double kinetic = .5*(u*u+v*v);
    const double energy = kinetic*rho + ((m == 0 && n == 0) ? 2.5 : 0.);
    return {rho, rho*u, rho*v, energy};
}

int main(int argc, char** argv) {
    try {
        if (argc != 2) throw std::runtime_error("Usage: writer OUTPUT_DIRECTORY");
        const fs::path out(argv[1]);
        fs::create_directories(out);
        if (fs::exists(out/"manifest.json")) throw std::runtime_error("Refusing to overwrite a manifest");
        for (int rank = 0; rank < 2; ++rank) {
            std::ostringstream name;
            name << "rank-" << std::setfill('0') << std::setw(4) << rank << ".csv";
            const fs::path dest = out/name.str();
            if (fs::exists(dest)) throw std::runtime_error("Refusing to overwrite a partition");
            std::ofstream csv(dest);
            csv.exceptions(std::ios::failbit | std::ios::badbit);
            csv.imbue(std::locale::classic());
            csv << std::setprecision(17);
            csv << "global_i,global_j,mode_i,mode_j,rho,rho_u,rho_v,energy\n";
            // Reverse cell and modal ordering; ownership differs from Python's serial file.
            for (int cell = 5; cell >= 0; --cell) {
                const int i = cell/2, j = cell%2;
                if ((i+2*j)%2 != rank) continue;
                for (int m = 2; m >= 0; --m) for (int n = 2; n >= 0; --n) {
                    const auto q = coefficient(i,j,m,n);
                    csv << i << ',' << j << ',' << m << ',' << n;
                    for (double value : q) csv << ',' << value;
                    csv << '\n';
                }
            }
        }
        std::ofstream manifest(out/"manifest.json");
        manifest.exceptions(std::ios::failbit | std::ios::badbit);
        manifest << R"JSON({
  "schema": "atlas-rkdg-modal-csv-v1",
  "representation": "modal-legendre-Qp",
  "basis": {"family":"Legendre","interval":[-1,1],"normalization":"P_m(1)=1","cell_average_mode":[0,0],"tensor_space":"Qp"},
  "variables": ["rho","rho_u","rho_v","energy"],
  "dtype": "float64",
  "case": "polynomial-io-fixture",
  "time": 0.0,
  "gamma": 1.4,
  "degree": 2,
  "global_shape": [3,2],
  "bounds": [0.0,1.0,0.0,1.0],
  "boundary": "outflow",
  "axis": null,
  "rank_count": 2,
  "partitions": [{"rank":0,"file":"rank-0000.csv"},{"rank":1,"file":"rank-0001.csv"}],
  "execution_kind": "foreign-language-io-fixture",
  "criteria_sha256": "7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af",
  "producer": "C++17 analytic polynomial output writer",
  "language": "C++17",
  "notes": "Actual C++ output formatting was executed. This program neither advances a PDE nor launches MPI.",
  "diagnostics": {
    "initial_integral": [1.09,0.327,-0.218,2.57085],
    "final_integral": [1.09,0.327,-0.218,2.57085],
    "integrated_boundary_outflow": [0.0,0.0,0.0,0.0]
  }
})JSON";
        std::cout << (out/"manifest.json").string() << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n'; return 1;
    }
}
