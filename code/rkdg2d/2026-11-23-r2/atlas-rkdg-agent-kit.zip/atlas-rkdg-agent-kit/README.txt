Numerical Methods Atlas: 2D Euler RKDG agent code and fixed tests
Release 2026-11-23-r2

Start with agent-kits/rkdg2d/TESTSET.md (Japanese) or TESTSET-en.md (English).
Public entry: https://hrkoyama.github.io/numerical-methods-atlas/agent-kits/rkdg2d/
Machine-readable identity: RELEASE.json. Public archive SHA is in the external
public-manifest.json and .zip.sha256 sidecar; SHA256SUMS.txt binds archive files.

Recommended setup Python3.12; source syntax minimum3.9. Local fixed-dependency
checks used Python3.9.6/NumPy2.0.2. Python3.13+ is unverified for this release.
Install requirements-verified.txt for the recorded NumPy version.
Run python scripts/run_rkdg_smoke.py --output outputs/fresh-smoke.json
for six small fresh fully2D evolutions. This is not the 48-case qualification.

Current candidate SHA256:
4ed984a01c42fe9bb657c09c61361b086682d6aa611e9f478bf996c0b29b81d4
Original48 PASS and supplemental waveform4 PASS are separate from the later
x-reflection6 check: only5/6 PASS; Shu-Osher p3 exceeds its frozen1e-10 limit.
The historical reflection runner is pinned to this original source only.
The full campaign and explicit failure are retained without relaxed criteria.

The original agent-kits/rkdg2d/README.txt, accepted/ directory and assembly-notes
are historical demonstration records. The current accepted-v3 directory and
RELEASE.json identify the current source. All nine tests/test_rkdg*.py files
are included; pytest is optional, with requirements-tests-verified.txt provided.

The kit supports independent reference checks and a JSON/CSV output contract
for ports and MPI. Executed C++ analytic I/O and partition fixtures are not
foreign-language PDE solves or actual MPI PDE executions; these remain unrun.
r2 allows only named derived diagnostic display floats to differ by64eps
relative during saved-record comparison. Frozen scientific acceptance is
rerun without relaxed thresholds; input/hash/ID/verdict fields remain exact.
No poster, private manuscript, private QR or quantum calculation is included.
License: MIT; preserve LICENSE. Primary papers are cited in docs/rkdg*.md.
