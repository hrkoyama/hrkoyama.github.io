# Common output checks after language ports and MPI parallelization

[日本語](rkdg-interchange.md) · [RKDG numerical verification](rkdg-en.md)

This interface compares **the same physical quantities against the same reference arrays** after a C++, Fortran, Julia or other language port, or after domain decomposition with MPI. [interchange.py](../validation/rkdg/interchange.py) reads JSON conditions and owned-cell CSV files, then reconstructs all four conserved modal fields independently of rank ownership and output ordering.

Implemented and tested here are input reconstruction, ownership/completeness checks, numerical comparison with reference or serial output, and independently reconstructed density errors. Saved-array fixtures partitioned into 1, 2 and 4 files have been checked. Those preserved fixtures derive from historical v2; they are not relabeled as updated v3 data. **No MPI process or foreign-language Euler solver was executed by these fixture checks.** Fixtures declare `execution_kind: "fixture-export"`; reports retain `mpi_execution_verified: false`.

The [C++17 analytic coefficient writer](../agent-kits/rkdg2d/interchange-example/cpp-io/) was also actually compiled and run. C++ computes all four conserved Legendre fields for a known linear-density, constant-velocity, constant-pressure polynomial; Python independently constructs its reference. Two owned-cell files in reversed ordering matched with maximum coefficient difference 3.47×10⁻¹⁸ and zero global-integral difference. **This validates actual C++ output interoperability, not a C++ fluid solver port or MPI communication.** It is labelled `execution_kind: "foreign-language-io-fixture"`, `case: "polynomial-io-fixture"`.

The current numerical reference outputs correspond to [v3's passed 48 scientific cases and four waveform diagnostics](../outputs/rkdg-2026-11-23/scientific-summary-v3.json). The reproduction commands below use `accepted-v3/`, but do not relabel the preserved partition fixtures or C++ polynomial I/O record as foreign-language v3 PDE execution.

## Language-neutral output contract

Write one `manifest.json` and one CSV per declared rank. Print about 17 significant digits for round-trip float64 coefficients. See [interchange-example](../agent-kits/rkdg2d/interchange-example/).

Required JSON metadata:

- `schema: "atlas-rkdg-modal-csv-v1"`, `representation: "modal-legendre-Qp"`, `dtype: "float64"`.
- `basis` contains `family: "Legendre"`, `interval: [-1,1]`, `normalization: "P_m(1)=1"`, `cell_average_mode: [0,0]`, `tensor_space: "Qp"`.
- `variables: ["rho","rho_u","rho_v","energy"]`. Energy is **total energy per volume**, not pressure or specific energy.
- `case`, `time`, `gamma: 1.4`, `degree`, `global_shape: [nx,ny]`, `bounds: [xmin,xmax,ymin,ymax]`, `boundary`, `axis`. Directional cases use axis0/1, fully two-dimensional cases use `null`.
- `rank_count`, `partitions: [{"rank":0,"file":"rank-0000.csv","sha256":"..."}, ...]`, and `execution_kind: "solver-output"`, `"fixture-export"` or `"foreign-language-io-fixture"`.
- `criteria_sha256` identifies the unchanged physical criteria: `7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af`.

Optional fields are `producer`, `language`, `source_sha256`, `reference_npz_sha256`, `notes`, `diagnostics`. If supplied, diagnostics must contain four-component `initial_integral`, `final_integral`, `integrated_boundary_outflow`. Unknown metadata is rejected rather than silently reinterpreted.

`polynomial-io-fixture` is reserved for output testing and cannot declare `solver-output`. Its criteria SHA records the format's lineage, not execution of the 48 physical cases. Compiler details, commands, source and output hashes are in the example's `verification.json`.

The exact CSV header and field order is:

```text
global_i,global_j,mode_i,mode_j,rho,rho_u,rho_v,energy
```

Global indices are zero-based. Export every mode `(0..p,0..p)` of each owned cell exactly once from the same rank; mode00 is its cell average. Exclude halo/ghost cells. Within-file ordering, ownership layout, and partition listing order are arbitrary. An empty rank may write a header-only CSV. Nodal DG implementations must transform their output to this Legendre coefficient convention first.

The schema cannot prove that a solver applied the declared initial and boundary conditions. Preserve inputs, source and execution commands separately and match the reference output time and representation.

## MPI checks

Finish every rank's output before publishing the manifest. Global reconstruction detects missing cells/modes, duplicate halos, out-of-range indices, modes of one owned cell split across ranks, and nonfinite values. Rank0's local array is not the global solution.

Compare each coefficient with `abs(actual-reference) <= atol + rtol*abs(reference)`, rather than requiring bitwise equality. Defaults are `atol=1e-11`, `rtol=1e-9`. These are **output-equivalence tolerances**, allowing reduction-order roundoff; they do not relax the original 48-case physical acceptance. Incompatible times, meshes, field ordering or bases reject the comparison.

Full modal comparison also finds high-mode corruption invisible in cell averages. Reports include the global four-variable integral difference and positivity at the declared quadrature points and corners. When boundary-flux diagnostics are supplied, their final integral is checked against the output and the flux-corrected conservation defect must meet the unchanged physical limit `1e-9`, read from the hash-pinned original criteria. A failure rejects the comparison even if every mode matches or the I/O tolerances are large. Reports state `conservation_checked=true`; absent optional diagnostics state `false` and establish no boundary-flux conservation result. Open boundaries and reflecting-wall forces must not be replaced by an incorrect constant-global-momentum assertion.

## Commands

Export the saved v3 arrays to new serial and four-partition **fixtures**. Do not overwrite the preserved historical v2 fixtures.

```bash
python validation/rkdg/interchange.py export-fixture \
  outputs/rkdg-2026-11-23/accepted-v3/arrays/smooth-p2-n8.npz outputs/io-v3-serial
python validation/rkdg/interchange.py export-fixture \
  outputs/rkdg-2026-11-23/accepted-v3/arrays/smooth-p2-n8.npz outputs/io-v3-four --ranks 4 --shuffle
python validation/rkdg/interchange.py compare \
  outputs/io-v3-serial/manifest.json outputs/io-v3-four/manifest.json --output outputs/io-v3-verdict.json
```

Compare actual output written by a port/MPI implementation using the same contract:

```bash
python validation/rkdg/interchange.py check-reference \
  outputs/rkdg-2026-11-23/accepted-v3/arrays/smooth-p2-n8.npz port-output/manifest.json \
  --output outputs/port-verdict.json
```

Exit0 means the output check passed; exit1 means a numerical mismatch or invalid evidence. The Python APIs are `load_run`, `compare_runs`, `compare_reference_manifest`, and `entropy_metrics`. The last uses the existing independent `modal_density_errors`, preserving definitions of density L1/L2 and sampled Linf after a port.

One output-equivalence check is separate from a full physical-accuracy/convergence verdict. A formal port assessment runs every target case and reapplies the original error, order, conservation and positivity criteria. To claim a verified MPI implementation, additionally record actual launcher commands, process counts, decompositions, communication environment and measured checks.
