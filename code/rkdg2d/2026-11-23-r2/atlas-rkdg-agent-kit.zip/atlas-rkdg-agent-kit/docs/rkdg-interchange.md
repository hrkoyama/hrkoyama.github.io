# 多言語移植・MPI並列化後の共通出力検証

[English](rkdg-interchange-en.md) · [RKDGの数値検証](rkdg.md)

数値コードをC++、Fortran、Juliaなどへ移植した後や、MPIで領域を分割した後にも、**同じ物理量・同じ参照配列を使って照合する**ための入口である。実装は [interchange.py](../validation/rkdg/interchange.py)。JSONの計算条件と、所有セルのCSV出力を読み、言語やランクごとの出力順序に依存せず、全保存量のDGモードを再構成する。

今回実装・確認したのは共通出力の読込、所有権・欠落・重複の検査、参照／直列出力との数値比較、独立再構成した密度誤差である。1・2・4分割の保存配列フィクスチャーで追試した。これらの保存済みフィクスチャーは履歴v2に由来し、v3へ更新したものとして読み替えない。**これはMPIプロセスを実行した試験でも、他言語のEulerソルバーを実行した試験でもない。** 分割フィクスチャーの生成物は `execution_kind: "fixture-export"` と明示し、結果にも `mpi_execution_verified: false` を残す。

さらに [C++17の解析的係数出力例](../agent-kits/rkdg2d/interchange-example/cpp-io/) を実際にコンパイル・実行した。線形密度・一定速度・一定圧力の既知多項式から全4保存量のLegendre係数をC++で計算し、独立に構成したPython参照と照合した。2つの所有セルファイルを逆順で書き出しても最大係数差は3.47×10⁻¹⁸、全領域積分差は0だった。**確認したのはC++入出力の互換性であり、C++流体コードの移植やMPI通信ではない。** この例は `execution_kind: "foreign-language-io-fixture"`、`case: "polynomial-io-fixture"` と区別する。

現在の数値計算の参照出力は、[v3の48科学ケースと波形4診断の合格記録](../outputs/rkdg-2026-11-23/scientific-summary-v3.json)に対応する。以下の追試例は `accepted-v3/` を入力にするが、保存済みの分割フィクスチャーやC++多項式I/Oの記録を、v3の他言語PDE計算へ読み替えるものではない。

## 言語に依存しない出力契約

1実行につき `manifest.json` と、各ランク1個のCSVを出力する。倍精度の係数には往復変換できる17桁程度を使う。例は [interchange-example](../agent-kits/rkdg2d/interchange-example/) にある。

JSONの必須項目は次のとおり。

- `schema: "atlas-rkdg-modal-csv-v1"`、`representation: "modal-legendre-Qp"`、`dtype: "float64"`。
- `basis` は `family: "Legendre"`、`interval: [-1,1]`、`normalization: "P_m(1)=1"`、`cell_average_mode: [0,0]`、`tensor_space: "Qp"`。
- `variables: ["rho","rho_u","rho_v","energy"]`。最後は単位体積あたりの**全エネルギー**であり、圧力や比エネルギーと入れ替えない。
- `case`、`time`、`gamma: 1.4`、`degree`、`global_shape: [nx,ny]`、`bounds: [xmin,xmax,ymin,ymax]`、`boundary`、`axis`。方向別問題は `axis: 0` または `1`、完全2D問題は `null`。
- `rank_count`、`partitions: [{"rank":0,"file":"rank-0000.csv","sha256":"..."}, ...]`、`execution_kind: "solver-output"`、`"fixture-export"` または `"foreign-language-io-fixture"`。
- `criteria_sha256` は元の物理検証の固定SHA `7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af`。

`producer`、`language`、`source_sha256`、`reference_npz_sha256`、`notes`、`diagnostics` は任意。`diagnostics` を含める場合は、4成分の `initial_integral`、`final_integral`、`integrated_boundary_outflow` をすべて記録する。未知の項目を黙って読み替えない。

`polynomial-io-fixture` は入出力専用で、`solver-output` とは宣言できない。この例の `criteria_sha256` は形式の系譜を示すもので、元の48物理ケースを実行したという意味ではない。コンパイラー、実行コマンド、ソース・出力SHAは例の `verification.json` に記録した。

CSVのヘッダーと列順は固定する。

```text
global_i,global_j,mode_i,mode_j,rho,rho_u,rho_v,energy
```

グローバル添字は0始まり。各所有セルの全モード `(0..p,0..p)` を同じランクが1回ずつ出力する。モード00がセル平均。ハロー・ゴーストセルは含めない。ファイル内の行順序、セルのランク割当て、ランクファイルの列挙順には依存しない。空のランクはヘッダーだけを出力できる。nodal DGからの移植では、外部コード側でこのLegendre係数へ変換してから渡す。

このスキーマは、初期・境界条件を実行コードが本当に適用したことを証明するものではない。入力・ソース・実行コマンドを別に記録し、計算時刻と出力形式を参照と一致させる。

## MPIで確認すること

実際のMPI計算では全ランクの出力完了を確認してからmanifestを確定する。全所有セルを再構成すると、欠落、重複したハロー、範囲外添字、ランクをまたいだセルのモード分割、非有限値を検出できる。ランク0のローカル配列だけを全体結果とみなさない。

比較はビット一致ではなく、各係数について `abs(actual-reference) <= atol + rtol*abs(reference)` とする。既定値は `atol=1e-11`、`rtol=1e-9`。MPIの加算順序による丸め差を許容するための**出力同等性の公差**であり、元の48物理ケースの合格基準は変更しない。実行時刻・格子・変数順・基底が違う場合は比較自体を拒否する。

全モードを比較するので、セル平均だけでは隠れる高次モードの破損も検出する。全領域の4保存量の積分差と、指定求積点・頂点の正値性も出力する。境界流束診断があれば、出力係数と最終積分の一致を確認し、流束補正後の保存誤差にはSHA固定した元の物理基準 `1e-9` を適用する。全モードが一致していても、この保存誤差が上限を超えれば不合格となり、入出力公差を広げても回避できない。診断ありは `conservation_checked=true`、任意診断なしは `false` と明示し、後者は境界流束の保存性を確認したことにはならない。開放境界や反射壁の問題を、単純な「全運動量一定」で判定しない。

## 使い方

保存済みv3配列を、1分割・4分割の新しい**模擬出力**へ変換する例。既存の履歴v2フィクスチャーを上書きしない。

```bash
python validation/rkdg/interchange.py export-fixture \
  outputs/rkdg-2026-11-23/accepted-v3/arrays/smooth-p2-n8.npz outputs/io-v3-serial
python validation/rkdg/interchange.py export-fixture \
  outputs/rkdg-2026-11-23/accepted-v3/arrays/smooth-p2-n8.npz outputs/io-v3-four --ranks 4 --shuffle
python validation/rkdg/interchange.py compare \
  outputs/io-v3-serial/manifest.json outputs/io-v3-four/manifest.json --output outputs/io-v3-verdict.json
```

他言語やMPIコードが同じ契約で実際に書き出した出力は、次のように固定参照出力と照合できる。

```bash
python validation/rkdg/interchange.py check-reference \
  outputs/rkdg-2026-11-23/accepted-v3/arrays/smooth-p2-n8.npz port-output/manifest.json \
  --output outputs/port-verdict.json
```

合格なら終了コード0、不一致や不正な出力なら1。Python APIは `load_run`、`compare_runs`、`compare_reference_manifest`、`entropy_metrics` を提供する。`entropy_metrics` は既存の独立な `modal_density_errors` を再利用し、移植後も密度L1・L2・求積点L∞を同じ定義で測れる。

1つの出力の同等性は、全ケースの物理的精度・収束の確認とは別である。正式な移植検証では全対象ケースを実行し、誤差・収束次数・保存収支・正値性の元の固定基準も適用する。新しいMPI実装を検証済みと示すには、実際の起動コマンド、ランク数、分割、通信環境と検査結果を追加する。
