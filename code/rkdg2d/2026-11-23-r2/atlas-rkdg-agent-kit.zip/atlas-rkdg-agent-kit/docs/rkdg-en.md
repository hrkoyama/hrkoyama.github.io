# 2D Euler RKDG: code assembly and verification against fixed tests

[日本語](rkdg.md)

This demonstration asks a user's AI agent to assemble Atlas-provided code and assess it with an independent, fixed evaluator. The example is a Runge–Kutta discontinuous Galerkin (RKDG) solver for the two-dimensional compressible Euler equations. It gives a concrete implementation, input set, reference set and evaluation record for the poster theme, “Building a numerical computation website usable by people and AI agents.”

The wider Atlas covers fluid dynamics and MHD, special/general relativistic hydrodynamics, particles and transport, molecular dynamics (MD) and thermostats, quantum chemistry and DFT, biological models, stochastic computation and foundational methods. RKDG is a demonstration within fluid dynamics. Breadth of catalog coverage does not imply equal implementation or validation depth in every field.

Current v3 uses TVB limiting in Euler characteristic amplitudes expressed in density units. Its source SHA256 is `4ed984a01c42fe9bb657c09c61361b086682d6aa611e9f478bf996c0b29b81d4`; the library and generated candidate contain the same source. On 23 November 2026, **all 48 original scientific cases and four supplemental waveform diagnostics on their saved arrays passed**. One deliberately faulty y-flux implementation was rejected by the same fixed criteria. Consult the [v3 measured metrics](../outputs/rkdg-2026-11-23/accepted-v3/metrics.json), [original-criteria verdict](../outputs/rkdg-2026-11-23/accepted-v3/verdict.json), [supplemental waveform verdict](../outputs/rkdg-2026-11-23/resolution-v3.json) and [measured summary with limits](../outputs/rkdg-2026-11-23/scientific-summary-v3.json), together with the evaluated source SHA.

The v3 last 32²→64² density L2 orders were 2.001, 2.975 and 4.009 for p1, p2 and p3. Finest-grid Sod/Shu–Osher transverse deviations and coordinate-swapped full-modal differences were zero. Double Mach Ny=32 relative density L1 differences were 1.242%, 1.266% and 1.252%. The maximum boundary-flux-adjusted normalized conservation defect was 4.47×10⁻¹⁴. [195 structural/regression checks](../outputs/rkdg-2026-11-23/final-test-summary-v3.json) and [147 RKDG checks in the minimal distribution environment](../outputs/rkdg-2026-11-23/distribution-staging-pytest-v3.log) also passed. These test counts are not additional PDE runs to add to the 48 scientific cases.

Historical v2, source SHA256 `8b02652a2a0ad3266e234382038dee2137acb3b969d93fa8b06ccbe36a4c11df`, passed all 48 original scientific cases on 23 November 2026 under unchanged criteria, and one deliberately faulty y-flux implementation was rejected for its measured accuracy failure. Its last 32²→64² density L2 orders were 2.001, 2.975 and 4.009 for p1, p2 and p3. Transverse and rotated-modal differences in the directional Sod/Shu–Osher cases were zero. Finest-grid Double Mach relative density L1 differences were 1.307%, 1.288% and 1.325%. Halving the time step gave error ratios 16.01 and 14.23. The 117 passed structural/regression checks also belong to that historical version. Its [measured metrics](../outputs/rkdg-2026-11-23/accepted/metrics.json), [fixed verdict](../outputs/rkdg-2026-11-23/accepted/verdict.json) and [then-current summary with limits](../outputs/rkdg-2026-11-23/scientific-summary.json) are preserved. However, v2 failed the subsequent post-shock wave-resolution diagnostics. Its original passing record is neither erased nor treated as sufficient current validation.

## Equations and polynomial space

Use \(\gamma=1.4\), conserved variables

\[
 U=(\rho,\rho u,\rho v,E)^T,\qquad
 E=\frac{p}{\gamma-1}+\frac12\rho(u^2+v^2),
\]

and \(U_t+F(U)_x+G(U)_y=0\). Each uniform Cartesian cell contains a tensor product of Legendre polynomials:

\[
 U_h(\xi,\eta)=\sum_{m=0}^{p}\sum_{n=0}^{p}
 \widehat U_{mn}P_m(\xi)P_n(\eta),\qquad (\xi,\eta)\in[-1,1]^2.
\]

The labels p1, p2 and p3 mean **\(Q_1,Q_2,Q_3\)** here, with 4, 9 and 16 modes per conserved variable. They do not denote the total-degree \(P_p\) space, which restricts \(m+n\le p\). The zeroth coefficient \(\widehat U_{00}\) is the cell average. Modifying only nonconstant modes therefore preserves that average.

Integration by parts gives the cellwise weak form

\[
 \frac{d}{dt}\int_K U_h\phi\,dA
 =\int_K\{F(U_h)\phi_x+G(U_h)\phi_y\}\,dA
  -\int_{\partial K}\widehat F_n\phi\,ds.
\]

The solver assembles the x and y residuals together, without dimensional splitting, using HLL numerical face fluxes. Volume and face quadratures use at least p+2 Gauss points in each relevant direction. This overintegration exceeds the requirement for simple basis products; it does not integrate a general nonlinear Euler flux exactly, because that flux is not a polynomial in conserved variables. See [Cockburn–Shu (1998)](https://doi.org/10.1006/jcph.1998.5892) for multidimensional RKDG formulation and implementation.

The repaired demonstration candidate is [generated/rkdg2d.py](../agent-kits/rkdg2d/generated/rkdg2d.py), with identical source integrated into the library's [numart/rkdg2d.py](../numart/rkdg2d.py). The independent evaluator is [validation/rkdg/evaluate.py](../validation/rkdg/evaluate.py). The analytic reduction for exactly one-dimensional data is disclosed below.

HLL replaces the region between the two outer signal speeds with one intermediate state and does not independently restore the contact wave. Contact and shear layers can consequently be numerically broadened. These results characterize HLL together with the limiter described below. See [Harten, Lax and van Leer (1983)](https://doi.org/10.1137/1025002) for the flux and [Toro, Spruce and Speares (1994)](https://doi.org/10.1007/BF01414629) for contact-wave restoration.

## Time integration, shock limiting and the positivity claim

Time integration uses the five-stage, fourth-order SSPRK(5,4) scheme with coefficients from [Spiteri–Ruuth (2002)](https://doi.org/10.1137/S0036142901389025). Limiting is applied after every stage. Time-dependent Double Mach boundaries are evaluated at the corresponding actual stage times. The outward boundary flux is integrated with the same Runge–Kutta weights as the state update.

With sound speed \(c=\sqrt{\gamma p/\rho}\), the time-step controller uses

\[
 \Delta t\le\frac{C}{(2p+1)
 \max_s\{(|u_s|+c_s)/\Delta x+(|v_s|+c_s)/\Delta y\}},
\]

where s ranges over the declared check points. The main campaign uses C=0.2; a separate `dt_max` cap enables temporal refinement. This choice and the measured positivity diagnostics are implementation-specific evidence, not a stability theorem for arbitrary data.

The smooth convergence tests disable the TVB shock limiter. Current v3 shock tests apply TVB/minmod detection in local Euler characteristic amplitudes, using the cell-average state, in both the reduced 1D and full 2D operators. The TVB parameter is M=100. Acoustic, entropy and shear amplitudes are expressed in common density units, with a threshold Mh² in each normal direction.

Let uₙ and uₜ be normal and tangential velocity, c the sound speed, and δρ, δmₙ, δmₜ and δE a conserved-variable difference. The implemented local linearization is

\[
 \delta p=(\gamma-1)\{\delta E-u_n\delta m_n-u_t\delta m_t
                +\tfrac12(u_n^2+u_t^2)\delta\rho\},
\]

\[
 a_{\pm}=\tfrac12\left\{\frac{\delta p}{c^2}
                  \pm\frac{\delta m_n-u_n\delta\rho}{c}\right\},\quad
 a_0=\delta\rho-\frac{\delta p}{c^2},\quad
 a_s=\frac{\delta m_t-u_t\delta\rho}{c}.
\]

Face-mean deviations and neighbor-average differences are compared in these amplitudes. Only troubled cells are reduced to limited linear polynomials, preserving their conserved averages. For a y-normal face the momentum components are exchanged before using the same transform. A p2 or p3 calculation therefore does not retain a high-degree polynomial in every shocked cell.

The former componentwise detector applied the same numerical TVB threshold to density, momentum and energy. These components have different units and different magnitudes for an entropy perturbation. Momentum/energy components could therefore trigger repeated limiting even when pressure was smooth, strongly damping the Shu–Osher density waves. Characteristic detection addresses this bias; it does not disable limiting of pressure/acoustic shocks. The HLL flux and SSPRK(5,4) method are unchanged.

When sampled density or pressure falls below the check threshold, higher modes are scaled toward the cell average. The design follows the average-preserving scaling idea of [Zhang–Shu (2010)](https://doi.org/10.1016/j.jcp.2010.08.016). The implementation directly checks the specified volume Gauss nodes, face Gauss nodes and cell corners. **It does not claim positivity at every continuous point in a cell or satisfaction of every sufficient condition of the original theorem.** A nonphysical cell average causes a time-step retry with half the step, not a density or energy floor that hides the failure.

## Smooth diagonal transport: what establishes orders two, three and four?

On the periodic unit square, evolve the exact Euler entropy wave

\[
 \rho(x,y,t)=1+0.2\sin\{2\pi(x+y-1.5t)\},
 \quad u=1,\quad v=0.5,\quad p=1
\]

to t=0.2. This passes four conserved variables through the same 2D Euler DG implementation rather than a separate scalar-advection path. Both velocity and wavevector have two nonzero components, so a missing or incorrectly signed y residual affects the test.

Run every degree on 8², 16², 32² and 64² cells. The evaluator does not call the candidate's reconstruction routine. It independently reconstructs density from the saved Legendre coefficients and compares with the analytic solution at at least 2p+4 Gauss points per direction. Convergence is not inferred solely from cell averages.

\[
 e_1=\frac1{|\Omega|}\int_\Omega|\rho_h-\rho|\,dA,\qquad
 e_2=\left[\frac1{|\Omega|}\int_\Omega|\rho_h-\rho|^2\,dA\right]^{1/2},
 \qquad q_{\rm obs}=\log_2\frac{e(h)}{e(h/2)}.
\]

L∞ is the largest error at evaluation nodes, not a certified continuous supremum. The frozen rules require errors to decrease at every refinement and the final two observed-order pairs to exceed p+1−0.35 for L1/L2 and p+1−0.6 for sampled L∞. The target spatial orders for p1, p2 and p3 are two, three and four; these targets must not be presented as measured orders before the campaign finishes.

V3 errors decreased at every level. The last 32²→64² orders for p1,p2,p3 were 2.007,2.982,4.013 in L1; 2.001,2.975,4.009 in L2; and 1.987,2.976,3.940 in sampled L∞. The p3/64² density L2 error was 4.659×10⁻⁹. These are measurements for the specified smooth entropy wave and settings.

A separate p3 study fixes the spatial grid at 16² and t=0.2. It compares \(\Delta t_0=0.2/192\), half and quarter that step with the same-spatial-grid solution at one eighth the base step. The runner checks that the specified cap actually controls the step. Successive L2 differences must decrease by at least a factor of eight. These are differences from a finer temporal solution, not exact temporal errors.

The measured v3 L2 difference ratios were 16.006 and 14.234, corresponding to base-two logarithms of 4.001 and 3.831.

## Sod and Shu–Osher: the exact 1D invariant subspace

Embed each one-dimensional problem in the same 2D solver, using 128 and 256 cells in the varying direction and two cells across it. Swap coordinates, momentum components and modal indices between the x and y versions. Check transverse modal constancy as well as cell averages.

For periodic or outflow boundaries, the repaired candidate projects initial samples that are **exactly identical** in the transverse direction using their analytically zero inactive Legendre moments. During evolution, reduction is enabled only when every nonconstant transverse mode is exactly zero and every transverse cell has exactly identical coefficients. A shared orientation-neutral 1D weak-DG/HLL operator, TVB limiter, positivity limiter and time-step calculation then evolve that invariant subspace. Using the same normal-coordinate operations in x and y prevents orientation-dependent floating-point residue from seeding a nonexistent transverse perturbation.

This is not an amplitude filter that discards sufficiently small perturbations. An explicitly nonzero transverse modal coefficient of even 1e−30 prevents the reduction and stays in the full 2D operator. Double Mach boundaries always disable reduction, and the oblique entropy wave also takes the full 2D path. Thus **the x/y one-dimensional problems test the analytic reduction and directional symmetry; oblique entropy transport and Double Mach test multidimensional coupling.** Results from the reduced 1D branch alone must not be presented as validation of the entire full-2D operator.

- **Sod, t=0.2:** use the standard [Sod (1978)](https://doi.org/10.1016/0021-9991(78)90023-2) shock tube on [0,1], divided at 0.5. Left and right primitive states are (ρ,uₙ,p)=(1,0,1) and (0.125,0,0.1). Compare with conserved cell averages obtained by quadrature of the exact Riemann solution.
- **Shu–Osher, t=1.8:** the varying coordinate spans [-5,5], divided at −4. The left state is (ρ,uₙ,p)=(3.857143,2.629369,10.33333); on the right, ρ=1+0.2 sin(5xₙ), uₙ=0 and p=1. Compare with an independently implemented conservative FV WENO5-JS/HLLC/SSPRK3 reference on 3200 cells. The shock–density-wave interaction originates in [Shu–Osher (1989)](https://doi.org/10.1016/0021-9991(89)90222-2).

Relative density L1 means \(\sum|\bar\rho_h-\bar\rho_{ref}|/\sum|\bar\rho_{ref}|\). Reference cell averages on different grids are transferred by conservative geometric overlap, not point-value interpolation. Frozen finest-grid limits are 0.08 for Sod and 0.15 for Shu–Osher; the finer error may be at most 1.1 times the coarser error. Transverse variation and the coordinate-swapped x/y difference must be no larger than 1e−10.

Measured v3 relative L1 values on 256 cells, in p1,p2,p3 order, were 0.2119%,0.1863%,0.1890% for Sod and 1.1232%,0.6253%,0.6663% for Shu–Osher. The x and y results matched, with zero transverse-modal deviation and zero coordinate-swapped full-modal difference. For discontinuous problems with limiting, increasing p is not claimed to decrease this full-domain error monotonically.

No second-, third- or fourth-order full-domain convergence is demanded across discontinuities. These tests assess shock/contact representation, post-shock density waves, positivity and directional consistency. DG Gauss projection and the reference's cell-average initialization can represent a cut discontinuity differently; that finite-grid initialization difference is part of the comparison error.

## Shu–Osher wave resolution beyond global L1

Although v2 passed the original 48 cases, subsequent plots showed strong damping of post-shock density waves. In the fixed normal-coordinate ROI=[1.2,2.2], at t=1.8 on 256 cells, p2 had a standard-deviation ratio of 0.3574 and correlation 0.5998; p3 had 0.3602 and 0.5937. The [v2 supplemental report](../outputs/rkdg-2026-11-23/resolution-v2.json) is preserved as a failure. A small global density L1 error does not establish resolution of high-frequency waveform structure.

The [resolution-acceptance.json](../validation/rkdg/resolution-acceptance.json) was therefore frozen before improved-candidate pilots, with SHA256 `275c7ffc386bc4cc791148b498e3872e9a67398f2a175bd3ae9a418559cf63c3`. It neither replaces the original 48-case criteria nor rewrites their passing history. Four supplemental diagnostics reuse the saved p2/p3, x/y, 256-cell outputs at t=1.8. The 3200-cell reference averages are conservatively remapped to the candidate grid, and matching cells whose centers lie in the fixed ROI are selected.

- ROI relative density L1 difference no larger than 0.08.
- Standard-deviation ratio σ_candidate/σ_reference at least 0.5, after subtracting each profile's own mean.
- Pearson correlation of the same demeaned profiles at least 0.8.

The standard-deviation ratio includes local spatial trend in the ROI; it is not a single Fourier-mode amplitude ratio. A waveform can retain correlation while losing amplitude, or retain amplitude while shifting phase. Relative L1, fluctuation magnitude and correlation are therefore assessed together.

Componentwise-limiter pilots with M=100,1000,2000 all failed the supplemental criteria. The thresholds were not relaxed; the implementation was changed to characteristic limiting. Following limited pilots, the complete v3 fixed campaign finished, and the supplemental evaluator assessed saved arrays bound to that same source SHA. **All four p2/p3, x/y waveform diagnostics passed.**

Final M=100 characteristic results were ROI relative L1=0.02370, standard-deviation ratio 0.8015 and correlation 0.9961 for p2; p3 gave 0.02410, 0.8129 and 0.9930. The x and y values matched for each degree. The ROI contains 25 cells with centers between 1.23046875 and 2.16796875. Its standard deviation remains about 80–81% of the reference, rather than matching the waveform perfectly. These are four supplemental diagnostics on existing PDE runs, not four additional PDE runs. The [final waveform verdict](../outputs/rkdg-2026-11-23/resolution-v3.json) is preserved alongside the failed v2 report.

## Double Mach reflection: broad-structure comparison

Compute the [Woodward–Colella (1984)](https://doi.org/10.1016/0021-9991(84)90142-6) Mach-10, 60° oblique shock on [0,4]×[0,1] to t=0.2. See the [NASA LAVA setup](https://nas.nasa.gov/LAVA/unst_docs/tutorials/double_mach/double_mach/) and the existing [Double Mach explanation](double-mach.md) for the standard geometry. Post-shock and pre-shock primitive states are (8,8.25√3/2,−4.125,116.5) and (1.4,0,0,1). The left boundary supplies post-shock inflow, the right is outflow, the bottom supplies post-shock data for x<1/6 and a reflecting wall elsewhere, and the top switches at \(x_s(1,t)=1/6+(1+20t)/\sqrt3\).

For each degree, use Ny=16,24,32 and Nx=4Ny, comparing conserved cell-average density with an independent unsplit FV MUSCL/HLL/SSPRK2 solution at Ny=128. A separately generated Ny=64 reference quantifies reference grid change. The fixed limits are 0.30 for finest-grid relative density L1, 1.15 for its fine/coarse error ratio, and 0.15 for the reference grid difference.

Measured v3 Ny=32 relative density L1 differences were 1.242%,1.266%,1.252% for p1,p2,p3, versus about 0.955% grid change within the independent reference itself. All nine cases passed the fixed criteria. However, sampled pressure reached small values, about 2.88×10⁻¹¹ in the finest p2 case. Passing the positivity check does not establish precise local pressure.

This checks shock placement and the broad density field on modest grids. It does not establish agreement of small wall-jet roll-ups, reproduction of a high-resolution PPM figure, DNS quality or high-order convergence across shocks. The FV reference classifies initial cells by shock-side at their centers, while DG projects values at Gauss points. Initial cut-cell representation consequently differs as well.

## Conservation and independent-reference uncertainty

Open boundaries allow total mass, momentum and energy to change. For each conserved component evaluate

\[
 R=I_{final}-I_{initial}+\int_0^T\int_{\partial\Omega}\widehat F_n\,ds\,dt.
\]

Normalize componentwise by max(1, |I_initial|, |I_final|, |boundary integral|) and require the maximum residual to be at most 1e−9. Boundary integration uses exactly the accepted RK stage weights.

Completed independent-reference grid differences are saved in [quality.json](../validation/rkdg/references/quality.json). After conservative restriction of the fine solution, relative density L1 differences are 0.000995136 (about 0.0995%) for Shu–Osher 1600→3200 and 0.00955251 (about 0.955%) for Double Mach Ny=64→128. These are differences between references, not candidate DG errors or passed DG tests. Maximum point differences near shocks remain about 0.272 and 4.43 respectively; these references are not precise truth at every continuous point. The code, fixed inputs, environment and array hashes are available in [reference.py](../validation/rkdg/reference.py), the [reference definition](../validation/rkdg/references/definition.json) and the JSON beside each array.

## What does the AI agent develop?

This demonstration does not ask an agent to invent an arbitrary CFD solver from scratch. An Atlas starter supplies the DG spatial operator, limiters and input/output contract. A separate AI agent implements the missing `_step` using SSPRK(5,4). This bounded assembly requires actual stage updates, nonautonomous boundary times and boundary-flux weights, rather than a parameter change.

When fixed tests or measured plots reveal an implementation issue, the allowed repair scope is explicitly expanded and the task returns to the same agent. This development path includes initial assembly, an endpoint-roundoff repair, the exact-1D invariant subspace and a change from componentwise to Euler-characteristic limiting. It is an iterative development demonstration; failed attempts must not disappear into a claim of successful one-shot generation. New waveform diagnostics are added as separate frozen criteria rather than retroactively rewriting the original rules.

The instructions are in [AGENT-TASK.txt](../agent-kits/rkdg2d/AGENT-TASK.txt), and the candidate is [generated/rkdg2d.py](../agent-kits/rkdg2d/generated/rkdg2d.py). The evaluator, reference arrays and acceptance rules stay outside the agent's allowed edit scope. Preserve starting and ending hashes, actual instructions, source diff, environment and failure reasons. Do not relax criteria to fit the candidate's measurements.

The [acceptance.json](../validation/rkdg/acceptance.json) frozen before candidate measurements has SHA256 `7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af`. The evaluator pins that value and rejects changed criteria. The recorded candidate and reference-array hashes bind the measurements to their actual inputs. Having all files present is distinct from passing the scientific acceptance rules.

A separate negative control reverses the sign of the y flux and actually runs that faulty implementation against the same smooth-solution criteria. Merely writing `rejected=true` is not evidence. Save the mutant source, measured errors and rejection reasons so that the evaluator can recompute the verdict from the measurements.

## Observed failures and repairs

An early lightweight Double Mach check accepted three time steps and then left an 8.674e−19 remainder before the final time. Attempting an unnecessary tiny step raised `Time step underflow`. The repair aligns the reported time with the requested endpoint only after an accepted step and only when the remainder is no larger than 4ε max(1, |final time|). It does not discard a meaningful step or alter a conserved state. The actual input and repaired smoke checks are recorded in [assembly-notes.txt](../agent-kits/rkdg2d/generated/assembly-notes.txt).

The first full attempt subsequently stopped on Sod p1 with 256 cells. Its transverse variation, 4.0601e−10, and coordinate-swapped full-modal difference, 9.7778e−10, exceeded the unchanged 1e−10 limit. The [first-attempt stop record](../outputs/rkdg-2026-11-23/attempt-1-status.json) is preserved as a failure. Those measurements are not reclassified as a pass, and the limit is not relaxed.

That repair introduced analytic projection of exactly one-dimensional data and the common orientation-neutral 1D reduction. An individual comparison with the original tensor 2D operator found a maximum difference of about 9.2e−14, and repaired Sod p1/256-cell checks measured zero transverse variation and zero x/y difference. The subsequent v2 passed the original 48 cases, but the supplemental diagnostics exposed insufficient wave resolution. V3 preserves that history while revising the limiter and has passed all 48 original cases plus the four waveform diagnostics under its new source SHA. This success is limited to the fixed inputs and declared validation scope.

## Carrying verification to language ports and MPI

The [common output contract and checker](rkdg-interchange-en.md) ([日本語](rkdg-interchange.md)) compare the same conserved variables, Legendre modes and reference arrays after a C++, Fortran, Julia or other language port, or after MPI decomposition. Implemented checks reconstruct output, validate owned-cell completeness and compare numerical arrays. They have been exercised with saved-array fixtures partitioned into 1,2,4 files. **Those checks did not launch MPI or execute a foreign-language Euler solver.**

The C++17 analytic modal-output writer was actually compiled and run. It matched an independent Python reference with maximum coefficient difference 3.47×10⁻¹⁸ and zero global-integral difference; see the [I/O verification record](../agent-kits/rkdg2d/interchange-example/cpp-io/verification.json). This is separate from a numerical solver assessment. I/O round-trip equivalence, foreign-language PDE execution and actual MPI execution require separate verification states. A successful writer check must not be labeled a verified C++ RKDG or MPI implementation.

## Reproduction commands

Run from the repository root with Python, `numpy` and `pytest`. If `.venv` does not exist, create it with `python -m venv .venv`, then install with `.venv/bin/python -m pip install -e '.[test]'`.

```bash
.venv/bin/python -m pytest -q \
  tests/test_rkdg2d.py tests/test_rkdg_invariance.py \
  tests/test_rkdg_characteristic.py tests/test_rkdg_references.py \
  tests/test_rkdg_evaluator.py tests/test_rkdg_resolution.py \
  tests/test_rkdg_interchange.py

.venv/bin/python scripts/run_rkdg_campaign.py \
  --solver agent-kits/rkdg2d/generated/rkdg2d.py \
  --output outputs/rkdg-reproduction

.venv/bin/python scripts/run_rkdg_negative_control.py \
  --solver agent-kits/rkdg2d/generated/rkdg2d.py \
  --campaign outputs/rkdg-reproduction \
  --output outputs/rkdg-reproduction/negative-control

.venv/bin/python validation/rkdg/evaluate.py \
  outputs/rkdg-reproduction/metrics.json \
  --solver agent-kits/rkdg2d/generated/rkdg2d.py \
  --output outputs/rkdg-reproduction/verdict.json

.venv/bin/python validation/rkdg/resolution.py \
  --campaign outputs/rkdg-reproduction \
  --solver agent-kits/rkdg2d/generated/rkdg2d.py \
  --output outputs/rkdg-reproduction/resolution-verdict.json
```

A normal reproduction verifies and uses the saved independent references. To regenerate a reference itself, for example use `.venv/bin/python -m validation.rkdg.reference shu-osher --n 3200 --output outputs/rkdg-reference-reproduction/shu-osher-n3200.npz`. Compare arrays and conservation residuals without overwriting the frozen data. `double-mach --n 128` uses the same entry point.

The campaign evaluates 48 scientific cases: 12 smooth, 24 directional, nine Double Mach and three temporal-refinement comparisons, saving coefficients, inputs, diagnostics and hashes. The preserved v3 results passed those 48 cases plus four supplemental waveform diagnostics, but **a new reproduction requires its own measured verdict**. Check exit code zero for both the original evaluator and supplemental diagnostics, with complete `verdict.json` and `resolution-verdict.json` files. A partial run, interruption or cache from an older implementation must not be counted as success.

## Primary references

- [Sod (1978), JCP 27, 1–31](https://doi.org/10.1016/0021-9991(78)90023-2): shock tubes and exact-solution comparisons.
- [Harten, Lax & van Leer (1983), SIAM Review 25, 35–61](https://doi.org/10.1137/1025002): the HLL approximate Riemann solver.
- [Woodward & Colella (1984), JCP 54, 115–173](https://doi.org/10.1016/0021-9991(84)90142-6): two-dimensional strong-shock benchmarks.
- [Shu & Osher (1989), JCP 83, 32–78](https://doi.org/10.1016/0021-9991(89)90222-2): shock capturing and shock–density-wave interaction.
- [Toro, Spruce & Speares (1994), Shock Waves 4, 25–34](https://doi.org/10.1007/BF01414629): HLLC contact restoration, used by the independent Shu–Osher reference.
- [Jiang & Shu (1996), JCP 126, 202–228](https://doi.org/10.1006/jcph.1996.0130): WENO smoothness indicators used by the independent FV reference.
- [Cockburn & Shu (1998), JCP 141, 199–224](https://doi.org/10.1006/jcph.1998.5892): multidimensional RKDG formulation and implementation.
- [Spiteri & Ruuth (2002), SINUM 40, 469–491](https://doi.org/10.1137/S0036142901389025): five-stage, fourth-order SSP time integration.
- [Zhang & Shu (2010), JCP 229, 8918–8934](https://doi.org/10.1016/j.jcp.2010.08.016): background for average-preserving Euler positivity limiting. An [author manuscript](https://www.math.purdue.edu/~zhan1966/research/paper/euler.pdf) is also available.
