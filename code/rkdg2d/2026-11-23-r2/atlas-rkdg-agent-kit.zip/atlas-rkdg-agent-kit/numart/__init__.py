"""Minimal Atlas RKDG demonstration distribution."""
