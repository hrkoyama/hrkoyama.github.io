#!/usr/bin/env python3
"""Plot actual saved RKDG campaign data; never run or modify a solver.

The default command requires all plotted cases and their measured metric rows.
Use --figures to render a completed section while other sections are running.
PNG files use 200 dpi by default. --pdf also writes vector scientific PDFs.
Figures are evidence views, not independent statements that a campaign passed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

COLORS = {1: '#1764a4', 2: '#d37313', 3: '#23816a'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def required_cases(figures):
    names = []
    if 'convergence' in figures:
        names.extend(f'smooth-p{p}-n{n}' for p in (1, 2, 3) for n in (8, 16, 32, 64))
    if 'directional' in figures:
        names.extend(f'{problem}-p{p}-a0-n256'
                     for problem in ('sod', 'shu-osher') for p in (1, 2, 3))
        names.extend(f'{problem}-p3-a1-n256' for problem in ('sod', 'shu-osher'))
    if 'double-mach' in figures:
        names.append('double-mach-p3-ny32')
    return names


class FigureData:
    def __init__(self, args):
        self.args = args
        self.campaign = args.campaign.resolve()
        self.metrics_path = self.campaign/'metrics.json'
        self.metrics = json.loads(self.metrics_path.read_text())
        actual_sha = digest(args.solver)
        if self.metrics.get('solver_sha256') != actual_sha:
            raise ValueError('Saved metrics belong to a different candidate SHA')
        self.solver_sha = actual_sha
        self.provenance = {'metrics.json': digest(self.metrics_path),
                           str(args.solver.resolve().relative_to(ROOT)): actual_sha}
        self.arrays = {}
        missing = [name for name in required_cases(args.figures)
                   if not (self.campaign/'arrays'/(name+'.npz')).exists()]
        if missing:
            raise ValueError('Required measured cases are not yet present: '+', '.join(missing))
        for name in required_cases(args.figures):
            path = self.campaign/'arrays'/(name+'.npz')
            with np.load(path) as data:
                self.arrays[name] = {k: data[k].copy() for k in data.files}
            self.provenance['arrays/'+name+'.npz'] = digest(path)
            item = self.arrays[name]
            item['config'] = json.loads(str(item['config']))
            item['diagnostics'] = json.loads(str(item['diagnostics']))
            config, q, coeff = item['config'], item['q'], item['coeff']
            if q.shape != (config['nx'], config['ny'], 4):
                raise ValueError('Unexpected cell-average shape in '+name)
            if coeff.shape != q.shape[:2]+(config['degree']+1, config['degree']+1, 4):
                raise ValueError('Unexpected modal shape in '+name)
            if not np.all(np.isfinite(coeff)) or not np.array_equal(q, coeff[:, :, 0, 0]):
                raise ValueError('Nonfinite or inconsistent saved data in '+name)
            if not np.isclose(item['diagnostics']['final_time'], config['time'], rtol=0., atol=1e-14):
                raise ValueError('Incomplete final time in '+name)
        self.references = {}
        if 'directional' in args.figures:
            self.references['shu-osher'] = self.load_reference('shu-osher-n3200.npz')
        if 'double-mach' in args.figures:
            self.references['double-mach'] = self.load_reference('double-mach-ny128.npz')

    def load_reference(self, name):
        path = self.args.references/name
        measured_sha = self.metrics.get('reference_sha256', {}).get(name)
        if measured_sha != digest(path):
            raise ValueError('Reference is not bound to measured metrics: '+name)
        self.provenance['references/'+name] = measured_sha
        with np.load(path) as data:
            return {k: data[k].copy() for k in data.files}

    def row(self, section, **keys):
        rows = [r for r in self.metrics[section]
                if all(r.get(k) == v for k, v in keys.items())]
        if len(rows) != 1:
            raise ValueError('Missing or duplicate measured metric row: '+str((section, keys)))
        return rows[0]


def save_figure(fig, name, args):
    args.output.mkdir(parents=True, exist_ok=True)
    files = []
    for suffix in ('.png', '.pdf') if args.pdf else ('.png',):
        path = args.output/(name+suffix)
        fig.savefig(path, dpi=args.dpi, facecolor='white',
                    metadata={'Creator': 'Numerical Methods Atlas measured RKDG campaign'}
                    if suffix == '.pdf' else None)
        files.append({'path': str(path.resolve()), 'sha256': digest(path),
                      'bytes': path.stat().st_size})
    return files


def convergence(data, plt, args):
    from matplotlib.ticker import ScalarFormatter, NullLocator, NullFormatter
    from validation.rkdg.evaluate import modal_density_errors
    fig, axes = plt.subplots(1, 3, figsize=(12, 5))
    fig.subplots_adjust(left=.085, right=.985, bottom=.20, top=.70, wspace=.30)
    norms = (('l1', r'$L_1$'), ('l2', r'$L_2$'), ('linf', r'$L_\infty$ (sampled)'))
    observed = {}
    ns = np.array((8, 16, 32, 64))

    def exact_density(x, y, t):
        return 1+.2*np.sin(2*np.pi*(x+y-1.5*t))

    for p in (1, 2, 3):
        rows = [data.row('smooth', p=p, n=int(n)) for n in ns]
        for n, row in zip(ns, rows):
            raw = data.arrays[f'smooth-p{p}-n{n}']
            calculated = modal_density_errors(raw['coeff'], exact_density, time=.2)
            for norm, _ in norms:
                if not np.isclose(calculated[norm], row['errors'][norm], rtol=1e-10, atol=1e-14):
                    raise ValueError('Measured smooth errors disagree with saved coefficients')
        observed[str(p)] = {}
        for ax, (norm, label) in zip(axes, norms):
            errors = np.array([r['errors'][norm] for r in rows])
            if not np.all(np.isfinite(errors)) or np.any(errors <= 0):
                raise ValueError('Convergence plot requires measured positive finite errors')
            qobs = float(np.log2(errors[-2]/errors[-1]))
            observed[str(p)][norm] = qobs
            ax.loglog(ns, errors, 'o-', color=COLORS[p], linewidth=2.2, markersize=6,
                      label=fr'$Q_{p}$')
            ax.set_xticks(ns)
            ax.xaxis.set_major_formatter(ScalarFormatter())
            ax.xaxis.set_minor_locator(NullLocator())
            ax.xaxis.set_minor_formatter(NullFormatter())
            ax.set_xlabel('Cells per direction, N')
            ax.grid(True, which='both', alpha=.20)
    for ax, (norm, label) in zip(axes, norms):
        orders = ' / '.join(f'{observed[str(p)][norm]:.2f}' for p in (1, 2, 3))
        ax.set_title(label+'\n'+r'$q_{obs}$: '+orders, fontsize=13)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(.5, .89),
               ncol=3, fontsize=14, frameon=False)
    axes[0].set_ylabel('Reconstructed density error')
    fig.suptitle('Oblique Euler entropy wave, t = 0.2\nTensor DG / HLL / SSPRK(5,4)', fontsize=16)
    fig.text(.5, .045, r'$q_{obs}=\log_2(e_{32}/e_{64})$; independently reconstructed density and quadrature; sampled $L_\infty$',
             ha='center', fontsize=14)
    outputs = save_figure(fig, 'convergence', args)
    plt.close(fig)
    return outputs, {'observed_last_pair_orders': observed,
                     'caption': 'Measured errors, not nominal-order guide lines; all three norms from saved candidate coefficients.'}


def directional(data, plt, args):
    from numart.riemann import exact_euler
    fig, axes = plt.subplots(1, 2, figsize=(12, 3.5))
    fig.subplots_adjust(left=.085, right=.985, bottom=.30, top=.82, wspace=.23)
    row_data = {}
    for ax, problem, end in zip(axes, ('sod', 'shu-osher'), (.2, 1.8)):
        if problem == 'sod':
            xref = np.linspace(0., 1., 4096)
            rhoref = exact_euler((xref-.5)/end)[:, 0]
            reference_label = 'Exact Riemann density'
        else:
            ref = data.references['shu-osher']
            xref = .5*(ref['x_edges'][1:]+ref['x_edges'][:-1])
            rhoref = ref['q'][:, 0]
            reference_label = 'Independent FV, 3200 cells'
        ax.plot(xref, rhoref, color='#262626', linewidth=1.6, alpha=.85,
                label=reference_label, zorder=1)
        row_data[problem] = {}
        for p in (1, 2, 3):
            raw = data.arrays[f'{problem}-p{p}-a0-n256']
            row = data.row('directional', problem=problem, p=p, axis=0, n=256)
            if row['time'] != end:
                raise ValueError('Unexpected directional metric time')
            x = .5*(raw['x_edges'][1:]+raw['x_edges'][:-1])
            density = raw['q'][..., 0].mean(axis=1)
            ax.plot(x, density, color=COLORS[p], linewidth=1.7, label=fr'$Q_{p}$, x direction')
            row_data[problem][str(p)] = {'x_relative_l1': row['error_l1']}
        raw_y = data.arrays[f'{problem}-p3-a1-n256']
        row_y = data.row('directional', problem=problem, p=3, axis=1, n=256)
        y = .5*(raw_y['y_edges'][1:]+raw_y['y_edges'][:-1])
        density_y = raw_y['q'][..., 0].mean(axis=0)
        ax.plot(y, density_y, linestyle='none', marker='o', markevery=8, markersize=4.5,
                markerfacecolor='none', markeredgecolor='#111111', markeredgewidth=1.,
                label=r'$Q_3$, y direction', zorder=5)
        row_data[problem]['3'].update(y_relative_l1=row_y['error_l1'],
                                      measured_axis_difference=row_y['axis_difference'])
        ax.set(xlabel='Normal coordinate', ylabel='Density',
               title=f'{"Sod" if problem == "sod" else "Shu–Osher"}, t = {end:g}; 256 × 2 cells')
        ax.set_xlim((0., 1.) if problem == 'sod' else (-5., 5.))
        ax.grid(alpha=.18)
    handles, _ = axes[0].get_legend_handles_labels()
    fig.legend(handles, ['Reference', r'$Q_1$, x', r'$Q_2$, x', r'$Q_3$, x', r'$Q_3$, y'],
               loc='upper center', bbox_to_anchor=(.5, .135), ncol=5, fontsize=12, frameon=False)
    fig.text(.5, .015, 'Cell averages; exact Sod / independent FV Shu–Osher reference. Open markers: y embedding (exact 1D reduction).',
             ha='center', fontsize=11)
    outputs = save_figure(fig, 'directional', args)
    plt.close(fig)
    return outputs, {'measured_directional_metrics': row_data,
                     'caption': 'Sod and Shu–Osher at the actual final times; Q3 y-direction values are plotted as open markers.'}


def double_mach(data, plt, args):
    from matplotlib.colors import Normalize
    raw = data.arrays['double-mach-p3-ny32']
    ref = data.references['double-mach']
    row = data.row('double_mach', p=3, ny=32)
    if not np.isclose(float(ref['time']), .2) or row['time'] != .2:
        raise ValueError('Double Mach final times must both be 0.2')
    fig, axes = plt.subplots(1, 2, figsize=(12, 3), sharex=True, sharey=True)
    fig.subplots_adjust(left=.055, right=.90, bottom=.22, top=.68, wspace=.18)
    norm = Normalize(vmin=1.4, vmax=22.)
    for ax, saved, label in zip(axes, (raw, ref),
              ('Candidate '+r'$Q_3$ RKDG / HLL'+'\n'+r'$128\times32$',
               'Independent FV MUSCL / HLL'+'\n'+r'$512\times128$')):
        q = saved['q']
        if not np.all(np.isfinite(q)):
            raise ValueError('Nonfinite Double Mach density')
        image = ax.pcolormesh(saved['x_edges'], saved['y_edges'], q[..., 0].T,
                              shading='flat', cmap='viridis', norm=norm)
        ax.set_aspect('equal', adjustable='box')
        ax.set(xlim=(0, 4), ylim=(0, 1), xlabel='x', ylabel='y', title=label)
        ax.title.set_fontsize(13)
    allrho = np.r_[raw['q'][..., 0].ravel(), ref['q'][..., 0].ravel()]
    lo, hi = bool(np.min(allrho) < 1.4), bool(np.max(allrho) > 22)
    extension = 'both' if lo and hi else 'min' if lo else 'max' if hi else 'neither'
    cax = fig.add_axes([.93, .26, .015, .40])
    bar = fig.colorbar(image, cax=cax, extend=extension)
    bar.set_label('Density')
    fig.suptitle('Double Mach reflection, t = 0.2 | common density scale; cell averages', fontsize=14)
    outputs = save_figure(fig, 'double-mach', args)
    plt.close(fig)
    return outputs, {'relative_l1': row['error_l1'],
                     'reference_grid_change_l1': row['reference_grid_change_l1'],
                     'density_color_limits': [1.4, 22.],
                     'actual_density_range': [float(allrho.min()), float(allrho.max())],
                     'caption': 'Broad shock-structure comparison at different actual grid resolutions; no fine-vortex or exact-solution claim.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, default=ROOT/'outputs/rkdg-2026-11-23/accepted-v3')
    parser.add_argument('--solver', type=Path, default=ROOT/'agent-kits/rkdg2d/generated/rkdg2d.py')
    parser.add_argument('--references', type=Path, default=ROOT/'validation/rkdg/references')
    parser.add_argument('--output', type=Path, default=ROOT/'outputs/rkdg-2026-11-23/figures-v3')
    parser.add_argument('--figures', '--only', nargs='+', choices=('convergence', 'directional', 'double-mach'),
                        default=('convergence', 'directional', 'double-mach'))
    parser.add_argument('--dpi', type=int, default=200)
    parser.add_argument('--pdf', action='store_true')
    args = parser.parse_args()
    if not 180 <= args.dpi <= 220:
        parser.error('Use 180–220 dpi for these scientific figures')
    data = FigureData(args)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 14,
                         'axes.titlesize': 15, 'axes.labelsize': 14,
                         'xtick.labelsize': 14, 'ytick.labelsize': 14,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'figure.facecolor': 'white', 'axes.facecolor': 'white',
                         'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.facecolor': 'white'})
    builders = {'convergence': convergence, 'directional': directional, 'double-mach': double_mach}
    manifest = {'schema_version': 1, 'candidate_sha256': data.solver_sha,
                'plot_script_sha256': digest(__file__), 'dpi': args.dpi,
                'matplotlib': matplotlib.__version__, 'numpy': np.__version__,
                'input_sha256': data.provenance, 'figures': {},
                'scope': 'Plots of actual saved measurements; verdict is determined separately by the frozen evaluator.'}
    for name in args.figures:
        paths, details = builders[name](data, plt, args)
        manifest['figures'][name] = dict(outputs=paths, **details)
        print(json.dumps({'figure': name, 'outputs': paths}), flush=True)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output/'figure-manifest.json').write_text(json.dumps(manifest, indent=2, allow_nan=False)+'\n')


if __name__ == '__main__':
    main()
