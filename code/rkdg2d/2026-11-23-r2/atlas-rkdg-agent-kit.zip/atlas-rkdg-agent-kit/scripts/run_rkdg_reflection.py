#!/usr/bin/env python3
"""Fresh reversed-x RKDG runs, compared with source-bound forward evidence.

The unchanged scientific48 suite remains separate. The additional reflection
criteria were frozen before these six runs. No stored solution is used as an
initial condition. Saved forward data are only read after fresh evolution.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.run_rkdg_campaign import load_module, physical_minima, normalized_conservation

CRITERIA=ROOT/'validation/rkdg/reflection-acceptance.json'
PINNED_CRITERIA='ab7986e1eaf768f63fb239bf5a8d766d4c4fc5778389bdc42b5eb294594bf18a'
SOLVER_SHA='4ed984a01c42fe9bb657c09c61361b086682d6aa611e9f478bf996c0b29b81d4'
ORIGINAL_SHA='7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path,value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_suffix(p.suffix+'.tmp')
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    temp.replace(p)


def reflect_coefficients(coeff):
    """Represent T U(xmin+xmax-x,y) in the original grid's Legendre basis.

    Reflection changes cell ordering, the parity of *x* modes and x momentum.
    This map is its own inverse. No density, energy or tangential-momentum sign
    changes and no y-axis reordering are applied.
    """
    a=np.asarray(coeff)
    if a.ndim!=5 or a.shape[-1]!=4 or a.shape[2]!=a.shape[3]:
        raise ValueError('Expected (nx,ny,p+1,p+1,4) modal Euler coefficients')
    result=np.array(a[::-1],copy=True)
    result*=((-1.)**np.arange(a.shape[2]))[None,None,:,None,None]
    result[...,1]*=-1
    return result


def scaled_modal_max(a,b):
    scale=np.maximum(1.,np.max(abs(b),axis=(0,1,2,3)))
    return float(np.max(abs(a-b)/scale))


def mirror_initial(initial,bounds):
    """Fresh reflected conservative callable; importantly reflects Shu's sine."""
    midpoint_sum=bounds[0]+bounds[1]
    def reflected(x,y):
        q=np.array(initial(midpoint_sum-x,y,axis=0),copy=True)
        q[...,1]*=-1
        return q
    return reflected


def check_bindings(solver,forward):
    if digest(CRITERIA)!=PINNED_CRITERIA:raise ValueError('Frozen reflection criteria changed')
    rules=read(CRITERIA)
    if digest(solver)!=SOLVER_SHA or rules['source_sha256']!=SOLVER_SHA:
        raise ValueError('Unexpected solver version')
    if digest(ROOT/'validation/rkdg/acceptance.json')!=ORIGINAL_SHA:
        raise ValueError('Original48 criteria changed')
    metrics=read(forward/'metrics.json');verdict=read(forward/'verdict.json')
    raw=read(forward/'raw-array-manifest.json')
    if not verdict['passed'] or metrics['solver_sha256']!=SOLVER_SHA or raw['source_bindings']['solver_sha256']!=SOLVER_SHA:
        raise ValueError('Forward evidence is incomplete or source-incompatible')
    ledger={x['path']:x['sha256'] for x in raw['files']}
    for problem in rules['problems']:
        for p in rules['degrees']:
            rel=f'arrays/{problem}-p{p}-a0-n256.npz'
            if digest(forward/rel)!=ledger.get(rel):raise ValueError('Forward raw array digest mismatch '+rel)
    return rules


def run_one(payload):
    problem,p,solver_path,forward_dir,out_dir,rules=payload
    solver_path,forward_dir,out_dir=map(Path,(solver_path,forward_dir,out_dir))
    if digest(solver_path)!=SOLVER_SHA:raise ValueError('Solver changed during launch')
    mod=load_module(solver_path);r=rules['problems'][problem]
    config=dict(nx=rules['nx'],ny=rules['ny'],degree=p,bounds=r['bounds'],
                boundary=rules['boundary'],limiter=rules['limiter'],time=r['time'],
                cfl=rules['cfl'],tvb=rules['tvb'])
    dg=mod.DG2D(**{k:v for k,v in config.items() if k not in ('time','cfl')})
    initial=getattr(mod,'sod' if problem=='sod' else 'shu_osher')
    q0=dg.project(mirror_initial(initial,r['bounds']))
    forward0=dg.project(lambda x,y:initial(x,y,axis=0))
    initial_diff=scaled_modal_max(reflect_coefficients(q0),forward0)
    times=[0.];stamp=time.perf_counter()
    result=dg.evolve(q0,final_time=config['time'],cfl=config['cfl'],callback=lambda t,q:times.append(float(t)))
    elapsed=time.perf_counter()-stamp
    diag=dict(result.diagnostics);diag.update(final_time=result.time,steps=result.steps,
        wall_seconds=elapsed,recorded_step_count=len(times)-1)
    mapped=reflect_coefficients(result.coeff)
    baseline=forward_dir/f'arrays/{problem}-p{p}-a0-n256.npz'
    with np.load(baseline,allow_pickle=False) as f:
        fc=np.array(f['coeff']);bc=json.loads(str(f['config']));fd=json.loads(str(f['diagnostics']))
        xedges=np.array(f['x_edges']);yedges=np.array(f['y_edges'])
    expected={k:v for k,v in config.items() if k!='tvb'}
    if expected!=bc or result.time!=config['time'] or abs(fd['final_time']-result.time)>1e-14:
        raise ValueError('Forward/reflected conditions differ')
    rho=mapped[:,:,0,0,0];ref=fc[:,:,0,0,0]
    limits=rules['limits'];minrho,minp=physical_minima(dg,result.coeff)
    row=dict(problem=problem,p=p,nx=rules['nx'],ny=rules['ny'],time=result.time,
        initial_scaled_modal_max=initial_diff,scaled_modal_max=scaled_modal_max(mapped,fc),
        modal_max_absolute_by_variable=np.max(abs(mapped-fc),axis=(0,1,2,3)).tolist(),
        density_average_relative_l1=float(np.sum(abs(rho-ref))/np.sum(abs(ref))),
        density_average_scaled_linf=float(np.max(abs(rho-ref))/max(1.,np.max(abs(ref)))),
        density_average_absolute_linf=float(np.max(abs(rho-ref))),
        normalized_boundary_flux_conservation=normalized_conservation(diag),
        min_sampled_density=minrho,min_sampled_pressure=minp,steps=result.steps,
        forward_steps=fd['steps'],wall_seconds=elapsed,
        forward_npz=str(baseline.relative_to(ROOT)),forward_npz_sha256=digest(baseline))
    failures=[]
    for name in ['initial_scaled_modal_max','scaled_modal_max','density_average_relative_l1',
                 'density_average_scaled_linf','normalized_boundary_flux_conservation']:
        if not np.isfinite(row[name]) or row[name]>limits[name]:failures.append(name+' exceeds frozen limit')
    if minrho<=0 or not np.isfinite(minrho):failures.append('nonpositive sampled density')
    if minp<=0 or not np.isfinite(minp):failures.append('nonpositive sampled pressure')
    if len(times)-1!=result.steps or np.any(np.diff(times)<=0):failures.append('invalid accepted-step history')
    array_path=out_dir/'arrays'/f'{problem}-p{p}-reverse-x-n256.npz'
    if array_path.exists():raise ValueError('Refuse to overwrite existing reversed run '+str(array_path))
    array_path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(array_path,initial_coeff=q0,coeff=result.coeff,mapped_coeff=mapped,
        q=result.q,x_edges=xedges,y_edges=yedges,step_times=np.array(times),
        config=json.dumps(config),diagnostics=json.dumps(diag),solver_sha256=SOLVER_SHA,
        criteria_sha256=PINNED_CRITERIA,runner_sha256=digest(__file__))
    row.update(passed=not failures,failures=failures,reverse_npz=str(array_path.relative_to(ROOT)),
               reverse_npz_sha256=digest(array_path),fresh_evolution_executed=True)
    return row


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--solver',type=Path,default=ROOT/'agent-kits/rkdg2d/generated/rkdg2d.py')
    parser.add_argument('--forward',type=Path,default=ROOT/'outputs/rkdg-2026-11-23/accepted-v3')
    parser.add_argument('--output',type=Path,default=ROOT/'outputs/rkdg-2026-11-23/x-reflection')
    parser.add_argument('--workers',type=int,default=3)
    args=parser.parse_args();args.solver=args.solver.resolve();args.forward=args.forward.resolve();args.output=args.output.resolve()
    rules=check_bindings(args.solver,args.forward)
    report=dict(schema_version=1,started_jst=datetime.now(timezone(timedelta(hours=9))).isoformat(),
        passed=False,criteria_sha256=PINNED_CRITERIA,original48_criteria_sha256=ORIGINAL_SHA,
        solver_sha256=SOLVER_SHA,runner_sha256=digest(__file__),
        forward_metrics_sha256=digest(args.forward/'metrics.json'),
        forward_raw_manifest_sha256=digest(args.forward/'raw-array-manifest.json'),
        support_sha256={str(p.relative_to(ROOT)):digest(p) for p in [ROOT/'scripts/run_rkdg_campaign.py',ROOT/'validation/rkdg/evaluate.py']},
        environment={'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'workers':args.workers},
        cases=[],scope=rules['scope'])
    write(args.output/'run-start.json',report)
    payloads=[(problem,p,str(args.solver),str(args.forward),str(args.output),rules)
              for problem in rules['problems'] for p in rules['degrees']]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for task in as_completed([pool.submit(run_one,p) for p in payloads]):
            row=task.result();report['cases'].append(row);report['cases'].sort(key=lambda x:(x['problem'],x['p']))
            write(args.output/'verdict.json',report)
            print(json.dumps(row),flush=True)
    report['passed']=len(report['cases'])==6 and all(x['passed'] for x in report['cases'])
    report['case_count']=len(report['cases']);report['all_fresh_evolutions']=all(x['fresh_evolution_executed'] for x in report['cases'])
    report['finished_jst']=datetime.now(timezone(timedelta(hours=9))).isoformat()
    if digest(args.solver)!=SOLVER_SHA or digest(CRITERIA)!=PINNED_CRITERIA or digest(ROOT/'validation/rkdg/acceptance.json')!=ORIGINAL_SHA:
        raise ValueError('Read-only numerical source or criteria changed')
    write(args.output/'verdict.json',report)
    return 0 if report['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
