#!/usr/bin/env python3
"""Inject a genuine y-flux sign error and apply the unchanged smooth criteria."""
import argparse
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_rkdg_campaign import Campaign, ROOT, digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--solver', required=True)
    parser.add_argument('--campaign', help='Attach the result to this completed campaign directory')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    source = Path(args.solver).read_text()
    needle = '        return f, un, np.sqrt(self.gamma*p/rho)'
    if source.count(needle) != 1:
        raise ValueError('Negative-control injection location changed; inspect source')
    mutant = source.replace(needle,
                            '        return (-f if axis == 1 else f), (-un if axis == 1 else un), np.sqrt(self.gamma*p/rho)')
    mutation = out/'wrong_y_flux.py'
    mutation.write_text(mutant)
    job = Campaign(SimpleNamespace(solver=str(mutation), output=str(out/'run'),
                                   references=str(ROOT/'validation/rkdg/references')))
    job.degrees = [1]
    job.smooth()
    from validation.rkdg.evaluate import evaluate_smooth_control
    verdict = evaluate_smooth_control(job.metrics['smooth'], degree=1)
    evidence = dict(control='wrong-y-flux', original_solver_sha256=digest(args.solver),
                    mutant_solver_sha256=digest(mutation),
                    criteria_sha256=job.criteria_sha, smooth=job.metrics['smooth'], verdict=verdict,
                    description='Both physical y-flux and its normal velocity have their signs reversed; all inputs and evaluator are unchanged.')
    evidence_path = out/'evidence.json'
    evidence_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    row = dict(name='wrong-y-flux', rejected=verdict['rejected'],
               reasons=verdict['reasons'], smooth=job.metrics['smooth'],
               evidence_sha256=digest(evidence_path))
    (out/'control-row.json').write_text(json.dumps(row, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    if args.campaign:
        metrics_path = Path(args.campaign)/'metrics.json'
        metrics = json.loads(metrics_path.read_text())
        if metrics['solver_sha256'] != digest(args.solver):
            raise ValueError('Campaign belongs to a different candidate')
        metrics['negative_controls'] = [row]
        metrics_path.write_text(json.dumps(metrics, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    print(json.dumps(row, indent=2))
    if not verdict['valid_evidence'] or not verdict['rejected']:
        raise SystemExit('The fixed evaluation failed to detect the injected error')


if __name__ == '__main__':
    main()
