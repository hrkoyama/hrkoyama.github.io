#!/usr/bin/env python3
"""Build the public RKDG code kit; require both final v3 scientific verdicts.

--stage-only writes an unpacked, explicitly non-final code/test staging tree.
It does not produce a ZIP or assert that the scientific campaign has passed.
No PDE solver or independent reference generation is run by this packager.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RESULTS = Path('outputs/rkdg-2026-11-23')
CURRENT = RESULTS/'accepted-v3'
ORIGINAL_SHA = '7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af'
RESOLUTION_SHA = '275c7ffc386bc4cc791148b498e3872e9a67398f2a175bd3ae9a418559cf63c3'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def local_module(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT/path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_final():
    """Read-only recomputation from frozen metrics, raw arrays and references."""
    accepted = ROOT/CURRENT
    solver = ROOT/'agent-kits/rkdg2d/generated/rkdg2d.py'
    source_sha = digest(solver)
    require(digest(ROOT/'numart/rkdg2d.py') == source_sha,
            'Canonical source and generated candidate differ')
    require(digest(ROOT/'validation/rkdg/acceptance.json') == ORIGINAL_SHA,
            'Original fixed acceptance criteria changed')
    require(digest(ROOT/'validation/rkdg/resolution-acceptance.json') == RESOLUTION_SHA,
            'Supplemental fixed acceptance criteria changed')
    manifest = read_json(ROOT/'agent-kits/rkdg2d/manifest.json')
    require(manifest.get('candidate_sha256') == source_sha
            and manifest.get('canonical_source_sha256') == source_sha,
            'Agent kit manifest does not bind the current source')
    metrics = read_json(accepted/'metrics.json')
    verdict = read_json(accepted/'verdict.json')
    resolution_path = ROOT/RESULTS/'resolution-v3.json'
    resolution = read_json(resolution_path)
    require(verdict.get('passed') is True and not verdict.get('failures'),
            'Final accepted-v3 original scientific verdict is not PASS')
    require(resolution.get('passed') is True and not resolution.get('failures'),
            'Final resolution-v3 supplemental scientific verdict is not PASS')
    require(verdict.get('solver_sha256') == source_sha,
            'Final original verdict belongs to a different solver')
    require(verdict.get('criteria_sha256') == ORIGINAL_SHA,
            'Final original verdict does not bind the frozen criteria')
    require(resolution.get('resolution_criteria_sha256') == RESOLUTION_SHA,
            'Final resolution verdict does not bind the frozen criteria')
    require(metrics.get('runner_sha256') == digest(ROOT/'scripts/run_rkdg_campaign.py'),
            'Campaign runner differs from the measured source')
    expected_support = {'validation/rkdg/evaluate.py', 'numart/riemann.py', 'numart/equations.py'}
    require(set(metrics.get('support_sha256', {})) == expected_support,
            'Campaign evaluation support bindings are incomplete')
    for name, sha in metrics['support_sha256'].items():
        require(digest(ROOT/name) == sha, 'Campaign dependency changed: '+name)
    evaluator = local_module('_atlas_package_evaluate', 'validation/rkdg/evaluate.py')
    recomputed = evaluator.evaluate_metrics(metrics, expected_solver_sha256=source_sha)
    require(recomputed.get('passed') is True,
            'Original scientific recheck failed: '+str(recomputed.get('failures')))
    require(recomputed.get('case_counts') == verdict.get('case_counts'),
            'Saved original verdict case counts differ from recomputation')
    raw = read_json(accepted/'raw-array-manifest.json')
    require(raw.get('metrics_sha256') == digest(accepted/'metrics.json'),
            'Merged raw-array manifest belongs to different metrics')
    require(raw.get('source_bindings', {}).get('solver_sha256') == source_sha,
            'Merged raw-array manifest belongs to different source')
    for key in ['criteria_sha256', 'runner_sha256', 'support_sha256']:
        require(raw.get('source_bindings', {}).get(key) == metrics.get(key),
                'Raw-array manifest differs from campaign source bindings: '+key)
    require(raw.get('merge_tool_sha256') == digest(ROOT/'scripts/merge_rkdg_campaigns.py'),
            'Merged raw-array manifest belongs to a different merge tool')
    require(verdict.get('merge_manifest_sha256') == digest(accepted/'raw-array-manifest.json'),
            'Original verdict does not bind the raw-array manifest')
    seen = set()
    for entry in raw.get('files', []):
        relative = Path(entry['path'])
        require(not relative.is_absolute() and '..' not in relative.parts,
                'Unsafe raw-array manifest member')
        require(str(relative) not in seen, 'Duplicate raw-array manifest member')
        seen.add(str(relative))
        path = accepted/relative
        require(path.is_file() and path.stat().st_size == entry['bytes']
                and digest(path) == entry['sha256'], 'Corrupt measured raw array: '+str(relative))
    require(bool(seen), 'Merged campaign has no bound raw arrays')
    resolution_evaluator = local_module('_atlas_package_resolution', 'validation/rkdg/resolution.py')
    recomputed_resolution = resolution_evaluator.evaluate_resolution(accepted, solver)
    require(recomputed_resolution.get('passed') is True,
            'Supplemental raw-array recheck failed: '+str(recomputed_resolution.get('failures')))
    require(resolution.get('source_bindings') == recomputed_resolution.get('source_bindings')
            and resolution.get('cases') == recomputed_resolution.get('cases')
            and resolution.get('original_verdict_record') == recomputed_resolution.get('original_verdict_record'),
            'Saved supplemental verdict differs from raw-array recomputation')
    return {'source_sha256': source_sha, 'original_48_case_verdict': str(CURRENT/'verdict.json'),
            'original_verdict_sha256': digest(accepted/'verdict.json'),
            'supplemental_4_check_verdict': str(RESULTS/'resolution-v3.json'),
            'supplemental_verdict_sha256': digest(resolution_path),
            'bound_raw_files_checked': len(seen), 'original_criteria_sha256': ORIGINAL_SHA,
            'supplemental_criteria_sha256': RESOLUTION_SHA,
            'scientific_saved_result_recheck_passed': True,
            'pde_solver_rerun_by_packager': False}


def collect_files(final=False):
    files = {}

    def add(path, destination=None):
        path = ROOT/path
        require(path.is_file() and not path.is_symlink(), 'Missing/nonregular package input: '+str(path))
        key = destination or path.relative_to(ROOT).as_posix()
        require(key not in files, 'Duplicate package member: '+key)
        files[key] = path.read_bytes()

    def add_tree(directory):
        require((ROOT/directory).is_dir(), 'Missing package input directory: '+str(directory))
        for path in sorted((ROOT/directory).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                add(path.relative_to(ROOT))

    for path in ['LICENSE', 'numart/rkdg2d.py', 'numart/riemann.py', 'numart/equations.py',
                 'docs/double-mach.md', 'docs/figures/double-mach.png',
                 'scripts/run_rkdg_campaign.py', 'scripts/run_rkdg_negative_control.py',
                 'scripts/merge_rkdg_campaigns.py', 'scripts/plot_rkdg_campaign.py',
                 'scripts/package_rkdg_demo.py']:
        add(path)
    for pattern in ['docs/rkdg*.md', 'tests/test_rkdg*.py']:
        found = sorted(ROOT.glob(pattern))
        require(bool(found), 'Missing package inputs: '+pattern)
        for path in found:
            add(path.relative_to(ROOT))
    require(len(list(ROOT.glob('tests/test_rkdg*.py'))) >= 7, 'All seven RKDG regression files are required')
    for directory in ['agent-kits/rkdg2d', 'validation/rkdg']:
        add_tree(Path(directory))
    # Retain actual previous outcomes, source, and failed resolution history.
    # The 1/2/4-rank output fixtures were exported from the historical v2 arrays.
    add_tree(RESULTS/'accepted')
    if final:
        add_tree(CURRENT)
        add_tree(RESULTS/'figures-v3')
        for required in ['resolution-v3.json', 'scientific-summary-v3.json',
                         'final-test-summary-v3.json', 'final-pytest-v3.log']:
            require((ROOT/RESULTS/required).is_file(), 'Final evidence is not ready: '+required)
    for name in ['attempt-1-status.json', 'baseline-test-summary.json',
                 'candidate-independent-review.json', 'runner-independent-review.json',
                 'final-test-summary.json', 'scientific-summary.json',
                 'scientific-summary-v2.json', 'final-scientific-audit.json',
                 'final-scientific-audit-v2.json', 'resolution-v2.json', 'campaign-shards.json']:
        path = RESULTS/name
        if (ROOT/path).exists():
            add(path)
    # Include newly added v3 audits/receipts/logs without enumerating stale names.
    if final:
        for pattern in ['*-v3.json', '*-v3.log']:
            for path in sorted((ROOT/RESULTS).glob(pattern)):
                key = path.relative_to(ROOT).as_posix()
                if key not in files:
                    add(path.relative_to(ROOT))
    add('agent-kits/rkdg2d/README.txt', 'README.txt')
    files['numart/__init__.py'] = b'"""Minimal Atlas RKDG demonstration distribution."""\n'
    files['requirements.txt'] = b'numpy>=1.24\n'
    files['requirements-optional.txt'] = b'pytest>=7\nmatplotlib>=3.7\n'
    files['pytest.ini'] = b'[pytest]\ntestpaths = tests\n'
    return files


def prepare_files(final=False):
    verification = verify_final() if final else {
        'scientific_saved_result_recheck_passed': False,
        'source_sha256': digest(ROOT/'numart/rkdg2d.py'),
        'reason': 'Code/test staging only; final v3 scientific gates were not evaluated.'}
    files = collect_files(final=final)
    state = {'schema_version': 1, 'kind': 'final-code-distribution' if final else 'nonfinal-code-test-staging',
             'scientific_verification': verification, 'MPI_PDE_solver_executed': False,
             'foreign_language_PDE_solver_executed': False, 'foreign_language_Cpp_IO_fixture_executed': True,
             'scope': 'Bounded Atlas assembly, frozen reference tests and language-neutral output contract; no private poster assets.'}
    files['BUILD-STATE.json'] = (json.dumps(state, indent=2, ensure_ascii=False)+'\n').encode()
    checks = []
    for name, raw in sorted(files.items()):
        parts = Path(name).parts
        require(not name.startswith('/') and '..' not in parts and not any(
            part in {'retreat-poster', 'website', 'atlas-search-publisher', '.git', 'node_modules'} for part in parts),
            'Private or unsafe package path: '+name)
        require(Path(name).suffix.lower() not in {'.pptx', '.ttf', '.otf', '.dylib', '.so'},
                'Non-code/private asset in package: '+name)
        require(Path(name).suffix.lower() != '.pdf'
                or name.startswith((RESULTS/'figures-v3').as_posix()+'/'),
                'PDF outside the explicit public scientific figure directory: '+name)
        checks.append(hashlib.sha256(raw).hexdigest()+'  '+name)
    files['SHA256SUMS.txt'] = ('\n'.join(checks)+'\n').encode()
    return files


def stage_distribution(destination):
    destination = Path(destination)
    require(not destination.exists(), 'Refusing to overwrite staging: '+str(destination))
    files = prepare_files(final=False)
    destination.mkdir(parents=True)
    for name, raw in files.items():
        path = destination/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    return {'kind': 'nonfinal-code-test-staging', 'path': str(destination), 'files': len(files),
            'final_zip_created': False}


def build_distribution(output):
    output = Path(output)
    require(not output.exists(), 'Refusing to overwrite an existing distribution: '+str(output))
    files = prepare_files(final=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation prevents replacement after a long verification step.
    with output.open('xb') as stream:
        with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name, raw in sorted(files.items()):
                archive.writestr('atlas-rkdg-agent-demo/'+name, raw)
    return {'kind': 'final-code-distribution', 'path': str(output), 'files': len(files),
            'bytes': output.stat().st_size, 'sha256': digest(output)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--output', type=Path,
                       default=ROOT/'output/code/atlas-rkdg-agent-demo-2026-11-23.zip')
    group.add_argument('--stage-only', type=Path, metavar='NEW_DIRECTORY',
                       help='Create unpacked code/test staging; never make a final ZIP or assert scientific PASS')
    args = parser.parse_args()
    try:
        result = stage_distribution(args.stage_only) if args.stage_only else build_distribution(args.output)
    except (ValueError, FileNotFoundError, KeyError) as exc:
        raise SystemExit('Refusing distribution: '+str(exc))
    print(json.dumps(result))


if __name__ == '__main__':
    main()
