#!/usr/bin/env python3
"""Plot the fresh reverse evolution in its own ascending coordinate frame.

The original solution and reference are spatially reflected for solid lines;
open markers come directly from the previously computed reverse arrays.
No PDE is run here, and the original mapped-back figure is retained.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from numart.riemann import exact_euler


def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--campaign',type=Path,default=ROOT/'outputs/rkdg-2026-11-23/x-reflection')
    ap.add_argument('--output',type=Path,default=ROOT/'outputs/rkdg-2026-11-23/x-reflection/figures')
    args=ap.parse_args();report=json.loads((args.campaign/'verdict.json').read_text())
    if report['case_count']!=6 or not report['all_fresh_evolutions']:
        raise ValueError('Require six actual completed reversed-x evolutions')
    if report['solver_sha256']!=digest(ROOT/'numart/rkdg2d.py'):
        raise ValueError('Numerical source changed')
    if report['runner_sha256']!=digest(ROOT/'scripts/run_rkdg_reflection.py'):
        raise ValueError('Recorded reflection runner changed')
    if report['criteria_sha256']!=digest(ROOT/'validation/rkdg/reflection-acceptance.json'):
        raise ValueError('Frozen reflection criteria changed')
    rows={(x['problem'],x['p']):x for x in report['cases']};raw={};provenance={}
    for key,row in rows.items():
        for label in ['forward','reverse']:
            p=ROOT/row[label+'_npz']
            if digest(p)!=row[label+'_npz_sha256']:raise ValueError('Raw data checksum changed')
            with np.load(p,allow_pickle=False) as d:
                raw[key+(label,)]=dict(coeff=np.array(d['coeff']),x_edges=np.array(d['x_edges']))
            provenance[str(p.relative_to(ROOT))]=digest(p)
        f=raw[key+('forward',)]['coeff'];rev=raw[key+('reverse',)]['coeff']
        # Independent coordinate/parity transform; never mirror the forward result.
        parity=(-1.)**np.arange(rev.shape[2])
        expected_reversed=f[::-1]*parity[None,None,:,None,None]*np.array([1.,-1.,1.,1.])
        delta=np.max(abs(rev[:,:,0,0,0]-expected_reversed[:,:,0,0,0]))
        if not np.isclose(delta,row['density_average_absolute_linf'],rtol=1e-12,atol=1e-20):
            raise ValueError('Recomputed reversed-density mismatch')
        raw[key+('forward',)]['reflected']=expected_reversed
    refpath=ROOT/'validation/rkdg/references/shu-osher-n3200.npz'
    if digest(refpath)!='b6c51a2abed1ae7eb71d4ebcb1dfcdf1348686521f8a2b8d8941ed638413bd46':
        raise ValueError('Independent reference changed')
    with np.load(refpath,allow_pickle=False) as d:ref={k:np.array(d[k]) for k in ['q','x_edges']}
    provenance[str(refpath.relative_to(ROOT))]=digest(refpath)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.titlesize':14,
        'axes.labelsize':13,'xtick.labelsize':13,'ytick.labelsize':13,
        'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
    colors={1:'#1B67A5',2:'#D5780B',3:'#21816B'}
    fig,axes=plt.subplots(1,2,figsize=(12,3.5))
    fig.subplots_adjust(left=.085,right=.985,bottom=.31,top=.82,wspace=.23)
    for ax,problem,end in zip(axes,['sod','shu-osher'],[.2,1.8]):
        if problem=='sod':
            xr=np.linspace(0,1,4096);rho=exact_euler((.5-xr)/end)[:,0]
        else:
            original_centers=.5*(ref['x_edges'][1:]+ref['x_edges'][:-1])
            xr=-original_centers[::-1];rho=ref['q'][::-1,0]
        ax.plot(xr,rho,color='#333333',linewidth=1.6,alpha=.85,zorder=1)
        for p in (1,2,3):
            f=raw[(problem,p,'forward')];v=raw[(problem,p,'reverse')]
            x=.5*(f['x_edges'][1:]+f['x_edges'][:-1])
            ax.plot(x,f['reflected'][:,:,0,0,0].mean(1),color=colors[p],linewidth=1.65,zorder=2)
            ax.plot(x,v['coeff'][:,:,0,0,0].mean(1),linestyle='none',marker='o',
                markevery=(5*(p-1),16),markersize=4.4,markerfacecolor='none',
                markeredgecolor=colors[p],markeredgewidth=1.0,zorder=4)
        delta=max(rows[(problem,p)]['density_average_absolute_linf'] for p in (1,2,3))
        label_xy=(.035,.58) if problem=='sod' else (.53,.11)
        ax.text(*label_xy,fr'max $|\Delta\bar\rho|$ = {delta:.2e}',transform=ax.transAxes,fontsize=11,color='#555555')
        ax.set(xlabel='Reversed-computation coordinate x',ylabel='Density',
            title=f'{"Sod" if problem=="sod" else "Shu–Osher"}, reversed x, t = {end:g}; 256 × 2 cells',
            xlim=(0,1) if problem=='sod' else (-5,5))
        ax.grid(alpha=.18)
    handles=[Line2D([],[],color='#333333',lw=1.6,label='Reference, reflected')]
    handles += [Line2D([],[],color=colors[p],lw=1.7,label=fr'$Q_{p}$, original reflected') for p in (1,2,3)]
    handles += [Line2D([],[],color='#333333',linestyle='none',marker='o',mfc='none',ms=5,label='Fresh reversed x')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.155),ncol=5,fontsize=11.3,frameon=False)
    fig.text(.5,.025,'Lines: original/reference reflected into reversed frame. Open markers: fresh reversed-x evolution. Ascending x axis; cell averages.',
        ha='center',fontsize=10.5)
    args.output.mkdir(parents=True,exist_ok=True);outputs=[]
    for ext in ['png','pdf']:
        p=args.output/('directional-reflection-reversed-x.'+ext);fig.savefig(p,dpi=200,facecolor='white')
        outputs.append({'file':str(p.resolve()),'sha256':digest(p),'bytes':p.stat().st_size})
    plt.close(fig)
    manifest={'date':'2026-11-23','figure_source':'markers directly from fresh reverse PDE output; forward/reference solid lines reflected into the reversed-computation frame',
        'outputs':outputs,'plot_source_sha256':digest(__file__),'reflection_verdict_sha256':digest(args.campaign/'verdict.json'),
        'input_sha256':provenance,'max_density_absolute_difference':{k:max(rows[(k,p)]['density_average_absolute_linf'] for p in [1,2,3]) for k in ['sod','shu-osher']},
        'supplemental_qualification':{'passed':report['passed'],'passed_cases':sum(x['passed'] for x in report['cases']),
            'total_cases':6,'failed_cases':[{'problem':x['problem'],'p':x['p'],'failures':x['failures']} for x in report['cases'] if not x['passed']],
            'note':'The strict new1e-10 max-mode criterion fails for Shu–Osher p3. This plot displays that measured result and does not convert it into a PASS. Original48 and waveform4 verdicts are unchanged.'},
        'scope':'Ascending reversed-computation x coordinate: Sod low-density left/high-density right; Shu shock on left. Actual reverse arrays are markers, not a flipped forward output. Exact1D invariant branch; not independent accuracy or full2D-reflection validation.'}
    (args.output/'figure-reversed-x-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
