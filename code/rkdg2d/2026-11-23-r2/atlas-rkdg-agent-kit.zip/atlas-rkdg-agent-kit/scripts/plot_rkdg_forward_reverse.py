#!/usr/bin/env python3
"""Overlay raw forward/reverse computations in the same ascending x coordinate.

The display does not mirror either numerical result. Reflection is used only
for the separate symmetry-error comparison, explicitly labeled as such.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from numart.riemann import exact_euler


def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--campaign',type=Path,default=ROOT/'outputs/rkdg-2026-11-23/x-reflection')
    ap.add_argument('--output',type=Path,default=ROOT/'outputs/rkdg-2026-11-23/x-reflection/figures')
    args=ap.parse_args();report=json.loads((args.campaign/'verdict.json').read_text())
    if report['case_count']!=6 or not report['all_fresh_evolutions']:
        raise ValueError('Require six actual completed reversed-x evolutions')
    if report['solver_sha256']!=digest(ROOT/'numart/rkdg2d.py'):
        raise ValueError('Numerical source changed')
    if report['runner_sha256']!=digest(ROOT/'scripts/run_rkdg_reflection.py'):
        raise ValueError('Recorded reflection runner changed')
    if report['criteria_sha256']!=digest(ROOT/'validation/rkdg/reflection-acceptance.json'):
        raise ValueError('Frozen reflection criteria changed')
    rows={(x['problem'],x['p']):x for x in report['cases']};raw={};provenance={}
    for key,row in rows.items():
        for label in ['forward','reverse']:
            p=ROOT/row[label+'_npz']
            if digest(p)!=row[label+'_npz_sha256']:raise ValueError('Raw data checksum changed')
            with np.load(p,allow_pickle=False) as d:
                raw[key+(label,)]=dict(coeff=np.array(d['coeff']),x_edges=np.array(d['x_edges']))
            provenance[str(p.relative_to(ROOT))]=digest(p)
        f=raw[key+('forward',)]['coeff'];rev=raw[key+('reverse',)]['coeff']
        # Independent coordinate/parity transform; never mirror the forward result.
        parity=(-1.)**np.arange(rev.shape[2])
        mapped=rev[::-1]*parity[None,None,:,None,None]*np.array([1.,-1.,1.,1.])
        delta=np.max(abs(mapped[:,:,0,0,0]-f[:,:,0,0,0]))
        if not np.isclose(delta,row['density_average_absolute_linf'],rtol=1e-12,atol=1e-20):
            raise ValueError('Recomputed reversed-density mismatch')
        raw[key+('reverse',)]['mapped']=mapped
    refpath=ROOT/'validation/rkdg/references/shu-osher-n3200.npz'
    if digest(refpath)!='b6c51a2abed1ae7eb71d4ebcb1dfcdf1348686521f8a2b8d8941ed638413bd46':
        raise ValueError('Independent reference changed')
    with np.load(refpath,allow_pickle=False) as d:ref={k:np.array(d[k]) for k in ['q','x_edges']}
    provenance[str(refpath.relative_to(ROOT))]=digest(refpath)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.titlesize':14,
        'axes.labelsize':13,'xtick.labelsize':13,'ytick.labelsize':13,
        'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
    colors={'forward':'#1B67A5','reverse':'#D5780B'}
    styles={1:':',2:'--',3:'-'}
    fig,axes=plt.subplots(1,2,figsize=(12,3.5))
    fig.subplots_adjust(left=.085,right=.985,bottom=.35,top=.82,wspace=.23)
    for ax,problem,end in zip(axes,['sod','shu-osher'],[.2,1.8]):
        if problem=='sod':
            xr=np.linspace(0,1,4096);rho=exact_euler((xr-.5)/end)[:,0]
        else:xr=.5*(ref['x_edges'][1:]+ref['x_edges'][:-1]);rho=ref['q'][:,0]
        ax.plot(xr,rho,color='#444444',linewidth=1.2,alpha=.40,zorder=1)
        lo,hi=(0.,1.) if problem=='sod' else (-5.,5.)
        # Both reference directions are displayed, but neither numerical run is remapped.
        ax.plot(lo+hi-xr[::-1],rho[::-1],color='#444444',linewidth=1.2,alpha=.40,zorder=1)
        for p in (1,2,3):
            f=raw[(problem,p,'forward')];v=raw[(problem,p,'reverse')]
            x=.5*(f['x_edges'][1:]+f['x_edges'][:-1])
            ax.plot(x,f['coeff'][:,:,0,0,0].mean(1),color=colors['forward'],
                linestyle=styles[p],linewidth=1.8,zorder=2)
            ax.plot(x,v['coeff'][:,:,0,0,0].mean(1),color=colors['reverse'],
                linestyle=styles[p],linewidth=1.8,zorder=3)
        ax.set(xlabel='Computation coordinate x',ylabel='Density',
            title=f'{"Sod" if problem=="sod" else "Shu–Osher"}, t = {end:g}; 256 × 2 cells',
            xlim=(0,1) if problem=='sod' else (-5,5))
        ax.grid(alpha=.18)
    handles=[Line2D([],[],color=colors['forward'],lw=1.8,label='Original x'),
        Line2D([],[],color=colors['reverse'],lw=1.8,label='Fresh reversed x')]
    handles += [Line2D([],[],color='#333333',lw=1.8,linestyle=styles[p],label=fr'$Q_{p}$') for p in (1,2,3)]
    handles += [Line2D([],[],color='#444444',lw=1.2,alpha=.5,label='References, both directions')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,.18),ncol=6,fontsize=11.3,frameon=False)
    fig.text(.5,.065,'Blue: original x; orange: freshly computed reversed x. Both raw profiles use the same ascending x axis; no reflection for display.',
        ha='center',fontsize=10.5)
    deltas=[max(rows[(k,p)]['density_average_absolute_linf'] for p in (1,2,3)) for k in ['sod','shu-osher']]
    fig.text(.5,.018,'Separate comparison AFTER mapping reverse back: '+fr'max $|\Delta\bar\rho|$ = {deltas[0]:.2e} (Sod), {deltas[1]:.2e} (Shu–Osher).',
        ha='center',fontsize=10.5,color='#555555')
    args.output.mkdir(parents=True,exist_ok=True);outputs=[]
    for ext in ['png','pdf']:
        p=args.output/('directional-forward-reverse-x.'+ext);fig.savefig(p,dpi=200,facecolor='white')
        outputs.append({'file':str(p.resolve()),'sha256':digest(p),'bytes':p.stat().st_size})
    plt.close(fig)
    manifest={'date':'2026-11-23','figure_source':'raw forward and raw fresh reversed-x outputs on the same ascending x axis, without display remapping',
        'outputs':outputs,'plot_source_sha256':digest(__file__),'reflection_verdict_sha256':digest(args.campaign/'verdict.json'),
        'input_sha256':provenance,'max_density_absolute_difference':{k:max(rows[(k,p)]['density_average_absolute_linf'] for p in [1,2,3]) for k in ['sod','shu-osher']},
        'supplemental_qualification':{'passed':report['passed'],'passed_cases':sum(x['passed'] for x in report['cases']),
            'total_cases':6,'failed_cases':[{'problem':x['problem'],'p':x['p'],'failures':x['failures']} for x in report['cases'] if not x['passed']],
            'note':'The strict new1e-10 max-mode criterion fails for Shu–Osher p3. This plot displays that measured result and does not convert it into a PASS. Original48 and waveform4 verdicts are unchanged.'},
        'scope':'Blue denotes raw forward output, orange raw fresh reverse output. DegreesQ1/Q2/Q3 use dotted/dashed/solid styles. Both x axes ascend. Gray original/reflected independent references are displayed. The labeled tiny errors are a separate symmetry comparison AFTER mapping reverse back, not the difference of the visibly distinct raw curves. Exact1D branch, not a full2D-reflection validation.'}
    (args.output/'figure-forward-reverse-x-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
