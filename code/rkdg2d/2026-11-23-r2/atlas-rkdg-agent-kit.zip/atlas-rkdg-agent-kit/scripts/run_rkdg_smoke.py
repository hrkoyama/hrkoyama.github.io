#!/usr/bin/env python3
"""Run six small fresh fully-2D Euler evolutions with an independent exact wave.

This is an installation smoke check, not the original 48-case qualification.
The independent reconstruction uses raw Legendre modes rather than solver.sample.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
from numpy.polynomial.legendre import leggauss, legvander

ROOT = Path(__file__).resolve().parents[1]
RULES = ROOT/'validation/rkdg/smoke-acceptance.json'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def exact(x, y, t=0.):
    rho = 1+.2*np.sin(2*np.pi*(x+y-1.5*t))
    return np.stack((rho, rho, .5*rho, 2.5+.625*rho), axis=-1)


def check(solver):
    started = time.perf_counter()
    rules = json.loads(RULES.read_text())
    source_sha = digest(solver)
    spec = importlib.util.spec_from_file_location('_atlas_smoke_candidate', solver)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    z, w = leggauss(rules['quadrature_points_per_axis'])
    rows, failures = [], []
    for p in rules['degrees']:
        degree_rows = []
        for n in rules['grids']:
            dg = mod.DG2D(n, n, p, boundary='periodic', limiter='none')
            result = dg.evolve(dg.project(exact), rules['final_time'], cfl=rules['cfl'])
            coeff = np.asarray(result.coeff)
            expected_shape = (n, n, p+1, p+1, 4)
            if coeff.shape != expected_shape or not np.all(np.isfinite(coeff)):
                raise ValueError('Invalid candidate coefficient shape or nonfinite data')
            v = legvander(z, p)
            sampled = np.einsum('ijmnc,am,bn->ijabc', coeff, v, v)
            x = (np.arange(n)[:, None, None, None]+.5+.5*z[None, None, :, None])/n
            y = (np.arange(n)[None, :, None, None]+.5+.5*z[None, None, None, :])/n
            error = sampled-exact(x+y*0, y+x*0, rules['final_time'])
            l2 = float(np.sqrt(.25*np.einsum('a,b,ijab->', w, w, error[..., 0]**2)/n**2))
            rho = sampled[..., 0]
            pressure = .4*(sampled[..., 3]-.5*(sampled[..., 1]**2+sampled[..., 2]**2)/rho)
            # The exact conserved means on the periodic unit square are known.
            means = np.mean(coeff[:, :, 0, 0, :], axis=(0, 1))
            expected = np.array([1., 1., .5, 3.125])
            conservation = float(np.max(abs(means-expected)/np.maximum(1., abs(expected))))
            row = dict(degree=p, nx=n, ny=n, final_time=float(result.time), steps=int(result.steps),
                       density_l2=l2, normalized_conservation_defect=conservation,
                       sampled_density_min=float(rho.min()), sampled_pressure_min=float(pressure.min()),
                       fresh_pde_evolution=True)
            if result.time != rules['final_time'] or result.steps < 1:
                failures.append(f'p{p}/n{n}: incorrect time or no accepted steps')
            if not np.isfinite(l2) or l2 <= 0 or rho.min() <= 0 or pressure.min() <= 0:
                failures.append(f'p{p}/n{n}: nonfinite error or nonpositive state')
            if conservation > rules['maximum_normalized_conservation_defect']:
                failures.append(f'p{p}/n{n}: conservation threshold exceeded')
            rows.append(row); degree_rows.append(row)
        order = float(np.log(degree_rows[0]['density_l2']/degree_rows[1]['density_l2'])/
                      np.log(rules['grids'][1]/rules['grids'][0]))
        for row in degree_rows:
            row['observed_l2_order'] = order
        if not np.isfinite(order) or order < p+rules['minimum_l2_order_offset']:
            failures.append(f'p{p}: L2 order below frozen smoke threshold')
    if digest(solver) != source_sha:
        raise ValueError('Candidate source changed during execution')
    return dict(schema_version=1, kind='fresh-2d-smoke', passed=not failures, failures=failures,
                solver_sha256=source_sha, runner_sha256=digest(__file__), criteria_sha256=digest(RULES),
                scope=rules['scope'], fresh_pde_runs=len(rows), cases=rows,
                wall_seconds=time.perf_counter()-started,
                environment=dict(python=sys.version, numpy=np.__version__, platform=platform.platform()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--solver', type=Path, default=ROOT/'agent-kits/rkdg2d/generated/rkdg2d.py')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Refusing to overwrite existing smoke record')
    result = check(args.solver.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps(dict(passed=result['passed'], fresh_pde_runs=result['fresh_pde_runs'],
                          wall_seconds=result['wall_seconds'], output=str(args.output))))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
