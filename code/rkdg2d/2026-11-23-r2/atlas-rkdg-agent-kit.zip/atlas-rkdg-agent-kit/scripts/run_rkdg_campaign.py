#!/usr/bin/env python3
"""Run the frozen RKDG campaign against a selected implementation file.

Evaluation rules are read-only inputs. Each result is bound to source and input
hashes; incompatible caches are never silently reused. Run from the repo root.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
import time

import numpy as np
from numpy.polynomial.legendre import leggauss, legvander

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from numart.riemann import exact_euler
from validation.rkdg.evaluate import modal_density_errors, conservation_defect


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(path):
    spec = importlib.util.spec_from_file_location('numart._rkdg_candidate', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def exact_entropy(x, y, t, velocity=(1., .5)):
    """Independent analytic conservative state, gamma=1.4, p=1."""
    u, v = velocity
    density = 1 + .2*np.sin(2*np.pi*(x + y - (u+v)*t))
    return np.stack((density, density*u, density*v,
                     2.5+.5*density*(u*u+v*v)), axis=-1)


def overlap(source_edges, target_edges):
    left = np.maximum(target_edges[:-1, None], source_edges[None, :-1])
    right = np.minimum(target_edges[1:, None], source_edges[None, 1:])
    return np.maximum(right-left, 0)/np.diff(target_edges)[:, None]


def remap_1d(data, edges):
    return overlap(data['x_edges'], edges) @ data['q']


def remap_2d(data, xedges, yedges):
    return np.einsum('ai,ijv,bj->abv', overlap(data['x_edges'], xedges),
                     data['q'], overlap(data['y_edges'], yedges), optimize=True)


def sod_average(edges, end):
    z, w = leggauss(64)
    x = .5*(edges[:-1, None]+edges[1:, None])+np.diff(edges)[:, None]*z/2
    state = exact_euler((x-.5)/end)
    rho, u, p = np.moveaxis(state, -1, 0)
    q = np.stack((rho, rho*u, np.zeros_like(rho), p/.4+.5*rho*u*u), axis=-1)
    return np.einsum('iqv,q->iv', q, w/2)


def density_error(q, expected):
    return float(np.mean(abs(q[..., 0]-expected[..., 0])) /
                 np.mean(abs(expected[..., 0])))


def reconstruct(coeff, z):
    basis = legvander(np.asarray(z), coeff.shape[2]-1)
    return np.einsum('am,bn,ijmnk->ijabk', basis, basis, coeff, optimize=True)


def physical_minima(solver, coeff):
    # Positivity is claimed on the declared Gauss volume/face nodes and corners.
    # A Qp polynomial is not guaranteed positive at every continuous point.
    z = np.unique(np.r_[[-1., 1.], leggauss(len(solver.z))[0]])
    q = reconstruct(coeff, z)
    rho = q[..., 0]
    pressure = .4*(q[..., 3]-.5*np.sum(q[..., 1:3]**2, axis=-1)/rho)
    return float(rho.min()), float(pressure.min())


def normalized_conservation(diagnostics):
    # The solver reports an actual RK-integrated outward boundary flux.
    return conservation_defect(diagnostics['initial_integral'], diagnostics['final_integral'],
                                diagnostics['integrated_boundary_outflow'])


class Campaign:
    def __init__(self, args):
        self.args = args
        self.module = load_module(args.solver)
        self.solver_sha = digest(args.solver)
        self.criteria_path = ROOT/'validation/rkdg/acceptance.json'
        self.criteria = json.loads(self.criteria_path.read_text())
        self.criteria_sha = digest(self.criteria_path)
        self.degrees = getattr(args, 'degrees', None) or self.criteria['degrees']
        self.support = {str(p.relative_to(ROOT)): digest(p) for p in (
            ROOT/'validation/rkdg/evaluate.py', ROOT/'numart/riemann.py',
            ROOT/'numart/equations.py')}
        self.out = Path(args.output)
        self.out.mkdir(parents=True, exist_ok=True)
        (self.out/'arrays').mkdir(exist_ok=True)
        self.reference_dir = Path(args.references)
        self.metrics_path = self.out/'metrics.json'
        self.metrics = dict(schema_version=1, criteria_sha256=self.criteria_sha,
                            solver_sha256=self.solver_sha, reference_sha256={},
                            runner_sha256=digest(__file__),
                            support_sha256=self.support,
                            smooth=[], directional=[], double_mach=[], temporal=[],
                            negative_controls=[], environment=dict(
                                python=sys.version, numpy=np.__version__, platform=platform.platform()))
        if self.metrics_path.exists():
            old = json.loads(self.metrics_path.read_text())
            if (old['solver_sha256'] == self.solver_sha and old['criteria_sha256'] == self.criteria_sha
                    and old.get('runner_sha256') == digest(__file__)
                    and old.get('support_sha256') == self.support):
                self.metrics = old
        self.start = time.perf_counter()

    def checkpoint(self):
        temp = self.metrics_path.with_suffix('.json.tmp')
        temp.write_text(json.dumps(self.metrics, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
        temp.replace(self.metrics_path)

    def put(self, section, row, keys):
        self.metrics[section] = [r for r in self.metrics[section]
                                 if any(r[k] != row[k] for k in keys)] + [row]
        self.checkpoint()
        print(json.dumps(dict(section=section, elapsed=round(time.perf_counter()-self.start, 2),
                              result=row), ensure_ascii=False), flush=True)

    def run(self, name, config, initial):
        cache = self.out/'arrays'/(name+'.npz')
        dgargs = {k: v for k, v in config.items() if k not in ('time', 'cfl', 'dt_max')}
        solver = self.module.DG2D(**dgargs)
        q0 = solver.project(initial)
        key = hashlib.sha256(json.dumps(dict(config=config, solver=self.solver_sha,
                                             runner=digest(__file__),
                                             support=self.support,
                                             initial=hashlib.sha256(q0.tobytes()).hexdigest()),
                                       sort_keys=True).encode()).hexdigest()
        if cache.exists():
            data = np.load(cache)
            if str(data['cache_key']) == key:
                return solver, data['coeff'], json.loads(str(data['diagnostics'])), data
        stamp = time.perf_counter()
        step_times = [0.]
        result = solver.evolve(q0, final_time=config['time'], cfl=config.get('cfl', .2),
                               dt_max=config.get('dt_max'),
                               callback=lambda t, q: step_times.append(float(t)))
        diagnostics = dict(result.diagnostics)
        diagnostics.update(wall_seconds=time.perf_counter()-stamp, steps=result.steps,
                           final_time=result.time)
        stepsizes = np.diff(step_times)
        diagnostics['recorded_step_count'] = len(stepsizes)
        if 'dt_max' in config:
            nominal = config['dt_max']
            diagnostics['steps_shorter_than_cap_excluding_final'] = int(np.count_nonzero(
                ~np.isclose(stepsizes[:-1], nominal, rtol=1e-9, atol=1e-14)))
        b = config.get('bounds', (0., 1., 0., 1.))
        xedges = np.linspace(b[0], b[1], config['nx']+1)
        yedges = np.linspace(b[2], b[3], config['ny']+1)
        np.savez_compressed(cache, cache_key=key, coeff=result.coeff,
                            q=result.coeff[:, :, 0, 0, :],
                            x_edges=xedges, y_edges=yedges,
                            step_times=np.asarray(step_times),
                            diagnostics=json.dumps(diagnostics), config=json.dumps(config))
        print(json.dumps(dict(case=name, seconds=round(diagnostics['wall_seconds'], 2),
                              steps=result.steps, cache=str(cache))), flush=True)
        return solver, result.coeff, diagnostics, np.load(cache)

    def smooth(self):
        c = self.criteria['smooth']
        for p in self.degrees:
            for n in c['levels']:
                config = dict(nx=n, ny=n, degree=p, boundary='periodic', limiter='none',
                              time=c['time'], cfl=.2)
                solver, q, diag, _ = self.run(f'smooth-p{p}-n{n}', config,
                                             lambda x, y: exact_entropy(x, y, 0.))
                errors = modal_density_errors(q, exact_entropy, time=c['time'])
                self.put('smooth', dict(p=p, n=n, time=c['time'], velocity=c['velocity'],
                                        errors=errors, conservation_defect=normalized_conservation(diag)),
                         ['p', 'n'])

    def reference(self, pattern):
        candidates = sorted(self.reference_dir.glob(pattern))
        if not candidates:
            raise FileNotFoundError('Missing independent reference: '+pattern)
        def resolution(p):
            with np.load(p) as data:
                return data['q'].size
        path = max(candidates, key=resolution)
        return self.checked_reference(path)

    def checked_reference(self, path):
        metadata = json.loads(path.with_suffix('.json').read_text())
        quality = json.loads((self.reference_dir/'quality.json').read_text())
        ledger = {r['file']: r['sha256'] for r in quality['files']}
        if metadata['npz_sha256'] != digest(path) or ledger.get(path.name) != digest(path):
            raise ValueError('Frozen reference digest mismatch: '+str(path))
        if metadata['gamma'] != 1.4 or metadata['source_sha256'] != digest(ROOT/'validation/rkdg/reference.py'):
            raise ValueError('Reference physical model/source changed')
        data = np.load(path)
        end = 1.8 if path.name.startswith('shu') else .2
        if float(data['time']) != end or metadata['time'] != end or list(data['q'].shape) != metadata['shape']:
            raise ValueError('Reference horizon/shape mismatch')
        expected_x = (-5., 5.) if path.name.startswith('shu') else (0., 4.)
        xedges = data['x_edges']
        if (not np.all(np.diff(xedges) > 0) or not np.allclose(xedges[[0, -1]], expected_x)
                or len(xedges) != data['q'].shape[0]+1):
            raise ValueError('Reference cell-edge mismatch')
        if not path.name.startswith('shu'):
            yedges = data['y_edges']
            if (not np.all(np.diff(yedges) > 0) or not np.allclose(yedges[[0, -1]], [0., 1.])
                    or len(yedges) != data['q'].shape[1]+1):
                raise ValueError('Reference y-edge mismatch')
        self.metrics['reference_sha256'][path.name] = digest(path)
        return data

    def directional(self):
        c = self.criteria['directional']
        for problem in c['problems']:
            reference = None if problem == 'sod' else self.reference('shu*.npz')
            for p in self.degrees:
                for n in c['levels']:
                    rows = []; oriented = []
                    for axis in (0, 1):
                        lo, hi = (0., 1.) if problem == 'sod' else (-5., 5.)
                        bounds = (lo, hi, 0., 1.) if axis == 0 else (0., 1., lo, hi)
                        config = dict(nx=n if axis == 0 else 2, ny=2 if axis == 0 else n,
                                      degree=p, bounds=bounds, boundary='outflow', limiter='tvb',
                                      time=c['time'][problem], cfl=.2)
                        init = getattr(self.module, 'sod' if problem == 'sod' else 'shu_osher')
                        solver, coeff, diag, raw = self.run(f'{problem}-p{p}-a{axis}-n{n}', config,
                                                           lambda x, y: init(x, y, axis=axis))
                        averages = coeff[:, :, 0, 0, :]
                        profile = averages.mean(axis=1-axis)
                        if axis == 1:
                            profile = profile[:, [0, 2, 1, 3]]
                        oriented.append(coeff if axis == 0 else
                                        coeff.transpose(1, 0, 3, 2, 4)[..., [0, 2, 1, 3]])
                        ed = raw['x_edges'] if axis == 0 else raw['y_edges']
                        expected = sod_average(ed, config['time']) if reference is None else remap_1d(reference, ed)
                        # Transverse constancy includes all modal fields, not just means.
                        transverse_modes = coeff[:, :, :, 1:, :] if axis == 0 else coeff[:, :, 1:, :, :]
                        transverse = float(max(np.max(abs(np.diff(coeff, axis=1-axis))),
                                               np.max(abs(transverse_modes))))
                        minrho, minp = physical_minima(solver, coeff)
                        rows.append(dict(problem=problem, p=p, axis=axis, n=n, time=config['time'],
                                         error_l1=density_error(profile, expected), transverse=transverse,
                                         conservation_defect=normalized_conservation(diag),
                                         min_density=minrho, min_pressure=minp,
                                         reference_kind=c['reference_kind'][problem]))
                    delta = float(np.max(abs(oriented[0]-oriented[1])))
                    for row in rows:
                        row['axis_difference'] = delta
                        self.put('directional', row, ['problem', 'p', 'axis', 'n'])

    def double_mach(self):
        c = self.criteria['double_mach']
        reference = self.reference('double-mach*.npz')
        refs = sorted(self.reference_dir.glob('double-mach*.npz'),
                      key=lambda p: np.load(p)['q'].size)
        if len(refs) < 2:
            raise ValueError('Double Mach requires two independent FV resolution levels')
        coarse = self.checked_reference(refs[-2])
        fine_on_coarse = remap_2d(reference, coarse['x_edges'], coarse['y_edges'])
        uncertainty = density_error(coarse['q'], fine_on_coarse)
        for p in self.degrees:
            for ny in c['levels']:
                config = dict(nx=4*ny, ny=ny, degree=p, bounds=(0., 4., 0., 1.),
                              boundary='double-mach', limiter='tvb', time=c['time'], cfl=.2)
                solver, coeff, diag, raw = self.run(f'double-mach-p{p}-ny{ny}', config,
                                                   self.module.double_mach)
                expected = remap_2d(reference, raw['x_edges'], raw['y_edges'])
                minrho, minp = physical_minima(solver, coeff)
                self.put('double_mach', dict(p=p, ny=ny, time=config['time'],
                                             error_l1=density_error(raw['q'], expected),
                                             reference_grid_change_l1=uncertainty,
                                             conservation_defect=normalized_conservation(diag),
                                             min_density=minrho, min_pressure=minp,
                                             reference_kind='independent-fv'), ['p', 'ny'])

    def temporal(self):
        c = self.criteria['temporal']
        # Fixed stable dt, exact subdivisions of the horizon; identical space.
        base = c['time']/192
        solutions = {}
        for factor in (1, 2, 4, 8):
            config = dict(nx=c['n'], ny=c['n'], degree=3, boundary='periodic', limiter='none',
                          time=c['time'], cfl=.5, dt_max=base/factor)
            solver, coeff, diag, _ = self.run(f'temporal-f{factor}', config,
                                             lambda x, y: exact_entropy(x, y, 0.))
            if not np.isclose(diag['max_dt'], base/factor, rtol=1e-11, atol=1e-15):
                raise RuntimeError('Temporal dt cap is not the active time step')
            if diag['steps_shorter_than_cap_excluding_final']:
                raise RuntimeError('Temporal refinement has internally shortened time steps')
            solutions[factor] = (solver, coeff)
        z, w = leggauss(8)
        weight = w[:, None]*w[None, :]/4
        reference = reconstruct(solutions[8][1], z)[..., 0]
        for factor in (1, 2, 4):
            error = reconstruct(solutions[factor][1], z)[..., 0]-reference
            l2 = float(np.sqrt(np.mean(np.sum(error**2*weight, axis=(-2, -1)))))
            self.put('temporal', dict(p=3, n=c['n'], time=c['time'], factor=factor,
                                      dt=base/factor, reference_dt=base/8, error_l2=l2), ['factor'])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--solver', default=str(ROOT/'numart/rkdg2d.py'))
    p.add_argument('--references', default=str(ROOT/'validation/rkdg/references'))
    p.add_argument('--output', default=str(ROOT/'outputs/rkdg-2026-11-23/baseline'))
    p.add_argument('--sections', nargs='+', choices=['smooth', 'directional', 'double_mach', 'temporal'],
                   default=['smooth', 'directional', 'double_mach', 'temporal'])
    p.add_argument('--degrees', nargs='+', type=int, choices=[1, 2, 3],
                   help='Run a subset into a separate output directory; final acceptance still requires all degrees')
    args = p.parse_args()
    campaign = Campaign(args)
    for section in args.sections:
        getattr(campaign, section)()
    campaign.checkpoint()


if __name__ == '__main__':
    main()
