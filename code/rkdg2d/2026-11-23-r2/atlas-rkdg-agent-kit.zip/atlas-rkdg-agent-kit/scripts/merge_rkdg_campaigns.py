#!/usr/bin/env python3
"""Merge disjoint, source-identical RKDG campaign shards and a measured mutant.

No numerical criteria are changed and no solver is executed. A complete final
PASS is issued only by the unchanged pinned evaluator. Missing cases produce a
saved failing verdict and a nonzero exit status, including for partial merges.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from validation.rkdg.evaluate import (CRITERIA_PATH, PINNED_CRITERIA_SHA256,
    evaluate_metrics, evaluate_smooth_control)

SECTIONS = {
    'smooth': ('p', 'n'),
    'directional': ('problem', 'p', 'axis', 'n'),
    'double_mach': ('p', 'ny'),
    'temporal': ('factor',),
}
BINDINGS = ('schema_version', 'criteria_sha256', 'solver_sha256',
            'runner_sha256', 'support_sha256')


class MergeError(ValueError):
    pass


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    temp.replace(path)


def require(condition, message):
    if not condition:
        raise MergeError(message)


def relative(path, output):
    return os.path.relpath(Path(path).resolve(), Path(output).resolve())


def copy_bound(source, target, manifest, output):
    """Preserve exact bytes; refuse to mix a previous different output bundle."""
    source, target = Path(source), Path(target)
    require(source.is_file(), 'Missing preserved evidence: '+str(source))
    sha = digest(source)
    if target.exists():
        require(target.is_file() and digest(target)==sha,
                'Output already contains different evidence; use a new output directory: '+str(target))
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source,target)
    require(digest(target)==sha, 'Copy hash mismatch: '+str(target))
    manifest.append({'path':relative(target,output),'bytes':target.stat().st_size,
                     'sha256':sha,'source':relative(source,output)})


def array_name(section, row):
    if section=='smooth': return f"smooth-p{row['p']}-n{row['n']}.npz"
    if section=='directional': return f"{row['problem']}-p{row['p']}-a{row['axis']}-n{row['n']}.npz"
    if section=='double_mach': return f"double-mach-p{row['p']}-ny{row['ny']}.npz"
    return f"temporal-f{row['factor']}.npz"


def check_array(path, section, row):
    """Bind raw array geometry/horizon to its recorded numerical case."""
    require(path.is_file(), 'Missing raw array for recorded case: '+str(path))
    with np.load(path,allow_pickle=False) as data:
        require(all(k in data for k in ('coeff','q','config','diagnostics','step_times')),
                'Incomplete raw-array evidence: '+str(path))
        config=json.loads(str(data['config']))
        diagnostics=json.loads(str(data['diagnostics']))
        p=row.get('p',3)
        require(config.get('degree')==p, 'Raw array polynomial degree mismatch: '+str(path))
        require(config.get('time')==row['time'] and
                abs(float(diagnostics.get('final_time',float('inf')))-row['time'])<=1e-12,
                'Raw array final-time mismatch: '+str(path))
        nx,ny=config['nx'],config['ny']
        expected=(row['n'],row['n']) if section in ('smooth','temporal') else (
            (row['n'],2) if section=='directional' and row['axis']==0 else
            (2,row['n']) if section=='directional' else (4*row['ny'],row['ny']))
        require((nx,ny)==expected, 'Raw array mesh mismatch: '+str(path))
        require(data['coeff'].shape==(nx,ny,p+1,p+1,4), 'Raw coefficient shape mismatch: '+str(path))
        require(data['q'].shape==(nx,ny,4), 'Raw average shape mismatch: '+str(path))
        require(np.all(np.isfinite(data['coeff'])) and np.all(np.isfinite(data['q'])),
                'Nonfinite raw numerical state: '+str(path))
        require(np.array_equal(data['q'],data['coeff'][:,:,0,0,:]),
                'Raw average/coefficient mismatch: '+str(path))
        times=data['step_times']
        require(times.ndim==1 and len(times)>=2 and abs(float(times[0]))<=1e-14
                and abs(float(times[-1])-row['time'])<=1e-12 and np.all(np.diff(times)>0),
                'Invalid accepted-step history: '+str(path))
        require(len(times)-1==diagnostics.get('steps')==diagnostics.get('recorded_step_count'),
                'Accepted-step count mismatch: '+str(path))
        if section=='temporal':
            nominal=row['dt']
            require(np.isclose(config.get('dt_max'),nominal,rtol=1e-12,atol=1e-15)
                    and np.all(np.isclose(np.diff(times)[:-1],nominal,rtol=1e-9,atol=1e-14)),
                    'Actual temporal refinement differs from nominal cap: '+str(path))


def check_negative(negative, solver, common):
    negative=Path(negative)
    row_path=negative/'control-row.json'
    evidence_path=negative/'evidence.json'
    mutant_path=negative/'wrong_y_flux.py'
    row,evidence=read_json(row_path),read_json(evidence_path)
    require(row.get('name')=='wrong-y-flux','Unexpected negative-control name')
    require(row.get('evidence_sha256')==digest(evidence_path),'Negative-control evidence hash mismatch')
    require(evidence.get('original_solver_sha256')==digest(solver),
            'Negative control belongs to a different original solver')
    require(evidence.get('mutant_solver_sha256')==digest(mutant_path),
            'Negative-control mutant source hash mismatch')
    require(evidence.get('criteria_sha256')==common['criteria_sha256'],
            'Negative control uses different criteria')
    require(evidence.get('smooth')==row.get('smooth'),'Negative-control measured rows disagree')
    control=evaluate_smooth_control(row.get('smooth'),degree=1)
    require(control['valid_evidence'] and control['rejected'],
            'Fixed smooth criteria do not reject the recorded mutant: '+str(control['reasons']))
    require(row.get('rejected') is True and row.get('reasons')==control['reasons']
            and evidence.get('verdict')==control,
            'Negative-control stored verdict differs from recomputed fixed verdict')
    source=Path(solver).read_text()
    needle='        return f, un, np.sqrt(self.gamma*p/rho)'
    require(source.count(needle)==1,'Cannot verify the declared single y-flux mutation')
    expected=source.replace(needle,'        return (-f if axis == 1 else f), (-un if axis == 1 else un), np.sqrt(self.gamma*p/rho)')
    require(mutant_path.read_text()==expected,'Mutant has changes beyond the declared y-flux fault')
    run_metrics=negative/'run/metrics.json'
    if run_metrics.exists():
        run=read_json(run_metrics)
        for key in ('criteria_sha256','runner_sha256','support_sha256'):
            require(run.get(key)==common.get(key),'Negative-control run has different '+key)
        require(run.get('solver_sha256')==digest(mutant_path)
                and run.get('smooth')==row['smooth'],'Negative-control measured run is inconsistent')
    return row,control


def merge(inputs, solver, negative, output):
    output=Path(output).resolve();solver=Path(solver).resolve()
    inputs=[Path(p).resolve() for p in inputs]
    require(len(inputs)==len(set(inputs)),'Duplicate input campaign directory')
    require(output not in inputs,'Output directory must differ from every input shard')
    require(digest(CRITERIA_PATH)==PINNED_CRITERIA_SHA256,'Frozen criteria hash changed')
    common=None;merged=None;seen={s:set() for s in SECTIONS};origins=[]
    raw_sources=[];names=set()
    solver_sha=digest(solver)
    for source in inputs:
        path=source/'metrics.json';metrics=read_json(path)
        bind={k:metrics.get(k) for k in BINDINGS}
        require(bind['schema_version']==1 and bind['criteria_sha256']==PINNED_CRITERIA_SHA256,
                'Shard has wrong schema/frozen criteria: '+str(source))
        require(bind['solver_sha256']==solver_sha,'Shard belongs to a different solver: '+str(source))
        require(bind['runner_sha256']==digest(ROOT/'scripts/run_rkdg_campaign.py'),
                'Shard belongs to a different runner version: '+str(source))
        support=bind['support_sha256']
        require(isinstance(support,dict) and support,'Shard lacks evaluation dependency hashes: '+str(source))
        for dependency,sha in support.items():
            dep=(ROOT/dependency).resolve()
            require(dep.is_relative_to(ROOT) and dep.is_file() and digest(dep)==sha,
                    'Shard evaluation dependency changed: '+dependency)
        if common is None:
            common=bind
            merged=dict(bind,reference_sha256={},smooth=[],directional=[],double_mach=[],temporal=[],negative_controls=[])
        else:
            require(bind==common,'Shards have inconsistent solver/runner/support/criteria bindings: '+str(source))
        require(not metrics.get('negative_controls'),
                'Input shards must exclude controls; provide the separately audited --negative directory')
        references=metrics.get('reference_sha256',{})
        require(isinstance(references,dict),'Invalid shard reference ledger: '+str(source))
        for name,sha in references.items():
            require(name not in merged['reference_sha256'] or merged['reference_sha256'][name]==sha,
                    'Conflicting reference digest: '+name)
            reference=ROOT/'validation/rkdg/references'/name
            require(reference.parent.resolve()==(ROOT/'validation/rkdg/references').resolve()
                    and reference.is_file() and digest(reference)==sha,'Reference file hash mismatch: '+name)
            merged['reference_sha256'][name]=sha
        for section,keys in SECTIONS.items():
            rows=metrics.get(section)
            require(isinstance(rows,list),'Invalid/missing shard section '+section)
            for row in rows:
                require(isinstance(row,dict) and all(k in row for k in keys), 'Malformed shard row in '+section)
                try:identifier=tuple(row[k] for k in keys);duplicate=identifier in seen[section]
                except TypeError:raise MergeError('Malformed case identifier in '+section)
                require(not duplicate,'Duplicate scientific case identifier in '+section+': '+str(identifier))
                seen[section].add(identifier)
                name=array_name(section,row)
                require(name not in names,'Duplicate raw array filename: '+name)
                names.add(name)
                array=source/'arrays'/name
                check_array(array,section,row)
                raw_sources.append((array,name))
                merged[section].append(row)
        # dt/8 is a raw same-grid temporal reference, although not an acceptance row.
        if metrics['temporal']:
            refname='temporal-f8.npz'
            require(refname not in names,'Duplicate temporal reference array')
            names.add(refname)
            refrow=dict(metrics['temporal'][0],factor=8,dt=metrics['temporal'][0]['reference_dt'])
            refpath=source/'arrays'/refname
            check_array(refpath,'temporal',refrow)
            raw_sources.append((refpath,refname))
        origins.append({'root':relative(source,output),'metrics_sha256':digest(path),
                        'environment':metrics.get('environment',{}),
                        'case_counts':{s:len(metrics[s]) for s in SECTIONS}})
    require(common is not None,'No input shards provided')
    control,control_verdict=check_negative(negative,solver,common)
    merged['negative_controls']=[control]
    for section,keys in SECTIONS.items():
        merged[section].sort(key=lambda row:tuple(row[k] for k in keys))
    merged['merge_inputs']=origins
    merged['merge_tool_sha256']=digest(__file__)
    copied=[]
    for source,name in raw_sources:
        copy_bound(source,output/'arrays'/name,copied,output)
    negative=Path(negative).resolve()
    for name in ('control-row.json','evidence.json','wrong_y_flux.py'):
        copy_bound(negative/name,output/'negative-control'/name,copied,output)
    if (negative/'run/metrics.json').exists():
        copy_bound(negative/'run/metrics.json',output/'negative-control/run/metrics.json',copied,output)
        for row in control['smooth']:
            name=array_name('smooth',row);path=negative/'run/arrays'/name
            check_array(path,'smooth',row)
            copy_bound(path,output/'negative-control/run/arrays'/name,copied,output)
    report=evaluate_metrics(merged,expected_solver_sha256=solver_sha)
    write_json(output/'metrics.json',merged)
    manifest={'schema_version':1,'source_bindings':common,'merge_tool_sha256':digest(__file__),
              'inputs':origins,'files':copied,'metrics_sha256':digest(output/'metrics.json'),
              'negative_control_recomputed_verdict':control_verdict,
              'scope':'Byte-preserving merge only; full numerical acceptance is the unchanged fixed evaluator verdict.'}
    write_json(output/'raw-array-manifest.json',manifest)
    report['merge_manifest_sha256']=digest(output/'raw-array-manifest.json')
    write_json(output/'verdict.json',report)
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',nargs='+',required=True,type=Path)
    parser.add_argument('--solver',required=True,type=Path)
    parser.add_argument('--negative',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    try:
        report=merge(args.inputs,args.solver,args.negative,args.output)
    except (MergeError,OSError,ValueError,KeyError,TypeError) as exc:
        report={'passed':False,'failures':['Merge rejected: '+str(exc)],
                'criteria_sha256':PINNED_CRITERIA_SHA256,
                'scope':'No complete acceptance claim; merge provenance or preserved evidence is incomplete/inconsistent.'}
        write_json(args.output/'verdict.json',report)
    print(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
