Actual reversed-x runs / x方向の向きを反転した実計算

The six newly evolved cases are Sod and Shu–Osher, Q1/Q2/Q3, 256x2 cells.
Initial data are T U(xmin+xmax-x,y), including the full reflected Shu density
phase; T negates only x momentum. Both physical x boundaries are outflow.
The final reverse result is mapped to the original coordinate by reversing x
cell order, applying (-1)^m to the Legendre x mode m, and negating x momentum.
It is not a reflected copy of a saved final forward solution.

Frozen before new evolution:
 validation/rkdg/reflection-acceptance.json
 SHA256 ab7986e1eaf768f63fb239bf5a8d766d4c4fc5778389bdc42b5eb294594bf18a

The new strict symmetry qualification is FIVE OF SIX PASS, not all pass.
Shu–Osher Q3 has normalized maximum modal/density-average error 1.48326497e-10,
above the frozen 1e-10 limit. The tolerance was not relaxed. Its relative density
L1 discrepancy is 6.50839042e-12. Conservation and sampled positivity pass.
The visually overlaid profile does not erase this strict qualification failure.

Sod maximum absolute density-cell-average difference, across Q1/Q2/Q3:
 8.434364318077314e-13.
Shu–Osher maximum absolute density-cell-average difference:
 6.631896143360905e-10.

The source is unchanged from the accepted-v3 forward campaign:
 4ed984a01c42fe9bb657c09c61361b086682d6aa611e9f478bf996c0b29b81d4
The original48 and the four added waveform diagnostics remain PASS. This
supplemental reflection test does not rewrite those contracts or histories.
Its failures are preserved in verdict.json and the figure manifest.

日本語要約：初期条件と法線運動量を反転して新しく時間発展させ、座標・モードの
偶奇性・運動量を戻して比較した。両問題の線は表示上重なるが、追加の1e-10という
厳格な最大差基準ではShu–Osher p3のみ1.48e-10で不合格となった。公差は変更せず、
実測差を図と記録に残す。元の48科学ケース＋波形4診断の合格とは別の判定である。
厳密な1D不変部分空間の縮約を使う試験であり、完全2Dの反射対称性保証ではない。

Reproduce in a NEW output directory (existing raw results are never overwritten):
 PYTHONDONTWRITEBYTECODE=1 VECLIB_MAXIMUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python scripts/run_rkdg_reflection.py --workers 3 --output outputs/recheck-x-reflection

The saved campaign above exited 1 for the documented qualification failure.
A repeat must be judged from its actual results, not assumed to pass or fail.
No quantum calculation or heavy independent-reference regeneration was run.

Mapping tests: tests/test_rkdg_reflection.py, 2 passed (helper-tests.log).
Figure: figures/directional-reflection.png and .pdf.
The plot script independently recomputes the coordinate/parity transform from
raw reversed coefficients, with source/array checksums and actual data.

2026-11-23 plot-only display refinements (no new PDE runs):
- figures/directional-reflection.* retains the initial mapped-back overlay.
- figures/directional-reflection-reversed-x.* retains the reversed-coordinate
  view, with original/ref lines reflected and fresh reverse markers.
- FINAL POSTER FIGURE: figures/directional-forward-reverse-x.png / .pdf.
  Blue is the original raw calculation; orange is the fresh reversed raw
  calculation, both on the same ordinary ascending x axis, with no numerical
  reflection for display. Degree Q1/Q2/Q3 uses dotted/dashed/solid lines.
  Gray curves show original and reflected independent references. The separate
  bottom footnote's tiny errors are computed AFTER mapping reverse data back;
  they are not the raw-profile difference in the displayed coordinates.
  figure-forward-reverse-x-manifest.json and forward-reverse-frame-verification.json
  bind this final view to its sources. All previous plots/data remain unchanged.

Final poster notation variant:
 figures/directional-forward-reverse-x-p.png / .pdf
The degree legend now reads p=1, p=2, p=3 (the polynomial degree in tensor Qp).
All data, axes, colors, line styles and symmetry qualifications are unchanged.
The PNG pixel difference is confined to the legend band, rows603–632.
See figure-forward-reverse-x-p-manifest.json and p-legend-verification.json.
No PDE rerun; previous plot versions remain available as history.
