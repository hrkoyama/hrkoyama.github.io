"""The independent acceptance contract rejects scientifically invalid reports."""
import copy
import json

import numpy as np
import pytest

from validation.rkdg.evaluate import (CRITERIA_PATH, PINNED_CRITERIA_SHA256,
    conservative_restrict, conservation_defect, evaluate_metrics, field_errors,
    modal_density_errors, relative_l1, sha256_file, evaluate_smooth_control)


def synthetic_passing_metrics():
    """Contract fixture; these analytic numbers are never campaign evidence."""
    rules=json.loads(CRITERIA_PATH.read_text())
    data={"schema_version":1,"criteria_sha256":PINNED_CRITERIA_SHA256,
          "solver_sha256":"1"*64,"reference_sha256":{"synthetic":"2"*64},
          "smooth":[],"directional":[],"double_mach":[],"temporal":[],
          "negative_controls":[{"name":"wrong-y-flux","rejected":True,"evidence_sha256":"4"*64,
              "reasons":["diagonal exact error fails"],"smooth":[
                  {"p":1,"n":n,"time":.2,"velocity":[1.,.5],
                   "errors":{norm:0.1 for norm in ("l1","l2","linf")},"conservation_defect":0.}
                  for n in rules["smooth"]["levels"]]}]}
    for p in rules["degrees"]:
        for n in rules["smooth"]["levels"]:
            data["smooth"].append({"p":p,"n":n,"time":.2,"velocity":[1.,.5],
                "errors":{norm:n**(-p-1) for norm in ("l1","l2","linf")},"conservation_defect":1e-14})
        for problem in ("sod","shu-osher"):
            for axis in (0,1):
                for n in (128,256):
                    data["directional"].append({"p":p,"problem":problem,"axis":axis,"n":n,
                        "time":.2 if problem=="sod" else 1.8,"error_l1":2/n,
                        "transverse":0.,"axis_difference":0.,"conservation_defect":1e-14,
                        "min_density":.1,"min_pressure":.1,
                        "reference_kind":"exact-riemann" if problem=="sod" else "independent-fv"})
        for ny in (16,24,32):
            data["double_mach"].append({"p":p,"ny":ny,"time":.2,"error_l1":1/ny,
                "reference_grid_change_l1":.02,"conservation_defect":1e-14,
                "min_density":1.,"min_pressure":1.,"reference_kind":"independent-fv"})
    for factor in (1,2,4):
        data["temporal"].append({"p":3,"n":16,"time":.2,"factor":factor,
            "dt":.001/factor,"reference_dt":.001/8,"error_l2":1e-6/factor**4})
    return data


def test_frozen_criteria_match_pin_and_complete_contract():
    assert sha256_file(CRITERIA_PATH)==PINNED_CRITERIA_SHA256
    report=evaluate_metrics(synthetic_passing_metrics(),expected_solver_sha256="1"*64)
    assert report["passed"],report["failures"]
    assert report["case_counts"]=={"smooth":12,"directional":24,"double_mach":9,"temporal":3,"negative_controls":1}


@pytest.mark.parametrize("mutation",["missing","duplicate","wrong_time","nonfinite","stale_solver","wrong_velocity","bad_order","negative_pressure","no_mutant","wrong_axis","tampered_error_shape","inconsistent_dt","bad_reference"])
def test_fixed_evaluator_rejects_invalid_scientific_evidence(mutation):
    data=synthetic_passing_metrics()
    if mutation=="missing":data["directional"].pop()
    elif mutation=="duplicate":data["smooth"].append(copy.deepcopy(data["smooth"][0]))
    elif mutation=="wrong_time":data["double_mach"][0]["time"]=.02
    elif mutation=="nonfinite":data["smooth"][0]["errors"]["l1"]=float("nan")
    elif mutation=="stale_solver":data["solver_sha256"]="3"*64
    elif mutation=="wrong_velocity":data["smooth"][0]["velocity"]=[1.,0.]
    elif mutation=="bad_order":
        for row in data["smooth"]:
            if row["p"]==3:row["errors"]={norm:row["n"]**-3 for norm in ("l1","l2","linf")}
    elif mutation=="negative_pressure":data["directional"][0]["min_pressure"]=-1e-12
    elif mutation=="no_mutant":data["negative_controls"][0]["rejected"]=False
    elif mutation=="wrong_axis":data["directional"][0]["axis"]=True
    elif mutation=="tampered_error_shape":data["smooth"][0]["errors"]="nonsense"
    elif mutation=="inconsistent_dt":data["temporal"][1]["dt"]*=1.1
    elif mutation=="bad_reference":data["reference_sha256"]={"fv":"not-a-digest"}
    report=evaluate_metrics(data,expected_solver_sha256="1"*64)
    assert not report["passed"]
    assert report["failures"]


def test_criteria_edit_cannot_silently_change_acceptance(tmp_path):
    changed=json.loads(CRITERIA_PATH.read_text())
    changed["smooth"]["order_margin"]["l1"]=99
    path=tmp_path/"acceptance.json"
    path.write_text(json.dumps(changed))
    data=synthetic_passing_metrics();data["criteria_sha256"]=sha256_file(path)
    result=evaluate_metrics(data,criteria_path=path)
    assert result["failures"]==["Frozen acceptance.json hash changed"]


def test_noninteger_reference_restriction_preserves_integral_in_both_axes():
    rng=np.random.default_rng(42)
    q=rng.uniform(.5,2.,size=(23,17,4))
    reduced=conservative_restrict(q,(8,6))
    assert reduced.shape==(8,6,4)
    np.testing.assert_allclose(reduced.mean(axis=(0,1)),q.mean(axis=(0,1)),rtol=2e-15,atol=1e-15)
    assert reduced.min()>=q.min() and reduced.max()<=q.max()
    np.testing.assert_allclose(conservative_restrict(np.ones((32,32)),(24,24)),1,atol=1e-14)


def test_reconstruction_errors_measure_subcell_modes_not_only_cell_average():
    coeff=np.zeros((2,3,4,4,4));coeff[...,0,0,0]=1.
    coeff[...,3,0,0]=.1
    # Every cell average is exactly one, but cubic reconstruction is not.
    error=modal_density_errors(coeff,lambda x,y,t:np.ones_like(x))
    assert error["l1"]>0.02 and error["linf"]>0.05
    assert error["l2"]==pytest.approx(.1/np.sqrt(7),rel=1e-13)


def test_normalized_errors_and_boundary_balance_have_declared_meaning():
    assert field_errors([1,3],[0,0],[1,3])["l1"]==2.5
    assert relative_l1([2,4],[1,2])==1.
    assert conservation_defect([1,2,3,4],[.8,2.1,3,3.5],[.2,-.1,0,.5])<1e-15
    assert conservation_defect([1,2,3,4],[.8,2.1,3,3.5],[0,0,0,0])==pytest.approx(.2)
    with pytest.raises(ValueError):relative_l1([1],[0])
    with pytest.raises(ValueError):field_errors([np.nan],[1])


def test_negative_control_requires_measured_failure_not_self_reported_flag():
    data=synthetic_passing_metrics()
    positive=[copy.deepcopy(r) for r in data["smooth"] if r["p"]==1]
    control=evaluate_smooth_control(positive)
    assert control["valid_evidence"] and not control["rejected"]
    data["negative_controls"][0]["smooth"]=positive
    assert not evaluate_metrics(data)["passed"]
    # Missing numerical evidence is an incomplete control, not a detected fault.
    control=evaluate_smooth_control(positive[:-1])
    assert not control["valid_evidence"] and not control["rejected"]
    genuine=evaluate_smooth_control(synthetic_passing_metrics()["negative_controls"][0]["smooth"])
    assert genuine["valid_evidence"] and genuine["rejected"]
    assert genuine["observed_orders"][0]["orders"]==[0.,0.,0.]
