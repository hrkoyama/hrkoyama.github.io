"""Supplemental resolution tests use synthetic saved-array fixtures, not PDE evidence."""
import json
from pathlib import Path

import numpy as np
import pytest

from validation.rkdg.resolution import (ROOT,CRITERIA_PATH,PINNED_RESOLUTION_SHA256,
    PINNED_ORIGINAL_SHA256,PINNED_REFERENCE_SHA256,digest,evaluate_resolution,
    remap_density,resolution_metrics)


def test_roi_statistics_distinguish_phase_amplitude_and_global_average():
    x=np.linspace(0,3,301)
    reference=4+.7*np.sin(8*x)
    actual=4+.42*np.sin(8*x)
    measured=resolution_metrics(actual,reference,x)
    assert measured['demeaned_standard_deviation_ratio']==pytest.approx(.6)
    assert measured['pearson_correlation']==pytest.approx(1.)
    reversed_wave=4-.7*np.sin(8*x)
    assert resolution_metrics(reversed_wave,reference,x)['pearson_correlation']==pytest.approx(-1.)
    with pytest.raises(ValueError,match='undefined'):resolution_metrics(np.ones_like(x),reference,x)
    with pytest.raises(ValueError,match='nonfinite'):resolution_metrics(actual*np.nan,reference,x)


def test_reference_remap_preserves_uniform_cell_average_on_noninteger_ratios():
    reference=1+np.sin(np.arange(3200)*.1)**2
    target=remap_density(reference,np.linspace(-5,5,3201),np.linspace(-5,5,257))
    assert target.mean()==pytest.approx(reference.mean(),rel=2e-15)
    with pytest.raises(ValueError,match='domains differ'):
        remap_density(reference,np.linspace(-5,5,3201),np.linspace(-4,5,257))


@pytest.fixture
def synthetic_campaign(tmp_path):
    """Perfectly matching FV-constant array fixture, explicitly not a solver run."""
    candidate=tmp_path/'synthetic-candidate.py'
    candidate.write_text('# This is a synthetic provenance fixture, never a PDE result.\n')
    output=tmp_path/'campaign';(output/'arrays').mkdir(parents=True)
    reference_path=ROOT/'validation/rkdg/references/shu-osher-n3200.npz'
    with np.load(reference_path) as reference:
        edges=np.linspace(-5,5,257)
        density=remap_density(reference['q'][:,0],reference['x_edges'],edges)
    support={name:digest(ROOT/name) for name in ('validation/rkdg/evaluate.py','numart/riemann.py','numart/equations.py')}
    metrics={'schema_version':1,'criteria_sha256':PINNED_ORIGINAL_SHA256,
             'solver_sha256':digest(candidate),'runner_sha256':digest(ROOT/'scripts/run_rkdg_campaign.py'),
             'support_sha256':support,'reference_sha256':{'shu-osher-n3200.npz':PINNED_REFERENCE_SHA256},
             'directional':[]}
    for p in (2,3):
        for axis in (0,1):
            shape=(256,2) if axis==0 else (2,256)
            q=np.zeros(shape+(4,));q[...,0]=density[:,None] if axis==0 else density[None,:];q[...,3]=2.5
            coeff=np.zeros(shape+(p+1,p+1,4));coeff[:,:,0,0,:]=q
            row={'problem':'shu-osher','p':p,'n':256,'axis':axis,'time':1.8,
                 'error_l1':0.,'conservation_defect':0.,'min_density':float(density.min()),
                 'min_pressure':1.,'transverse':0.,'axis_difference':0.,'reference_kind':'independent-fv'}
            metrics['directional'].append(row)
            config={'degree':p,'nx':shape[0],'ny':shape[1],'bounds':[-5.,5.,0.,1.] if axis==0 else [0.,1.,-5.,5.],
                    'boundary':'outflow','limiter':'tvb','time':1.8}
            diag={'final_time':1.8,'steps':1,'recorded_step_count':1}
            np.savez_compressed(output/'arrays'/f'shu-osher-p{p}-a{axis}-n256.npz',q=q,coeff=coeff,
                x_edges=edges if axis==0 else np.linspace(0,1,3),y_edges=np.linspace(0,1,3) if axis==0 else edges,
                step_times=np.array([0.,1.8]),config=json.dumps(config),diagnostics=json.dumps(diag))
    (output/'metrics.json').write_text(json.dumps(metrics))
    return output,candidate,metrics


def test_complete_synthetic_resolution_fixture_passes_without_claiming_old48(synthetic_campaign):
    campaign,candidate,_=synthetic_campaign
    report=evaluate_resolution(campaign,candidate)
    assert report['passed'],report['failures']
    assert report['diagnostic_checks']==4
    assert 'original_verdict_record' not in report
    assert all(row['metrics']['pearson_correlation']==pytest.approx(1.) for row in report['cases'])
    assert digest(CRITERIA_PATH)==PINNED_RESOLUTION_SHA256


@pytest.mark.parametrize('fault',['missing','duplicate','source_hash','reference_hash','nonfinite_metric','raw_nonfinite','raw_bounds','raw_time','raw_steps','forged_global_error','low_amplitude'])
def test_resolution_rejects_incomplete_nonfinite_or_unbound_evidence(synthetic_campaign,fault):
    campaign,candidate,metrics=synthetic_campaign
    if fault=='missing':metrics['directional'].pop()
    elif fault=='duplicate':metrics['directional'].append(dict(metrics['directional'][0]))
    elif fault=='source_hash':metrics['solver_sha256']='0'*64
    elif fault=='reference_hash':metrics['reference_sha256']['shu-osher-n3200.npz']='0'*64
    elif fault=='nonfinite_metric':metrics['directional'][0]['min_pressure']=float('nan')
    elif fault=='forged_global_error':metrics['directional'][0]['error_l1']=.1
    else:
        path=campaign/'arrays/shu-osher-p2-a0-n256.npz'
        with np.load(path) as f:data={k:np.array(f[k]) for k in f.files}
        if fault=='raw_nonfinite':data['coeff'][0,0,0,0,0]=np.nan
        elif fault=='raw_bounds':
            config=json.loads(str(data['config']));config['bounds']=[-4.,5.,0.,1.];data['config']=json.dumps(config)
        elif fault=='raw_time':
            config=json.loads(str(data['config']));config['time']=1.;data['config']=json.dumps(config)
        elif fault=='raw_steps':data['step_times']=np.array([0.,0.])
        elif fault=='low_amplitude':
            rho=data['q'][:,:,0];mean=float(rho.mean());rho[:]=mean+.1*(rho-mean)
            data['coeff'][:,:,0,0,:]=data['q']
            with np.load(ROOT/'validation/rkdg/references/shu-osher-n3200.npz') as reference:
                ref=remap_density(reference['q'][:,0],reference['x_edges'],data['x_edges'])
            metrics['directional'][0]['error_l1']=float(np.sum(abs(rho.mean(1)-ref))/np.sum(abs(ref)))
        np.savez_compressed(path,**data)
    (campaign/'metrics.json').write_text(json.dumps(metrics))
    result=evaluate_resolution(campaign,candidate)
    assert not result['passed']
    assert result['failures']
    if fault=='low_amplitude':assert any('standard-deviation ratio' in f for f in result['failures'])


def test_resolution_pin_rejects_relaxed_threshold_even_with_forged_new_digest(synthetic_campaign,tmp_path):
    campaign,candidate,_=synthetic_campaign
    rules=json.loads(CRITERIA_PATH.read_text());rules['max_relative_l1_density']=1.
    changed=tmp_path/'relaxed.json';changed.write_text(json.dumps(rules))
    result=evaluate_resolution(campaign,candidate,criteria_path=changed)
    assert not result['passed'] and result['failures']==['Frozen supplemental resolution criteria hash changed']
