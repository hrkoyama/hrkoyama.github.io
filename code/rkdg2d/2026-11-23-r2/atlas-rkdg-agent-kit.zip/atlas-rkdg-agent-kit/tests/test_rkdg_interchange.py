"""Portable output invariants, not a claim of MPI or foreign-solver execution."""
import csv
import json
from pathlib import Path

import numpy as np
import pytest

from validation.rkdg.interchange import (BASIS, COLUMNS, DEFAULT_ATOL, InterchangeError,
    compare_reference_manifest, compare_runs, entropy_metrics, export_reference_npz,
    load_run, physical_diagnostics, sha256)


def manufactured_npz(tmp_path):
    """A nonuniform but physical modal field, independent of the solver."""
    coeff = np.zeros((5, 3, 3, 3, 4))
    rho = 1.1+.03*np.arange(5)[:, None]+.02*np.arange(3)[None, :]
    u, v = .3, -.2
    coeff[:, :, 0, 0, :] = np.stack((rho, rho*u, rho*v, 2.5+.5*rho*(u*u+v*v)), -1)
    perturbation = np.array([1., u, v, .5*(u*u+v*v)])
    coeff[:, :, 1, 0, :] = .01*perturbation
    coeff[:, :, 0, 2, :] = -.004*perturbation
    config = dict(nx=5, ny=3, degree=2, time=.2, bounds=[0., 1., 0., 1.], boundary='periodic')
    integral = coeff[:, :, 0, 0, :].mean(axis=(0, 1)).tolist()
    diagnostics = dict(initial_integral=integral, final_integral=integral,
                       integrated_boundary_outflow=[0., 0., 0., 0.])
    path = tmp_path/'smooth-manufactured.npz'
    np.savez(path, coeff=coeff, config=json.dumps(config), diagnostics=json.dumps(diagnostics))
    return path, coeff


def rewrite_manifest(path, mutation):
    d = json.loads(path.read_text()); mutation(d)
    path.write_text(json.dumps(d)); return d


def alter_rows(manifest, mutation, rank=0):
    d = json.loads(manifest.read_text()); path = manifest.parent/d['partitions'][rank]['file']
    with path.open(newline='') as stream: rows = list(csv.reader(stream))
    mutation(rows)
    with path.open('w', newline='') as stream: csv.writer(stream).writerows(rows)
    d['partitions'][rank]['sha256'] = sha256(path)
    manifest.write_text(json.dumps(d))


@pytest.mark.parametrize('ranks', [1, 2, 4])
def test_shuffled_owned_partitions_reconstruct_all_fields_and_reuse_norms(tmp_path, ranks):
    path, coeff = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/f'ranks{ranks}', ranks=ranks, shuffle=True)
    run = load_run(manifest)
    np.testing.assert_array_equal(run.coefficients, coeff)
    np.testing.assert_array_equal(run.cell_averages, coeff[:, :, 0, 0, :])
    assert run.metadata['basis'] == BASIS
    assert run.provenance['mpi_execution_verified'] is False
    report = compare_reference_manifest(manifest, path)
    assert report['passed'] and report['maximum_absolute_difference'] == 0.
    assert report['conservation_checked'] and report['conservation_passed']
    assert report['boundary_flux_corrected_conservation_defect'] == 0.
    assert report['density_errors'] == entropy_metrics(run)
    assert physical_diagnostics(run)['positive_at_declared_points']


def test_serial_and_partitioned_fixture_have_same_physics_without_bitwise_file_equality(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    serial = export_reference_npz(path, tmp_path/'serial')
    parallel = export_reference_npz(path, tmp_path/'partitioned', ranks=4, shuffle=True)
    assert sha256(serial) != sha256(parallel)
    result = compare_runs(serial, parallel)
    assert result['passed'] and result['candidate_rank_count'] == 4
    assert not result['mpi_execution_verified']


@pytest.mark.parametrize('mutation', ['missing', 'duplicate', 'ghost', 'bad_mode', 'float_index', 'unknown_column', 'nonfinite', 'bad_value'])
def test_invalid_partition_evidence_is_rejected_even_with_updated_csv_checksum(tmp_path, mutation):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data', ranks=2)
    def change(rows):
        if mutation == 'missing': rows.pop()
        elif mutation == 'duplicate': rows.append(rows[1][:])
        elif mutation == 'ghost': rows[1][0] = '5'
        elif mutation == 'bad_mode': rows[1][2] = '3'
        elif mutation == 'float_index': rows[1][0] = '1.0'
        elif mutation == 'unknown_column': rows[0][-1] = 'pressure'
        elif mutation == 'nonfinite': rows[1][4] = 'nan'
        elif mutation == 'bad_value': rows[1][4] = 'not-a-number'
    alter_rows(manifest, change)
    with pytest.raises(InterchangeError): load_run(manifest)


@pytest.mark.parametrize('field,value', [('time', float('nan')), ('gamma', 1.67), ('dtype', 'float32'),
    ('variables', ['rho', 'rho_v', 'rho_u', 'energy']), ('degree', True), ('case', 'unknown'),
    ('global_shape', [5, 3.0]), ('basis', {'family': 'nodal'}), ('rank_count', 3)])
def test_physical_and_representation_metadata_cannot_be_silently_reinterpreted(tmp_path, field, value):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    rewrite_manifest(manifest, lambda d: d.__setitem__(field, value))
    with pytest.raises(InterchangeError): load_run(manifest)


def test_wrong_finite_horizon_or_domain_rejected_against_reference(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    rewrite_manifest(manifest, lambda d: d.__setitem__('time', .2001))
    with pytest.raises(InterchangeError, match='time'): compare_reference_manifest(manifest, path)
    rewrite_manifest(manifest, lambda d: d.update(time=.2, bounds=[0., 2., 0., 1.]))
    with pytest.raises(InterchangeError, match='bounds'): compare_reference_manifest(manifest, path)


def test_full_modal_comparison_detects_errors_hidden_in_cell_average(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    def corrupt(rows):
        row = next(r for r in rows[1:] if r[:4] == ['0', '0', '2', '2'])
        row[4] = '.02'
    alter_rows(manifest, corrupt)
    report = compare_reference_manifest(manifest, path)
    assert not report['passed'] and report['mismatched_coefficients'] == 1
    np.testing.assert_array_equal(report['integral_difference'], 0.)


def test_roundoff_tolerance_is_explicit_and_large_changes_fail(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    # An inactive mode has a zero reference, so this exercises absolute tolerance.
    def perturb(rows):
        row = next(r for r in rows[1:] if r[:4] == ['0', '0', '2', '2'])
        row[4] = repr(DEFAULT_ATOL/2)
    alter_rows(manifest, perturb)
    assert compare_reference_manifest(manifest, path)['passed']
    assert not compare_reference_manifest(manifest, path, atol=0., rtol=0.)['passed']


def test_hash_corruption_unknown_fields_and_source_path_escape_are_rejected(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    rewrite_manifest(manifest, lambda d: d['partitions'][0].__setitem__('sha256', '0'*64))
    with pytest.raises(InterchangeError, match='digest'): load_run(manifest)
    rewrite_manifest(manifest, lambda d: d.__setitem__('made_up', 1))
    with pytest.raises(InterchangeError, match='Unknown manifest'): load_run(manifest)
    rewrite_manifest(manifest, lambda d: (d.pop('made_up'), d['partitions'][0].__setitem__('file', '../secret.csv')))
    with pytest.raises(InterchangeError, match='relative descendants'): load_run(manifest)


def test_cell_owned_by_multiple_rank_files_is_rejected(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data', ranks=2)
    d = json.loads(manifest.read_text())
    paths = [manifest.parent/p['file'] for p in d['partitions']]
    with paths[0].open(newline='') as f: a = list(csv.reader(f))
    with paths[1].open(newline='') as f: b = list(csv.reader(f))
    b.append(a.pop())
    for i, rows in enumerate((a,b)):
        with paths[i].open('w',newline='') as f: csv.writer(f).writerows(rows)
        d['partitions'][i]['sha256'] = sha256(paths[i])
    manifest.write_text(json.dumps(d))
    with pytest.raises(InterchangeError, match='split across'): load_run(manifest)


def test_nonphysical_output_fails_even_when_numerically_close_tolerances_are_wide(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    def corrupt(rows):
        row = next(r for r in rows[1:] if r[:4] == ['0', '0', '0', '0'])
        row[7] = '0.001'
    alter_rows(manifest, corrupt)
    report = compare_reference_manifest(manifest, path, atol=10., rtol=1.)
    assert not report['passed'] and not report['positive_at_declared_points']


def test_known_but_wrong_case_cannot_relabel_the_trusted_reference(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    rewrite_manifest(manifest, lambda d: d.__setitem__('case', 'temporal-entropy-wave'))
    with pytest.raises(InterchangeError, match='case'):
        compare_reference_manifest(manifest, path)


def test_foreign_language_io_fixture_is_distinguished_from_solver_execution(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data', case='polynomial-io-fixture')
    rewrite_manifest(manifest, lambda d: d.__setitem__('execution_kind', 'foreign-language-io-fixture'))
    assert load_run(manifest).metadata['case'] == 'polynomial-io-fixture'
    rewrite_manifest(manifest, lambda d: d.__setitem__('execution_kind', 'solver-output'))
    with pytest.raises(InterchangeError, match='not a PDE'):
        load_run(manifest)


def test_incorrect_outflow_fails_physical_conservation_despite_identical_modal_output(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    # This models counting an internal MPI face as physical boundary outflow.
    # All modes AND the declared final integral still match the trusted field.
    rewrite_manifest(manifest, lambda d: d['diagnostics']['integrated_boundary_outflow'].__setitem__(0, 1e-5))
    result = compare_reference_manifest(manifest, path, atol=1., rtol=1.)
    assert not result['passed']
    assert result['mismatched_coefficients'] == 0
    assert result['declared_final_integral_matches_coefficients']
    assert result['conservation_checked'] and not result['conservation_passed']
    assert result['max_normalized_conservation_defect'] == 1e-9
    assert result['boundary_flux_corrected_conservation_defect'] > 1e-9


def test_absent_optional_boundary_diagnostics_explicitly_mark_conservation_unchecked(tmp_path):
    path, _ = manufactured_npz(tmp_path)
    manifest = export_reference_npz(path, tmp_path/'data')
    rewrite_manifest(manifest, lambda d: d.pop('diagnostics'))
    result = compare_reference_manifest(manifest, path)
    assert result['passed'] and result['conservation_checked'] is False
    assert 'conservation_passed' not in result
