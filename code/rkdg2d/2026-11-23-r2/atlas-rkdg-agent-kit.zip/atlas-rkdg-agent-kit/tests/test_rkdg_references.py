"""Independent reference checks; no imports from the RKDG implementation."""
import numpy as np
from pathlib import Path
import hashlib
import json

from validation.rkdg.reference import (conserved, primitive, flux, hll,
    _weno_left, _rhs_1d, initial_1d, solve_1d, solve_double_mach,
    double_mach_states)


def test_reference_flux_consistency_and_stationary_contact():
    left = conserved([[1., 0., 0., 1.], [.8, .7, -.2, 1.3]])
    for axis in (0, 1):
        np.testing.assert_allclose(hll(left, left, axis), flux(left, axis), atol=1e-14)
    right = conserved([[.125, 0., 0., 1.]])
    np.testing.assert_allclose(hll(left[:1], right, contact=True), [[0., 1., 0., 0.]], atol=1e-14)


def test_weno_reconstruction_exact_for_constant_and_linear_cell_averages():
    x = np.arange(16, dtype=float)
    q = np.stack((2+0*x, 1+.1*x), axis=-1)
    reconstructed = _weno_left(q)
    np.testing.assert_allclose(reconstructed[:, 0], 2., atol=1e-14)
    np.testing.assert_allclose(reconstructed[:, 1], 1+.1*(x[2:-2]+.5), atol=1e-14)


def test_reference_operator_telescopes_and_uses_actual_cell_averages():
    edges, q = initial_1d('shu-osher', 200)
    rhs, inflow, fallback = _rhs_1d(q, edges[1]-edges[0])
    np.testing.assert_allclose((edges[1]-edges[0])*rhs.sum(axis=0), inflow, atol=1e-12)
    assert fallback == 0
    mask = edges[:-1] >= -4
    expected = 1+.2*(np.cos(5*edges[:-1])-np.cos(5*edges[1:]))/(5*np.diff(edges))
    np.testing.assert_allclose(q[mask, 0], expected[mask], atol=1e-14)


def test_independent_sod_refines_toward_exact_riemann_solution():
    # An exact solution is an independent check on this numerical reference.
    from numart.riemann import exact_euler
    errors = []
    for n in (100, 200):
        result = solve_1d('sod', n=n, final_time=.2)
        x = .5*(result.x_edges[1:]+result.x_edges[:-1])
        exact = exact_euler((x-.5)/.2)
        errors.append(np.mean(abs(result.q[:, 0]-exact[:, 0])))
        np.testing.assert_allclose(result.diagnostics['balance_residual'], 0., atol=1e-12)
    assert errors[1] < .8*errors[0]
    assert errors[1] < .008


def test_double_mach_reference_jump_and_balance():
    hot, cold = double_mach_states()
    direction = np.array((np.sqrt(3)/2, -.5))
    fn = lambda q: direction[0]*flux(q, 0)+direction[1]*flux(q, 1)
    np.testing.assert_allclose(fn(hot)-fn(cold), 10*(hot-cold), rtol=1e-13, atol=1e-11)
    result = solve_double_mach(ny=8, final_time=.01)
    assert result.q.shape == (32, 8, 4)
    assert np.all(primitive(result.q)[..., (0, 3)] > 0)
    np.testing.assert_allclose(result.diagnostics['balance_residual'], 0., atol=5e-11)


def test_frozen_reference_integrity_and_grid_uncertainty():
    """Detect stale/corrupt arrays and assess finite-reference resolution."""
    directory = Path(__file__).parents[1]/'validation/rkdg/references'
    source = directory.parent/'reference.py'
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    arrays = {}
    for name in ('shu-osher-n800', 'shu-osher-n1600', 'shu-osher-n3200',
                 'double-mach-ny64', 'double-mach-ny128'):
        path = directory/(name+'.npz')
        meta = json.loads(path.with_suffix('.json').read_text())
        assert meta['npz_sha256'] == hashlib.sha256(path.read_bytes()).hexdigest()
        assert meta['source_sha256'] == digest
        data = np.load(path)
        assert list(data['q'].shape) == meta['shape']
        assert float(data['time']) == meta['time']
        assert np.all(primitive(data['q'])[..., (0, 3)] > 0)
        arrays[name] = data['q'][..., 0]
    differences = []
    for coarse, fine in (('shu-osher-n800','shu-osher-n1600'),
                         ('shu-osher-n1600','shu-osher-n3200')):
        a, b = arrays[coarse], arrays[fine]
        restricted = b.reshape(len(a), 2).mean(axis=1)
        differences.append(np.mean(abs(a-restricted))/np.mean(abs(restricted)))
    assert differences[1] < differences[0]
    assert differences[1] < .005
    coarse, fine = arrays['double-mach-ny64'], arrays['double-mach-ny128']
    restricted = fine.reshape(coarse.shape[0],2,coarse.shape[1],2).mean(axis=(1,3))
    assert np.mean(abs(coarse-restricted))/np.mean(abs(restricted)) < .15
