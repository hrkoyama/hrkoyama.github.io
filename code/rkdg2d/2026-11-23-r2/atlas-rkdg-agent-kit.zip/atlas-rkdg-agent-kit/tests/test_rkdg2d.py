"""Small structural tests; the full frozen campaign is in validation/rkdg."""
import numpy as np
import pytest
from numart.rkdg2d import DG2D, conserved, pressure, entropy_wave, sod, double_mach


@pytest.mark.parametrize('degree', (1, 2, 3))
def test_modal_projection_and_freestream(degree):
    dg = DG2D(5, 3, degree, bounds=(-1., 2., -.5, .5))
    # Polynomial density with constant pressure/velocity is exactly representable.
    fun = lambda x, y: conserved(2+.1*x+.2*y+.05*x*y, .3, -.2, 1.)
    coeff = dg.project(fun)
    x, y = dg.coordinates([-1., -.23, .31, 1.])
    np.testing.assert_allclose(dg.sample(coeff, [-1., -.23, .31, 1.]), fun(x, y), atol=2e-13)
    coeff = dg.project(lambda x, y: conserved(np.ones_like(x), .3, -.2, 1.))
    np.testing.assert_allclose(dg.rhs(coeff), 0., atol=2e-12)


@pytest.mark.parametrize('degree', (1, 2, 3))
def test_periodic_euler_entropy_wave_spatial_order_and_conservation(degree):
    errors = []
    for n in (4, 8, 16):
        dg = DG2D(n, n, degree)
        result = dg.evolve(dg.project(entropy_wave), .035)
        z, w = np.polynomial.legendre.leggauss(6)
        x, y = dg.coordinates(z)
        # Independent exact expression, with density wave advected by (1,.5).
        exact = 1+.2*np.sin(2*np.pi*(x+y-1.5*.035))
        error = dg.sample(result.coeff, z)[..., 0]-exact
        errors.append(np.sqrt(.25*np.einsum('a,b,ijab->', w, w, error**2)/n**2))
        np.testing.assert_allclose(result.diagnostics['conservation_defect'], 0., atol=3e-13)
    assert min(np.log2(np.array(errors[:-1])/errors[1:])) > degree+.55


def test_scaling_repairs_point_values_but_never_changes_cell_averages():
    dg = DG2D(2, 2, 3)
    coeff = np.zeros((2, 2, 4, 4, 4))
    coeff[:, :, 0, 0] = conserved(1., .2, -.3, 1.)
    coeff[:, :, 1, 0, 0] = 2.5  # Negative endpoint density before limiting.
    coeff[:, :, 0, 2, 3] = -7.  # Negative pressures even after density limiting.
    initial = coeff[:, :, 0, 0].copy()
    fixed = dg.stabilize(coeff)
    np.testing.assert_array_equal(fixed[:, :, 0, 0], initial)
    q = dg._checkpoints(fixed)
    assert q[..., 0].min() > 0
    assert pressure(q).min() > 0
    coeff[:, :, 0, 0, 0] = -1
    with pytest.raises(ValueError, match='Nonphysical cell average'):
        dg.stabilize(coeff)


@pytest.mark.parametrize('degree', (1, 2, 3))
def test_tvb_shock_limiter_preserves_means_and_xy_rotation(degree):
    xdg = DG2D(30, 2, degree, boundary='outflow', limiter='tvb')
    ydg = DG2D(2, 30, degree, boundary='outflow', limiter='tvb')
    xc = xdg.project(sod)
    yc = ydg.project(lambda x, y: sod(x, y, axis=1))
    np.testing.assert_allclose(xdg.integral(xdg.stabilize(xc)), xdg.integral(xc), atol=1e-14)
    xr = xdg.evolve(xc, .025)
    yr = ydg.evolve(yc, .025)
    expected = xr.coeff.transpose(1, 0, 3, 2, 4)[..., [0, 2, 1, 3]]
    np.testing.assert_allclose(yr.coeff, expected, atol=3e-13)
    np.testing.assert_allclose(xr.diagnostics['conservation_defect'], 0., atol=2e-13)
    assert xr.diagnostics['minimum_cell_average_pressure'] > 0


def test_double_mach_boundary_times_wall_and_flux_balance():
    dg = DG2D(24, 6, 2, bounds=(0, 4, 0, 1), boundary='double-mach', limiter='tvb')
    coeff = dg.stabilize(dg.project(double_mach))
    xl, xr, yl, yr = dg._boundary_traces(coeff, 0.)
    _, _, _, later = dg._boundary_traces(coeff, .1)
    assert np.count_nonzero(later[:, -1, :, 0] == 8) > np.count_nonzero(yr[:, -1, :, 0] == 8)
    xf = dg.x[:, None]+dg.dx*.5*dg.z
    wall = xf >= 1/6
    flux = dg._hll(yl[:, 0], yr[:, 0], 1)
    np.testing.assert_allclose(flux[..., 0][wall], 0., atol=1e-13)
    np.testing.assert_allclose(flux[..., 3][wall], 0., atol=1e-11)
    result = dg.evolve(coeff, .003)
    assert result.time == .003
    assert result.steps > 1
    np.testing.assert_allclose(result.diagnostics['conservation_defect'], 0., atol=3e-12)


def test_reject_invalid_parameters():
    for nx, ny, p in ((0, 2, 1), (2, 0, 1), (2, 2, 0), (2, 2, 4), (2, 2, True)):
        with pytest.raises(ValueError):
            DG2D(nx, ny, p)
    with pytest.raises(ValueError):
        DG2D(2, 2, 3, quadrature=3)
    dg = DG2D(2, 2, 1)
    with pytest.raises(ValueError):
        dg.evolve(dg.project(entropy_wave), .1, dt_max=0.)


@pytest.mark.parametrize('degree', (1, 2, 3))
def test_decimal_output_horizon_does_not_create_a_roundoff_sized_extra_step(degree):
    dg = DG2D(6, 2, degree, bounds=(0, 4, 0, 1),
              boundary='double-mach', limiter='tvb')
    start, end = .005, .005+3e-5
    coeff = dg.project(lambda x, y: double_mach(x, y, start))
    result = dg.evolve(coeff, end, initial_time=start, cfl=.1, dt_max=1e-5)
    assert result.time == end
    assert result.steps == 3
    assert result.diagnostics['rejected_steps'] == 0
    np.testing.assert_allclose(result.diagnostics['conservation_defect'], 0., atol=2e-12)
