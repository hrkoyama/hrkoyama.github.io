"""Independent mathematical/structural checks of characteristic TVB limiting.

The Euler flux Jacobian below is obtained from an independent complex-step
expression.  Tests vary gamma, all four state components, orientation and
Galilean frame; no benchmark solution or campaign tolerance is used here.
"""
import hashlib
import importlib.util
from pathlib import Path
import sys

import numpy as np
import pytest


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT/'agent-kits/rkdg2d/generated/rkdg2d.py'
SOURCE_BEFORE = CANDIDATE.read_bytes()
SOURCE_SHA256 = hashlib.sha256(SOURCE_BEFORE).hexdigest()
spec = importlib.util.spec_from_file_location('_independent_characteristic_candidate', CANDIDATE)
candidate = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = candidate
spec.loader.exec_module(candidate)


def independent_conserved(rho, u, v, p, gamma):
    return np.stack((rho, rho*u, rho*v,
                     p/(gamma-1)+.5*rho*(u*u+v*v)), axis=-1)


def independent_flux(q, gamma):
    rho, mx, my, energy = np.moveaxis(q, -1, 0)
    p = (gamma-1)*(energy-(mx*mx+my*my)/(2*rho))
    return np.stack((mx, mx*mx/rho+p, mx*my/rho,
                     (energy+p)*mx/rho), axis=-1)


def physical_states(gamma, seed=761):
    rng = np.random.default_rng(seed)
    rho = rng.uniform(.15, 3., (4, 7))
    u = rng.uniform(-1.8, 2.1, rho.shape)
    v = rng.uniform(-2.3, 1.2, rho.shape)
    p = rng.uniform(.12, 2.4, rho.shape)
    return independent_conserved(rho, u, v, p, gamma)


def galilean_transform(q, normal_boost, tangent_boost):
    rho, mx, my, energy = np.moveaxis(q, -1, 0)
    return np.stack((rho, mx+normal_boost*rho, my+tangent_boost*rho,
                     energy+normal_boost*mx+tangent_boost*my
                     +.5*(normal_boost**2+tangent_boost**2)*rho), axis=-1)


def test_source_unchanged_and_canonical_copy_identical():
    assert CANDIDATE.read_bytes() == SOURCE_BEFORE
    assert (ROOT/'numart/rkdg2d.py').read_bytes() == SOURCE_BEFORE


@pytest.mark.parametrize('gamma', (1.1, 1.4, 5/3))
def test_characteristic_and_inverse_are_batched_linear_inverses(gamma):
    dg = candidate.DG2D(4, 7, 3, gamma=gamma)
    avg = physical_states(gamma)
    rng = np.random.default_rng(985)
    delta = rng.normal(0., .7, avg.shape)
    waves = rng.normal(0., .5, avg.shape)
    np.testing.assert_allclose(dg._from_characteristic(dg._to_characteristic(delta, avg), avg),
                               delta, rtol=2e-13, atol=2e-13)
    np.testing.assert_allclose(dg._to_characteristic(dg._from_characteristic(waves, avg), avg),
                               waves, rtol=2e-13, atol=2e-13)
    a, b = .173, -.487
    np.testing.assert_allclose(dg._to_characteristic(a*delta+b*waves, avg),
                               a*dg._to_characteristic(delta, avg)+b*dg._to_characteristic(waves, avg),
                               rtol=2e-13, atol=2e-13)


@pytest.mark.parametrize('gamma', (1.1, 1.4, 5/3))
def test_inverse_columns_are_eigenvectors_of_independent_euler_jacobian(gamma):
    dg = candidate.DG2D(2, 2, 2, gamma=gamma)
    for avg in physical_states(gamma).reshape(-1, 4)[::3]:
        rho, mx, my, energy = avg
        u, v = mx/rho, my/rho
        p = (gamma-1)*(energy-.5*(mx*mx+my*my)/rho)
        sound = np.sqrt(gamma*p/rho)
        enthalpy = (energy+p)/rho
        # Rows are unit-amplitude waves; transpose gives right-eigenvector columns.
        right = dg._from_characteristic(np.eye(4), avg).T
        expected = np.array([[1., 1., 0., 1.],
                             [u-sound, u, 0., u+sound],
                             [v, v, sound, v],
                             [enthalpy-u*sound, .5*(u*u+v*v), v*sound, enthalpy+u*sound]])
        np.testing.assert_allclose(right, expected, rtol=5e-14, atol=5e-14)
        jacobian = np.empty((4, 4))
        for j in range(4):
            perturb = avg.astype(complex)
            perturb[j] += 1e-30j
            jacobian[:, j] = independent_flux(perturb, gamma).imag/1e-30
        speeds = np.array([u-sound, u, u, u+sound])
        np.testing.assert_allclose(jacobian@right, right*speeds,
                                   rtol=2e-13, atol=2e-13)
        # Conversely L R = I: the shear column carries sound-speed normalization.
        np.testing.assert_allclose(dg._to_characteristic(right.T, avg),
                                   np.eye(4), rtol=2e-13, atol=2e-13)


@pytest.mark.parametrize('gamma', (1.1, 1.4, 5/3))
def test_wave_amplitudes_respect_normal_tangential_galilean_boosts(gamma):
    dg = candidate.DG2D(4, 7, 2, gamma=gamma)
    avg = physical_states(gamma)
    delta = np.random.default_rng(312).normal(0., .25, avg.shape)
    before = dg._to_characteristic(delta, avg)
    for boost in ((2.7, -1.3), (0., 2.4), (-1.9, 0.)):
        shifted_avg = galilean_transform(avg, *boost)
        shifted_delta = galilean_transform(delta, *boost)
        shifted = dg._to_characteristic(shifted_delta, shifted_avg)
        np.testing.assert_allclose(shifted, before, rtol=3e-13, atol=3e-13)
        np.testing.assert_allclose(dg._from_characteristic(shifted, shifted_avg),
                                   shifted_delta, rtol=3e-13, atol=3e-13)


@pytest.mark.parametrize('gamma', (1.1, 1.4, 5/3))
def test_all_wave_families_have_density_scaling_units(gamma):
    dg = candidate.DG2D(4, 7, 2, gamma=gamma)
    avg = physical_states(gamma)
    delta = np.random.default_rng(119).normal(0., .1, avg.shape)
    waves = dg._to_characteristic(delta, avg)
    for density_scale in (.007, 83.):
        np.testing.assert_allclose(dg._to_characteristic(density_scale*delta, density_scale*avg),
                                   density_scale*waves, rtol=2e-13, atol=2e-13)


def modal_field(p, gamma=1.4):
    rng = np.random.default_rng(453+p)
    coeff = rng.normal(0., .42, (7, 5, p+1, p+1, 4))
    x, y = np.meshgrid(np.linspace(0., 1., 7), np.linspace(0., 1., 5), indexing='ij')
    avg = independent_conserved(1.3+.16*x, .43+.21*y, -.63+.17*x,
                                .91+.11*np.cos(2*np.pi*x)*np.cos(2*np.pi*y), gamma)
    coeff[:, :, 0, 0] = avg
    return coeff


@pytest.mark.parametrize('p', (1, 2, 3))
@pytest.mark.parametrize('boundary', ('periodic', 'outflow'))
def test_active_characteristic_tvb_preserves_means_and_rotates(p, boundary):
    dg = candidate.DG2D(7, 5, p, bounds=(-.2, .8, -.5, .7),
                         boundary=boundary, limiter='tvb', tvb=0.)
    rotated = candidate.DG2D(5, 7, p, bounds=(-.5, .7, -.2, .8),
                              boundary=boundary, limiter='tvb', tvb=0.)
    coeff = modal_field(p)
    original_means = coeff[:, :, 0, 0].copy()
    ycoeff = coeff.transpose(1, 0, 3, 2, 4)[..., [0, 2, 1, 3]].copy()
    count = dg._tvb_limit(coeff, .037)
    ycount = rotated._tvb_limit(ycoeff, .037)
    assert count == ycount and count > 0
    np.testing.assert_array_equal(coeff[:, :, 0, 0], original_means)
    np.testing.assert_allclose(ycoeff, coeff.transpose(1, 0, 3, 2, 4)[..., [0, 2, 1, 3]],
                               rtol=2e-13, atol=2e-13)
    # The additional physical-state limiter remains conservative and physical.
    fixed = dg.stabilize(coeff, .037)
    np.testing.assert_array_equal(fixed[:, :, 0, 0], original_means)
    q = dg._checkpoints(fixed)
    assert q[..., 0].min() > 0
    assert candidate.pressure(q).min() > 0


@pytest.mark.parametrize('p', (1, 2, 3))
@pytest.mark.parametrize('gamma', (1.1, 1.4, 5/3))
def test_active_1d_and_full_2d_characteristic_limiting_agree(p, gamma):
    dg = candidate.DG2D(13, 3, p, limiter='tvb', tvb=0., gamma=gamma)
    rho = 1.5+.12*np.cos(2*np.pi*dg.x)
    avg = independent_conserved(rho, .51+.16*np.sin(2*np.pi*dg.x),
                                -.72+.18*np.cos(4*np.pi*dg.x), .9+.1*rho, gamma)
    line = np.random.default_rng(197+p).normal(0., .31, (13, p+1, 4))
    line[:, 0] = avg
    coeff = dg._embed_1d(line, 0)
    limited_1d = dg.stabilize(coeff)
    # Force the existing 2D branch on exactly the same modal polynomial.
    dg._embedded_1d = lambda value: None
    limited_2d = dg.stabilize(coeff)
    np.testing.assert_allclose(limited_1d, limited_2d, rtol=3e-13, atol=3e-13)
    np.testing.assert_array_equal(limited_1d[:, :, 0, 0], coeff[:, :, 0, 0])


def test_default_tvb_parameter_is_reported_and_not_case_selected():
    dg = candidate.DG2D(2, 2, 1, limiter='tvb')
    assert dg.tvb == 100.
    coeff = dg.project(lambda x, y: candidate.conserved(np.ones_like(x), .43, -.21, .87))
    result = dg.evolve(coeff, 0.)
    assert result.diagnostics['tvb_parameter'] == 100.
    assert result.diagnostics['limiter_variables'] == 'density-normalized Euler characteristic'


@pytest.mark.parametrize('p', (1, 2, 3))
def test_active_multidimensional_limiter_commutes_with_galilean_state_map(p):
    dg = candidate.DG2D(7, 5, p, limiter='tvb', tvb=0.)
    coeff = modal_field(p)
    boost = (1.7, -2.3)
    boosted = galilean_transform(coeff, *boost)
    count = dg._tvb_limit(coeff, .031)
    shifted_count = dg._tvb_limit(boosted, .031)
    assert count == shifted_count and count > 0
    np.testing.assert_allclose(boosted, galilean_transform(coeff, *boost),
                               rtol=4e-13, atol=4e-13)
