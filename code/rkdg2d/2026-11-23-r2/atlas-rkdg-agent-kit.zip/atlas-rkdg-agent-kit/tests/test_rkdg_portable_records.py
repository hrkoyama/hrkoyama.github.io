"""Reject damaged evidence while admitting one-ulp displayed diagnostic drift."""
import copy
import math
import pytest
from validation.rkdg.portable_records import compare_waveform_records


def record():
    return {'passed': True, 'failures': [], 'source_bindings': {'sha256': 'abc'},
            'cases': [{'p': 2, 'n': 256, 'time': 1.8, 'region': [1.2, 2.2],
                       'raw_array_sha256': 'def', 'passed': True, 'failures': [],
                       'global_relative_l1_density': .006,
                       'metrics': {'roi_cell_count': 25, 'selected_center_range': [1.23, 2.17],
                                   'relative_l1_density': .024,
                                   'pearson_correlation': .993}}]}


def test_one_ulp_output_drift_is_reported_and_inputs_stay_exact():
    saved = record(); computed = copy.deepcopy(saved)
    computed['cases'][0]['metrics']['pearson_correlation'] = math.nextafter(.993, math.inf)
    result = compare_waveform_records(saved, computed)
    assert result['passed'] and result['changed_scalar_count'] == 1
    assert result['maximum_absolute_difference'] > 0
    assert result['changed_fields'][0]['path'] == ['cases', 0, 'metrics', 'pearson_correlation']
    assert not result['scientific_thresholds_modified']


@pytest.mark.parametrize('field', ['passed', 'source', 'raw_sha', 'input_time',
                                 'input_region', 'selected_center', 'case_id', 'count',
                                 'large_output', 'nonfinite', 'extra_field', 'type'])
def test_non_roundoff_and_exact_contract_changes_are_rejected(field):
    saved = record(); changed = copy.deepcopy(saved); case = changed['cases'][0]
    if field == 'passed': case['passed'] = False
    elif field == 'source': changed['source_bindings']['sha256'] = 'other'
    elif field == 'raw_sha': case['raw_array_sha256'] = 'other'
    elif field == 'input_time': case['time'] = math.nextafter(case['time'], math.inf)
    elif field == 'input_region': case['region'][0] = math.nextafter(case['region'][0], math.inf)
    elif field == 'selected_center': case['metrics']['selected_center_range'][0] += 1e-15
    elif field == 'case_id': case['p'] = 3
    elif field == 'count': case['metrics']['roi_cell_count'] = 26
    elif field == 'large_output': case['metrics']['pearson_correlation'] += 1e-10
    elif field == 'nonfinite': case['metrics']['pearson_correlation'] = float('nan')
    elif field == 'extra_field': case['new'] = 1
    elif field == 'type': case['p'] = 2.
    with pytest.raises(ValueError, match='record mismatch'):
        compare_waveform_records(saved, changed)
