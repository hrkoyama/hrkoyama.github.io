"""Independent checks of the assembled candidate's exact 1D invariant path.

These tests use arbitrary Euler states, including transverse momentum. They do
not change the campaign evaluator or its acceptance limits. The candidate is
loaded from its frozen assembly output; equality to the canonical copy and a
before/after digest guard ensure these checks do not silently test another file.
"""
import hashlib
import importlib.util
from pathlib import Path
import sys

import numpy as np
import pytest


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT/'agent-kits/rkdg2d/generated/rkdg2d.py'
SOURCE_BEFORE = CANDIDATE.read_bytes()
SOURCE_SHA256 = hashlib.sha256(SOURCE_BEFORE).hexdigest()
spec = importlib.util.spec_from_file_location('_independent_rkdg_invariance_candidate', CANDIDATE)
candidate = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = candidate
spec.loader.exec_module(candidate)


class ForcedFull2D(candidate.DG2D):
    """Disable only dimensional reduction, preserving the same 2D equations."""
    def _embedded_1d(self, coeff):
        return None


def arbitrary_line_state(s):
    """Vary every primitive component, unrelated to Sod or Shu--Osher."""
    a = 2*np.pi*(s+.37)/2
    rho = 1.4+.13*np.cos(a)+.02*np.sin(2*a)
    normal = .43+.12*np.sin(a)
    tangent = -.71+.17*np.cos(2*a)
    pressure = .91+.08*np.cos(a-.2)
    return candidate.conserved(rho, normal, tangent, pressure)


def make_pair(p, boundary='periodic', limiter='none'):
    args = dict(nx=11, ny=3, degree=p, bounds=(-.37, 1.63, -.2, .55),
                boundary=boundary, limiter=limiter)
    return candidate.DG2D(**args), ForcedFull2D(**args)


def test_review_source_is_frozen_and_canonical_copy_matches():
    assert CANDIDATE.read_bytes() == SOURCE_BEFORE
    assert (ROOT/'numart/rkdg2d.py').read_bytes() == SOURCE_BEFORE


@pytest.mark.parametrize('p', (1, 2, 3))
@pytest.mark.parametrize('boundary', ('periodic', 'outflow'))
@pytest.mark.parametrize('limiter', ('none', 'tvb'))
def test_arbitrary_1d_restriction_agrees_with_full_2d(p, boundary, limiter):
    reduced, full = make_pair(p, boundary, limiter)
    coeff = reduced.project(lambda x, y: arbitrary_line_state(x))
    assert reduced._embedded_1d(coeff)[0] == 0
    # Full code has the same polynomial, including nonzero variable tangential
    # velocity. Quadrature cancellation may leave O(roundoff) transverse modes.
    rrate, rout = reduced._operator(coeff, .073)
    frate, fout = full._operator(coeff, .073)
    np.testing.assert_allclose(rrate, frate, atol=2e-11, rtol=2e-11)
    np.testing.assert_allclose(rout, fout, atol=2e-13, rtol=2e-12)
    np.testing.assert_allclose(reduced.integral(rrate)+rout, 0., atol=2e-13)
    np.testing.assert_allclose(reduced._stable_dt(coeff, .19),
                               full._stable_dt(coeff, .19), atol=2e-17, rtol=2e-14)
    np.testing.assert_allclose(reduced.stabilize(coeff), full.stabilize(coeff),
                               atol=2e-13, rtol=2e-13)
    # Compare actual coupled RK stage evolution as well as a single derivative.
    short_reduced = reduced.evolve(coeff, .002)
    short_full = full.evolve(coeff, .002)
    np.testing.assert_allclose(short_reduced.coeff, short_full.coeff,
                               atol=3e-12, rtol=3e-12)
    np.testing.assert_allclose(short_full.diagnostics['conservation_defect'],
                               0., atol=3e-13)


@pytest.mark.parametrize('p', (1, 2, 3))
@pytest.mark.parametrize('boundary', ('periodic', 'outflow'))
def test_rotated_arbitrary_flow_and_tangential_momentum_balance(p, boundary):
    xdg, _ = make_pair(p, boundary)
    ydg = candidate.DG2D(3, 11, p, bounds=(-.2, .55, -.37, 1.63),
                         boundary=boundary)
    xcoeff = xdg.project(lambda x, y: arbitrary_line_state(x))
    ycoeff = ydg.project(lambda x, y: arbitrary_line_state(y)[..., [0, 2, 1, 3]])
    assert ydg._embedded_1d(ycoeff)[0] == 1
    xresult = xdg.evolve(xcoeff, .007)
    yresult = ydg.evolve(ycoeff, .007)
    # Identical normal/tangential problem after rotating geometry and momenta.
    expected = xresult.coeff.transpose(1, 0, 3, 2, 4)[..., [0, 2, 1, 3]]
    np.testing.assert_array_equal(yresult.coeff, expected)
    np.testing.assert_allclose(xresult.diagnostics['conservation_defect'], 0., atol=3e-13)
    np.testing.assert_allclose(yresult.diagnostics['conservation_defect'], 0., atol=3e-13)
    np.testing.assert_allclose(yresult.diagnostics['integrated_boundary_outflow'],
                               np.asarray(xresult.diagnostics['integrated_boundary_outflow'])[[0, 2, 1, 3]],
                               atol=2e-14, rtol=2e-14)


@pytest.mark.parametrize('p', (1, 2, 3))
@pytest.mark.parametrize('boundary', ('periodic', 'outflow'))
def test_nonzero_tangential_uniform_flow_cancels_exactly(p, boundary):
    dg, _ = make_pair(p, boundary, 'tvb')
    state = candidate.conserved(1.234, -.827, .493, .765)
    coeff = dg.project(lambda x, y: np.broadcast_to(state, x.shape+(4,)))
    # Exact floating-point uniform input has no artificial modal perturbation.
    assert np.count_nonzero(coeff[:, :, 1:, :, :]) == 0
    assert np.count_nonzero(coeff[:, :, :, 1:, :]) == 0
    np.testing.assert_array_equal(dg.rhs(coeff), np.zeros_like(coeff))
    result = dg.evolve(coeff, .009)
    np.testing.assert_array_equal(result.coeff, coeff)


@pytest.mark.parametrize('p', (1, 2, 3))
def test_finite_transverse_perturbation_is_not_projected_away(p):
    dg, _ = make_pair(p)
    coeff = dg.project(lambda x, y: arbitrary_line_state(x))
    coeff[0, 1, 0, 1, 2] = 1e-30
    assert dg._embedded_1d(coeff) is None
    fixed = dg.stabilize(coeff)
    assert fixed[0, 1, 0, 1, 2] == 1e-30
    # Ensure the fallback is actually selected, not merely claimed by detector.
    def forbidden_reduced_operator(*args):
        raise AssertionError('A finite transverse perturbation used the 1D path')
    dg._operator_1d = forbidden_reduced_operator
    assert np.all(np.isfinite(dg.rhs(fixed)))


def test_genuinely_2d_entropy_and_double_mach_keep_full_2d_operator():
    dg = candidate.DG2D(7, 5, 3)
    coeff = dg.project(candidate.entropy_wave)
    assert dg._embedded_1d(coeff) is None
    dm = candidate.DG2D(16, 4, 2, bounds=(0, 4, 0, 1), boundary='double-mach', limiter='tvb')
    coeff = dm.project(candidate.double_mach)
    assert dm._embedded_1d(coeff) is None
    # Even uniform data do not override the multidimensional moving boundaries.
    uniform = np.zeros_like(coeff)
    uniform[:, :, 0, 0] = candidate.conserved(1.4, 0., 0., 1.)
    assert dm._embedded_1d(uniform) is None
