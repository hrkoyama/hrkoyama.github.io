"""Independent parity/point-value checks for the additional reflection map."""
import numpy as np
from numpy.polynomial.legendre import legval2d
from scripts.run_rkdg_reflection import reflect_coefficients


def test_reflection_is_involution_and_changes_only_normal_momentum_means():
    a=np.arange(5*2*4*4*4,dtype=float).reshape(5,2,4,4,4)/100
    b=reflect_coefficients(a)
    np.testing.assert_array_equal(reflect_coefficients(b),a)
    np.testing.assert_array_equal(b[:,:,0,0,:],a[::-1,:,0,0,:]*[1,-1,1,1])
    np.testing.assert_array_equal(a,np.arange(a.size).reshape(a.shape)/100)


def test_reflection_matches_independent_polynomial_point_evaluation():
    rng=np.random.default_rng(103);a=rng.normal(size=(5,2,4,4,4));b=reflect_coefficients(a)
    xi,eta=.371,-.219
    for i in range(5):
        for j in range(2):
            actual=np.array([legval2d(xi,eta,b[i,j,:,:,k]) for k in range(4)])
            expected=np.array([legval2d(-xi,eta,a[4-i,j,:,:,k]) for k in range(4)])*[1,-1,1,1]
            np.testing.assert_allclose(actual,expected,rtol=1e-14,atol=1e-14)
