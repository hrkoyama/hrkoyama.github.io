"""Language-neutral, owned-cell output regression checks for RKDG ports.

CSV/JSON are the interchange boundary. This module imports no candidate solver,
launches no MPI process, and does not infer that fixture partitions ran under MPI.
The coefficient comparison is additional to the frozen physical acceptance rules.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import re
import sys

import numpy as np
from numpy.polynomial.legendre import leggauss, legvander

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from validation.rkdg.evaluate import (PINNED_CRITERIA_SHA256, conservation_defect,
                                      modal_density_errors)

SCHEMA = 'atlas-rkdg-modal-csv-v1'
VARIABLES = ['rho', 'rho_u', 'rho_v', 'energy']
COLUMNS = ['global_i', 'global_j', 'mode_i', 'mode_j'] + VARIABLES
BASIS = {'family': 'Legendre', 'interval': [-1, 1], 'normalization': 'P_m(1)=1',
         'cell_average_mode': [0, 0], 'tensor_space': 'Qp'}
CASES = {'diagonal-entropy-wave', 'temporal-entropy-wave', 'sod', 'shu-osher', 'double-mach',
         'polynomial-io-fixture'}
DEFAULT_ATOL = 1e-11
DEFAULT_RTOL = 1e-9
_REQUIRED = {'schema', 'representation', 'basis', 'variables', 'dtype', 'case',
             'time', 'gamma', 'degree', 'global_shape', 'bounds', 'boundary',
             'axis', 'rank_count', 'partitions', 'execution_kind', 'criteria_sha256'}
_OPTIONAL = {'producer', 'language', 'source_sha256', 'reference_npz_sha256',
             'notes', 'diagnostics'}
_SHA = re.compile(r'^[0-9a-f]{64}$')
_INT = re.compile(r'^-?[0-9]+$')
_METADATA = ('representation', 'basis', 'variables', 'dtype', 'case', 'time', 'gamma',
             'degree', 'global_shape', 'bounds', 'boundary', 'axis', 'criteria_sha256')


class InterchangeError(ValueError):
    """Malformed or scientifically incompatible interchange evidence."""


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _require(condition, message):
    if not condition:
        raise InterchangeError(message)


def _integer(value, low=0):
    return isinstance(value, int) and not isinstance(value, bool) and value >= low


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _vector(value, size):
    return isinstance(value, list) and len(value) == size and all(_finite(x) for x in value)


def _validate_manifest(meta):
    _require(isinstance(meta, dict), 'Manifest must be a JSON object')
    _require(not (_REQUIRED-set(meta)), 'Missing manifest fields: '+str(sorted(_REQUIRED-set(meta))))
    _require(not (set(meta)-_REQUIRED-_OPTIONAL), 'Unknown manifest fields: '+str(sorted(set(meta)-_REQUIRED-_OPTIONAL)))
    _require(meta['schema'] == SCHEMA, 'Unsupported interchange schema')
    _require(meta['representation'] == 'modal-legendre-Qp' and meta['basis'] == BASIS,
             'Expected standard tensor Legendre Qp coefficients with mode00 cell averages')
    _require(meta['variables'] == VARIABLES, 'Conserved variable order must be '+str(VARIABLES))
    _require(meta['dtype'] == 'float64', 'This version accepts float64 outputs only')
    _require(isinstance(meta['case'], str) and meta['case'] in CASES, 'Unknown fixed-suite case')
    _require(_finite(meta['time']) and meta['time'] >= 0, 'Time must be finite and nonnegative')
    _require(_finite(meta['gamma']) and meta['gamma'] == 1.4, 'Fixed Euler suite requires gamma=1.4')
    _require(_integer(meta['degree'], 1) and meta['degree'] in (1, 2, 3), 'Require degree=1,2,3')
    shape = meta['global_shape']
    _require(isinstance(shape, list) and len(shape) == 2 and all(_integer(n, 1) for n in shape), 'Require two positive integer global mesh sizes')
    bounds = meta['bounds']
    _require(_vector(bounds, 4) and bounds[1] > bounds[0] and bounds[3] > bounds[2], 'Invalid rectangular bounds')
    _require(meta['boundary'] in ('periodic', 'outflow', 'double-mach'), 'Unknown boundary type')
    axis = meta['axis']
    _require(axis is None or (_integer(axis) and axis in (0, 1)), 'Axis must be null,0,1')
    _require((axis in (0, 1)) == (meta['case'] in ('sod', 'shu-osher')), 'Case orientation is inconsistent')
    _require(meta['criteria_sha256'] == PINNED_CRITERIA_SHA256, 'Physical acceptance version changed')
    _require(meta['execution_kind'] in ('fixture-export', 'solver-output', 'foreign-language-io-fixture'),
             'Declare fixture-export, solver-output or foreign-language-io-fixture')
    if meta['case'] == 'polynomial-io-fixture':
        _require(meta['execution_kind'] != 'solver-output', 'Polynomial I/O fixture is not a PDE solver execution')
    _require(_integer(meta['rank_count'], 1), 'rank_count must be a positive integer')
    parts = meta['partitions']
    _require(isinstance(parts, list) and len(parts) == meta['rank_count'], 'Every declared rank needs one CSV partition')
    ranks, filenames = set(), set()
    for part in parts:
        _require(isinstance(part, dict) and {'rank', 'file'} <= set(part) <= {'rank', 'file', 'sha256'}, 'Partition fields must be rank,file[,sha256]')
        rank, name = part['rank'], part['file']
        _require(_integer(rank) and rank < meta['rank_count'] and rank not in ranks, 'Duplicate or invalid rank')
        _require(isinstance(name, str) and name and not Path(name).is_absolute() and '..' not in Path(name).parts,
                 'Partition files must be relative descendants of the manifest directory')
        _require(name not in filenames, 'CSV partition path is repeated')
        if 'sha256' in part:
            _require(isinstance(part['sha256'], str) and bool(_SHA.fullmatch(part['sha256'])), 'Invalid CSV SHA256')
        ranks.add(rank); filenames.add(name)
    for key in ('source_sha256', 'reference_npz_sha256'):
        if key in meta:
            _require(isinstance(meta[key], str) and bool(_SHA.fullmatch(meta[key])), 'Invalid '+key)
    if 'diagnostics' in meta:
        d = meta['diagnostics']
        keys = {'initial_integral', 'final_integral', 'integrated_boundary_outflow'}
        _require(isinstance(d, dict) and set(d) == keys and all(_vector(d[k], 4) for k in keys), 'Invalid four-component conservation diagnostics')
    return meta


@dataclass
class ModalRun:
    coefficients: np.ndarray
    metadata: dict
    provenance: dict

    @property
    def cell_averages(self):
        return self.coefficients[:, :, 0, 0, :]


def load_run(manifest_path):
    """Reconstruct the global coefficient field, rejecting holes and halo copies."""
    path = Path(manifest_path).resolve()
    meta = _validate_manifest(json.loads(path.read_text()))
    nx, ny = meta['global_shape']; modes = meta['degree']+1
    values = np.empty((nx, ny, modes, modes, 4), dtype=float)
    seen = np.zeros((nx, ny, modes, modes), dtype=bool)
    owner = np.full((nx, ny), -1, dtype=int)
    files = []
    for part in meta['partitions']:
        csvpath = (path.parent/part['file']).resolve()
        _require(csvpath.is_relative_to(path.parent), 'CSV path escapes the manifest directory')
        _require(csvpath.is_file(), 'Missing partition file '+str(csvpath))
        digest = sha256(csvpath)
        _require(part.get('sha256', digest) == digest, 'CSV digest mismatch: '+part['file'])
        count = 0
        with csvpath.open(newline='') as stream:
            reader = csv.reader(stream)
            _require(next(reader, None) == COLUMNS, 'CSV header/order must exactly match '+','.join(COLUMNS))
            for number, row in enumerate(reader, start=2):
                _require(len(row) == len(COLUMNS), f'Wrong CSV column count at {part["file"]}:{number}')
                rawindex = [x.strip() for x in row[:4]]
                _require(all(_INT.fullmatch(x) for x in rawindex), 'Global and mode indices must be integers')
                i, j, m, n = (int(x) for x in rawindex)
                _require(0 <= i < nx and 0 <= j < ny and 0 <= m < modes and 0 <= n < modes,
                         'Out-of-range global/mode index (ghost rows must not be exported)')
                _require(not seen[i, j, m, n], 'Duplicate owned global/mode row; possible overlapping partition or halo')
                _require(owner[i, j] in (-1, part['rank']), 'One owned cell is split across rank files')
                owner[i, j] = part['rank']
                try:
                    fields = np.array([float(x) for x in row[4:]], dtype=float)
                except ValueError as exc:
                    raise InterchangeError('Non-numeric conserved field') from exc
                _require(np.all(np.isfinite(fields)), 'Nonfinite conserved coefficient')
                values[i, j, m, n] = fields; seen[i, j, m, n] = True; count += 1
        files.append({'rank': part['rank'], 'file': part['file'], 'rows': count, 'sha256': digest})
    _require(np.all(seen), f'Missing owned global/mode rows: {int(seen.size-seen.sum())}')
    return ModalRun(values, meta, {'manifest_sha256': sha256(path), 'partitions': files,
                                  'mpi_execution_verified': False,
                                  'scope': 'Output reconstruction and comparison, not an MPI runtime audit'})


def _infer_case(path, config):
    name = Path(path).name
    if name.startswith('smooth'): return 'diagonal-entropy-wave'
    if name.startswith('temporal'): return 'temporal-entropy-wave'
    if name.startswith('sod'): return 'sod'
    if name.startswith('shu-osher'): return 'shu-osher'
    if name.startswith('double-mach'): return 'double-mach'
    if name.startswith('polynomial-io-fixture'): return 'polynomial-io-fixture'
    raise InterchangeError('Unknown NPZ case; pass case explicitly')


def _baseline_npz(path, case=None, axis=None):
    with np.load(path, allow_pickle=False) as data:
        _require('coeff' in data and 'config' in data and 'diagnostics' in data, 'NPZ must be a recorded RKDG coefficient output')
        coeff = np.array(data['coeff'], copy=True)
        config = json.loads(str(data['config'])); diagnostics = json.loads(str(data['diagnostics']))
    case = case or _infer_case(path, config)
    if case in ('sod', 'shu-osher') and axis is None:
        axis = 0 if config['nx'] > config['ny'] else 1
    bounds = list(config.get('bounds', [0., 1., 0., 1.]))
    meta = {'schema': SCHEMA, 'representation': 'modal-legendre-Qp', 'basis': BASIS,
            'variables': VARIABLES, 'dtype': 'float64', 'case': case,
            'time': float(config['time']), 'gamma': 1.4, 'degree': config['degree'],
            'global_shape': [config['nx'], config['ny']], 'bounds': bounds,
            'boundary': config['boundary'], 'axis': axis, 'rank_count': 1,
            'partitions': [{'rank': 0, 'file': 'unused-baseline.csv'}],
            'execution_kind': 'fixture-export', 'criteria_sha256': PINNED_CRITERIA_SHA256,
            'reference_npz_sha256': sha256(path), 'producer': 'Atlas saved-array fixture exporter',
            'language': 'Python', 'diagnostics': {k: list(diagnostics[k]) for k in
                ('initial_integral', 'final_integral', 'integrated_boundary_outflow')}}
    _validate_manifest(meta)
    expected = tuple(meta['global_shape'])+(meta['degree']+1, meta['degree']+1, 4)
    _require(coeff.shape == expected and np.all(np.isfinite(coeff)), 'Baseline coefficient shape/values invalid')
    return ModalRun(coeff, meta, {'npz_sha256': sha256(path)})


def export_reference_npz(npz_path, output_directory, ranks=1, shuffle=False, case=None, axis=None):
    """Export 1/2/4/... fixture partitions. This does not execute MPI or a port."""
    _require(_integer(ranks, 1), 'ranks must be a positive integer')
    run = _baseline_npz(npz_path, case=case, axis=axis)
    out = Path(output_directory); out.mkdir(parents=True, exist_ok=True)
    manifest = out/'manifest.json'
    _require(not manifest.exists(), 'Refusing to overwrite an existing interchange run')
    coeff = run.coefficients
    cells = np.arange(coeff.shape[0]*coeff.shape[1])
    rng = np.random.default_rng(317)
    partitions = []
    for rank in range(ranks):
        owned = cells[cells % ranks == rank].copy()
        if shuffle: rng.shuffle(owned)
        name = f'rank-{rank:04d}.csv'; path = out/name
        with path.open('x', newline='') as stream:
            writer = csv.writer(stream); writer.writerow(COLUMNS)
            for global_cell in owned:
                i, j = divmod(int(global_cell), coeff.shape[1])
                indices = [(m, n) for m in range(coeff.shape[2]) for n in range(coeff.shape[3])]
                if shuffle: rng.shuffle(indices)
                for m, n in indices:
                    writer.writerow([i, j, m, n]+[format(float(x), '.17g') for x in coeff[i, j, m, n]])
        partitions.append({'rank': rank, 'file': name, 'sha256': sha256(path)})
    meta = dict(run.metadata, rank_count=ranks, partitions=partitions,
                notes='Partitioned saved-array fixture; no foreign-language solver or MPI runtime was executed.')
    manifest.write_text(json.dumps(meta, indent=2, allow_nan=False)+'\n')
    return manifest


def physical_diagnostics(run):
    """Independent checks at p+2 Gauss points, faces and corners; not all points."""
    c = run.coefficients; degree = run.metadata['degree']
    z = np.r_[-1., leggauss(degree+2)[0], 1.]
    b = legvander(z, degree)
    q = np.einsum('am,bn,ijmnk->ijabk', b, b, c, optimize=True)
    rho = q[..., 0]
    with np.errstate(divide='ignore', invalid='ignore'):
        pressure = .4*(q[..., 3]-.5*np.sum(q[..., 1:3]**2, axis=-1)/rho)
    return {'minimum_density': float(rho.min()) if np.all(np.isfinite(rho)) else None,
            'minimum_pressure': float(pressure.min()) if np.all(np.isfinite(pressure)) else None,
            'positive_at_declared_points': bool(np.all(rho > 0) and np.all(pressure > 0)
                                                and np.all(np.isfinite(q)) and np.all(np.isfinite(pressure)))}


def entropy_metrics(run):
    """Feed the same independently reconstructed density norms after a port."""
    _require(run.metadata['case'] in ('diagonal-entropy-wave', 'temporal-entropy-wave'), 'Entropy metrics require an entropy-wave case')
    _require(run.metadata['bounds'] == [0., 1., 0., 1.], 'Fixed entropy case requires the unit square')
    exact = lambda x, y, t: 1+.2*np.sin(2*np.pi*(x+y-1.5*t))
    return modal_density_errors(run.coefficients, exact, bounds=run.metadata['bounds'], time=run.metadata['time'])


def _compatible(a, b):
    for key in _METADATA:
        va, vb = a.metadata[key], b.metadata[key]
        if key in ('time', 'bounds'):
            same = np.allclose(va, vb, rtol=0., atol=1e-14)
        else: same = va == vb
        _require(same, 'Incompatible physical metadata: '+key)


def _compare(reference, candidate, atol=DEFAULT_ATOL, rtol=DEFAULT_RTOL):
    _require(_finite(atol) and _finite(rtol) and atol >= 0 and rtol >= 0, 'Finite nonnegative tolerances required')
    _compatible(reference, candidate)
    expected, actual = reference.coefficients, candidate.coefficients
    delta = np.abs(actual-expected); bound = atol+rtol*np.abs(expected)
    bad = delta > bound
    info = physical_diagnostics(candidate)
    bounds = candidate.metadata['bounds']; nx, ny = candidate.metadata['global_shape']
    area = (bounds[1]-bounds[0])*(bounds[3]-bounds[2])/(nx*ny)
    initial_integral = area*reference.cell_averages.sum(axis=(0, 1))
    actual_integral = area*candidate.cell_averages.sum(axis=(0, 1))
    report = {'passed': bool(not np.any(bad) and info['positive_at_declared_points']),
              'comparison': 'Full four-variable modal-output equivalence; not a new PDE acceptance verdict',
              'atol': atol, 'rtol': rtol, 'mismatched_coefficients': int(bad.sum()),
              'maximum_absolute_difference': float(delta.max()),
              'maximum_difference_by_variable': delta.max(axis=(0, 1, 2, 3)).tolist(),
              'reference_rank_count': reference.metadata['rank_count'],
              'candidate_rank_count': candidate.metadata['rank_count'],
              'integral_difference': (actual_integral-initial_integral).tolist(),
              'reference_provenance': reference.provenance, 'candidate_provenance': candidate.provenance,
              'mpi_execution_verified': False, 'conservation_checked': False, **info}
    if 'diagnostics' in candidate.metadata:
        d = candidate.metadata['diagnostics']
        criteria_path = Path(__file__).with_name('acceptance.json')
        _require(sha256(criteria_path) == PINNED_CRITERIA_SHA256, 'Frozen physical criteria changed')
        criteria = json.loads(criteria_path.read_text())
        limits = {criteria[section]['max_normalized_conservation_defect']
                  for section in ('smooth', 'directional', 'double_mach')}
        _require(len(limits) == 1, 'A case-specific physical conservation limit is required')
        limit = limits.pop()
        defect = conservation_defect(
            d['initial_integral'], d['final_integral'], d['integrated_boundary_outflow'])
        report.update(conservation_checked=True,
                      boundary_flux_corrected_conservation_defect=defect,
                      max_normalized_conservation_defect=limit,
                      conservation_passed=bool(defect <= limit))
        consistent = bool(np.allclose(actual_integral, d['final_integral'], atol=atol, rtol=rtol))
        report['declared_final_integral_matches_coefficients'] = consistent
        report['passed'] = report['passed'] and consistent and report['conservation_passed']
    if candidate.metadata['case'] in ('diagonal-entropy-wave', 'temporal-entropy-wave'):
        report['density_errors'] = entropy_metrics(candidate)
    return report


def compare_runs(serial_manifest, parallel_manifest, atol=DEFAULT_ATOL, rtol=DEFAULT_RTOL):
    return _compare(load_run(serial_manifest), load_run(parallel_manifest), atol=atol, rtol=rtol)


def compare_reference_manifest(manifest_path, baseline_npz, atol=DEFAULT_ATOL, rtol=DEFAULT_RTOL):
    candidate = load_run(manifest_path)
    # The expected case/orientation comes from the trusted baseline, never
    # from the candidate's potentially wrong declaration.
    reference = _baseline_npz(baseline_npz)
    declared = candidate.metadata.get('reference_npz_sha256')
    _require(declared is None or declared == sha256(baseline_npz), 'Manifest identifies a different reference NPZ')
    return _compare(reference, candidate, atol=atol, rtol=rtol)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    export = sub.add_parser('export-fixture')
    export.add_argument('npz', type=Path); export.add_argument('output', type=Path)
    export.add_argument('--ranks', type=int, default=1); export.add_argument('--shuffle', action='store_true')
    for command in ('compare', 'check-reference'):
        check = sub.add_parser(command)
        check.add_argument('reference', type=Path); check.add_argument('candidate', type=Path)
        check.add_argument('--atol', type=float, default=DEFAULT_ATOL)
        check.add_argument('--rtol', type=float, default=DEFAULT_RTOL)
        check.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'export-fixture':
            print(export_reference_npz(args.npz, args.output, ranks=args.ranks, shuffle=args.shuffle)); return
        result = (compare_runs(args.reference, args.candidate, args.atol, args.rtol)
                  if args.command == 'compare' else
                  compare_reference_manifest(args.candidate, args.reference, args.atol, args.rtol))
    except (ValueError, OSError) as exc:
        result = {'passed': False, 'error': str(exc), 'mpi_execution_verified': False}
        if args.command == 'export-fixture':
            print(json.dumps(result, indent=2)); raise SystemExit(1)
    text = json.dumps(result, indent=2, allow_nan=False)+'\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(text)
    print(text, end='')
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()
