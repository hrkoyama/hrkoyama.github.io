2D Euler RKDG: independent fixed acceptance suite
================================================

Status
------
This directory defines evaluation rules. It is not evidence that a solver passed.
Actual campaign arrays, commands, source hashes, environment, execution logs and
verdicts belong in a dated output directory. The synthetic fixture in
 tests/test_rkdg_evaluator.py tests the contract; it is never numerical evidence.

The acceptance.json file was frozen before measurements of the candidate:
SHA256 7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af
The evaluator pins that digest. Editing the criteria, even while updating a
metrics-file digest, produces a failing verdict. Fix the candidate or report the
failure; do not loosen the frozen test.

Independence
------------
evaluate.py does not import numart.rkdg2d or any candidate solver. It reconstructs
Legendre tensor modes and computes quadrature norms independently. It also remaps
reference cell averages by geometric overlap instead of point interpolation.
The reference generator is a separate finite-volume method, and Sod uses its
analytic Riemann solution. Shared floating-point libraries do not make a second
implementation a mathematical proof; report its grid uncertainty separately.

A generated candidate is allowed to change implementation files. The evaluation
rules, metric code and independent references must remain outside that editing
scope. Store hashes before and after an agent run, plus its actual instructions
and change diff. A successful reproduction of an existing module alone is not a
claim that a new solver was autonomously invented.

Scientific scope
----------------
- Cartesian tensor Qp, p=1,2,3, corresponding to 2nd/3rd/4th target spatial order
  on smooth solutions. Total-degree Pp is a different polynomial space.
- Smooth diagonal entropy wave: 8,16,32,64 cells in each direction; t=0.2,
  velocity (1,0.5). Error is in reconstructed density, integrated independently
  with at least 2p+4 Gauss points in each direction. L1 and L2 are normalized by
  domain area; Linf is a sampled maximum and is not a proven exact supremum.
  Every grid refinement must reduce error. The last two observed orders must
  exceed p+1-0.35 (L1/L2) and p+1-0.6 (sampled Linf).
- Sod and Shu-Osher: embedded x/y, same 2D code, 128 and 256 cells along the
  varying direction; transverse width and cell count must be recorded. Times
  are 0.2 and 1.8. Relative density L1 is sum |rho-rho_ref| / sum |rho_ref|,
  comparing cell averages. Finest-grid limits are 0.08 and 0.15. A fine error
  may be at most 1.1 times the coarse error; no high-order rate across shocks
  is asserted. Transverse variation and rotated x/y state difference <=1e-10.
- Double Mach: 4*ny by ny cells, ny=16,24,32; t=0.2. Finest relative density L1
  against an independent FV reference <=0.30. Its fine error may be at most
  1.15 times coarse error. Independent reference grid change <=0.15. This is a
  broad shock-structure check; these meshes do not establish fine vortex
  agreement, DNS quality, or high-order convergence across discontinuities.
- Density and pressure minima must remain strictly positive. No floor or
  clipping may be used to conceal a negative cell average in the report.
- Boundary-adjusted conservation uses I_final-I_initial+integrated_outflow.
  It must be <=1e-9 after componentwise normalization by
  max(1,|I_initial|,|I_final|,|integrated_outflow|). The RK stage quadrature used
  for boundary flux must match the actual time integration.
- Temporal separation: p=3, fixed 16x16 spatial grid and t=0.2; compare dt,
  dt/2,dt/4 to the same-grid dt/8 solution. Successive L2 differences must
  decrease by at least 8. Record actual time-step histories; the nominal cap
  must control the step rather than an unnoticed smaller CFL restriction.
- A deliberately wrong y-flux implementation must fail the same fixed
  evaluation. Preserve its source and actual measured failures. A hard-coded
  rejected=true flag without run evidence does not constitute a demonstration.
  The evaluator recomputes the fixed smooth criteria from those four measured
  faulty-solver rows; missing/malformed evidence cannot count as fault detection.

Metrics schema
--------------
The input is JSON, schema_version=1. Required top-level fields:
  criteria_sha256: the digest pinned above
  solver_sha256: SHA256 of the actual candidate module
  reference_sha256: nonempty object of independent reference file digests
  smooth: 12 rows, each
    {p,n,time,velocity:[1.0,0.5],errors:{l1,l2,linf},conservation_defect}
  directional: 24 rows, each
    {problem:'sod'|'shu-osher',p,axis:0|1,n,time,error_l1,transverse,
     axis_difference,conservation_defect,min_density,min_pressure,
     reference_kind:'exact-riemann'|'independent-fv'}
  double_mach: 9 rows, each
    {p,ny,time,error_l1,reference_grid_change_l1,conservation_defect,
     min_density,min_pressure,reference_kind:'independent-fv'}
  temporal: 3 rows, each
    {p:3,n:16,time:0.2,factor:1|2|4,dt,error_l2,reference_dt}
  negative_controls: a row
    {name:'wrong-y-flux',rejected:true,reasons:[actual nonempty failure messages],
     evidence_sha256:'digest of preserved actual run evidence',
     smooth:[four measured p=1 smooth rows with the schema above]}

Case identifiers must be integers where applicable. Missing, duplicate, unexpected
or incomplete cases, nonfinite numbers, wrong times or velocities, mismatched
hashes, and unverifiable references cause a failing verdict. Extra diagnostic
fields are allowed, and numeric extras must also be finite.

Functions
---------
modal_density_errors(coefficients, exact, bounds, time, nq=None)
  Coefficients axes nx,ny,p+1,p+1,4; exact(x,y,t) returns density or four conserved
  components. This reconstructs the density independently of the solver.
conservative_restrict(reference, target_shape)
  Uniform grids on the same physical domain; supports noninteger ratios and
  trailing field dimensions. It preserves averages by cell-overlap integration.
relative_l1(actual, reference, weights=None)
field_errors(actual, reference, weights=None)
conservation_defect(initial_integral, final_integral, integrated_outflow)
evaluate_smooth_control(rows, degree=1)
  Recomputes unchanged smooth criteria and returns valid_evidence/rejected/reasons.
  Use measured p=1 rows for the required wrong-y-flux negative control.
evaluate_metrics(metrics, expected_solver_sha256=None)

Example validation command from the repository root:
  python validation/rkdg/evaluate.py PATH/metrics.json \
    --solver PATH/candidate.py --output PATH/verdict.json
The command exits 0 only on a complete pass. Without --solver, the evaluator
checks digest syntax and internal binding but cannot verify the actual source
file; final demonstration commands should supply it.

Focused evaluator checks:
  python -m pytest -q tests/test_rkdg_evaluator.py

Primary references
------------------
Cockburn & Shu (1998), The Runge-Kutta Discontinuous Galerkin Method for
Conservation Laws V: Multidimensional Systems. JCP 141,199-224.
https://doi.org/10.1006/jcph.1998.5892

Zhang & Shu (2010), On positivity-preserving high order discontinuous Galerkin
schemes for compressible Euler equations on rectangular meshes. JCP 229,8918-8934.
https://doi.org/10.1016/j.jcp.2010.08.016
Author PDF: https://www.math.purdue.edu/~zhan1966/research/paper/euler.pdf

Sod (1978), A survey of several finite difference methods for systems of
nonlinear hyperbolic conservation laws. JCP 27,1-31.
https://doi.org/10.1016/0021-9991(78)90023-2

Shu & Osher (1989), Efficient implementation of essentially non-oscillatory
shock-capturing schemes II. JCP 83,32-78.
https://doi.org/10.1016/0021-9991(89)90222-2
NASA record: https://ntrs.nasa.gov/citations/19890061070

Woodward & Colella (1984), The Numerical Simulation of Two-Dimensional Fluid
Flow with Strong Shocks. JCP 54,115-173.
https://doi.org/10.1016/0021-9991(84)90142-6
NASA LAVA Double Mach setup:
https://nas.nasa.gov/LAVA/unst_docs/tutorials/double_mach/double_mach/
