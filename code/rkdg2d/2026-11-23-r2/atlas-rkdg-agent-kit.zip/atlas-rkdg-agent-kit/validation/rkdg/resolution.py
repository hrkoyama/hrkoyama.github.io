"""Frozen supplemental Shu--Osher wave-resolution evaluation from saved arrays.

This does not execute a PDE solver and never replaces or rewrites the original
48-case criteria/verdict. Four diagnostic checks reuse existing p2/p3 x/y runs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
CRITERIA_PATH = Path(__file__).with_name('resolution-acceptance.json')
PINNED_RESOLUTION_SHA256 = '275c7ffc386bc4cc791148b498e3872e9a67398f2a175bd3ae9a418559cf63c3'
PINNED_ORIGINAL_SHA256 = '7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af'
PINNED_REFERENCE_SHA256 = 'b6c51a2abed1ae7eb71d4ebcb1dfcdf1348686521f8a2b8d8941ed638413bd46'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def resolution_metrics(actual, reference, centers, region=(1.2,2.2)):
    """Density-cell-average ROI metrics; std uses each profile's own mean.

    Correlation is Pearson correlation over the selected uniform cells. The
    standard-deviation ratio includes local trend and is not a Fourier-mode
    amplitude. Constant profiles have undefined correlation and are rejected.
    """
    actual,reference,centers=[np.asarray(v,float) for v in (actual,reference,centers)]
    require(actual.ndim==reference.ndim==centers.ndim==1 and actual.shape==reference.shape==centers.shape,
            'ROI requires matching one-dimensional density/center arrays')
    require(all(np.all(np.isfinite(v)) for v in (actual,reference,centers)),
            'ROI input contains nonfinite values')
    require(np.all(np.diff(centers)>0),'Cell centers must be strictly increasing')
    mask=(centers>=region[0]) & (centers<=region[1])
    require(int(mask.sum())>=3,'ROI has fewer than three cell centers')
    a,b=actual[mask],reference[mask]
    require(np.all(a>0) and np.all(b>0),'ROI cell-average densities must be positive')
    an,bn=a-a.mean(),b-b.mean()
    denom=float(np.sqrt(np.sum(an*an)*np.sum(bn*bn)))
    require(denom>0 and np.isfinite(denom),'ROI correlation is undefined for a constant profile')
    std_a,std_b=float(np.std(a)),float(np.std(b))
    result={'roi_cell_count':int(mask.sum()),
            'selected_center_range':[float(centers[mask][0]),float(centers[mask][-1])],
            'relative_l1_density':float(np.sum(abs(a-b))/np.sum(abs(b))),
            'max_absolute_density_difference':float(np.max(abs(a-b))),
            'demeaned_standard_deviation_ratio':std_a/std_b,
            'pearson_correlation':float(np.clip(np.sum(an*bn)/denom,-1.,1.)),
            'candidate_mean':float(a.mean()),'reference_mean':float(b.mean()),
            'candidate_standard_deviation':std_a,'reference_standard_deviation':std_b}
    require(all(math.isfinite(v) for v in result.values() if isinstance(v,(int,float))),
            'Nonfinite computed ROI metric')
    return result


def remap_density(reference, source_edges, target_edges):
    """Exact overlap of uniform-cell reference averages, no point interpolation."""
    q,se,te=np.asarray(reference,float),np.asarray(source_edges,float),np.asarray(target_edges,float)
    require(q.ndim==1 and se.shape==(len(q)+1,) and te.ndim==1 and len(te)>1,
            'Reference remapping shape mismatch')
    require(all(np.all(np.isfinite(v)) for v in (q,se,te)) and np.all(np.diff(se)>0) and np.all(np.diff(te)>0),
            'Reference edges/values must be finite and increasing')
    require(np.allclose(se[[0,-1]],te[[0,-1]],atol=1e-13,rtol=0),
            'Reference and target physical domains differ')
    weight=np.maximum(0.,np.minimum(te[1:,None],se[None,1:])-np.maximum(te[:-1,None],se[None,:-1]))/np.diff(te)[:,None]
    require(np.allclose(weight.sum(1),1.,atol=2e-13,rtol=0),'Reference does not cover every target cell')
    return np.einsum('ai,i->a',weight,q,optimize=False)


def _reference(references_dir, rules, campaign_metrics):
    path=Path(references_dir)/rules['reference']
    metadata=read_json(path.with_suffix('.json'))
    quality=read_json(Path(references_dir)/'quality.json')
    ledger={r['file']:r['sha256'] for r in quality['files']}
    sha=digest(path)
    require(sha==PINNED_REFERENCE_SHA256==metadata['npz_sha256']==ledger.get(path.name),
            'Frozen independent reference digest mismatch')
    require(campaign_metrics.get('reference_sha256',{}).get(path.name)==sha,
            'Campaign did not bind the same independent reference')
    require(metadata['gamma']==1.4 and metadata['time']==rules['time'] and metadata['problem']=='shu-osher',
            'Independent reference model/problem/time mismatch')
    require(metadata['source_sha256']==digest(ROOT/'validation/rkdg/reference.py'),
            'Independent reference generator source changed')
    with np.load(path,allow_pickle=False) as data:
        q=np.array(data['q']);edges=np.array(data['x_edges']);time=float(data['time'])
    require(q.shape==(3200,4) and list(q.shape)==metadata['shape'] and time==rules['time'],
            'Independent reference shape/time mismatch')
    require(np.all(np.isfinite(q)) and np.all(q[:,0]>0) and edges.shape==(3201,)
            and np.all(np.diff(edges)>0) and np.allclose(edges[[0,-1]],[-5.,5.],atol=1e-13,rtol=0),
            'Independent reference data/physical edges invalid')
    return q[:,0],edges,sha


def evaluate_resolution(campaign, solver, criteria_path=CRITERIA_PATH, references_dir=None):
    """Return supplemental PASS/FAIL with source- and array-bound recomputation."""
    campaign,solver=Path(campaign),Path(solver)
    report={'passed':False,'supplemental':True,'supplemental_version':'supplemental-shu-resolution-1',
            'resolution_criteria_sha256':digest(criteria_path),'original_acceptance_sha256':PINNED_ORIGINAL_SHA256,
            'failures':[],'cases':[],
            'scope':'Four supplemental wave-resolution diagnostic checks on existing PDE runs; original 48-case acceptance/history is not rewritten.'}
    try:
        require(report['resolution_criteria_sha256']==PINNED_RESOLUTION_SHA256,
                'Frozen supplemental resolution criteria hash changed')
        rules=read_json(criteria_path)
        require(rules['original_acceptance_unchanged']==PINNED_ORIGINAL_SHA256
                and digest(Path(__file__).with_name('acceptance.json'))==PINNED_ORIGINAL_SHA256,
                'Original acceptance criteria changed')
        metrics_path=campaign/'metrics.json';metrics=read_json(metrics_path)
        require(metrics['schema_version']==1 and metrics['criteria_sha256']==PINNED_ORIGINAL_SHA256,
                'Campaign schema/original criteria mismatch')
        solver_sha=digest(solver)
        require(metrics['solver_sha256']==solver_sha,'Campaign belongs to a different candidate source')
        require(metrics['runner_sha256']==digest(ROOT/'scripts/run_rkdg_campaign.py'),
                'Campaign runner source changed')
        support=metrics.get('support_sha256')
        expected={'validation/rkdg/evaluate.py','numart/riemann.py','numart/equations.py'}
        require(isinstance(support,dict) and set(support)==expected,'Campaign support bindings incomplete')
        for name,sha in support.items():require(digest(ROOT/name)==sha,'Campaign evaluation dependency changed: '+name)
        ref,refedges,refsha=_reference(references_dir or Path(__file__).with_name('references'),rules,metrics)
        report['source_bindings']={'solver_sha256':solver_sha,'campaign_metrics_sha256':digest(metrics_path),
            'runner_sha256':metrics['runner_sha256'],'support_sha256':support,'reference_sha256':refsha,
            'resolution_evaluator_sha256':digest(__file__)}
        if (campaign/'verdict.json').exists():
            previous=read_json(campaign/'verdict.json')
            report['original_verdict_record']={'passed':previous.get('passed'),'sha256':digest(campaign/'verdict.json'),
                                               'note':'Read-only historical record; this supplemental result does not alter it.'}
        indexed={};required={(p,axis) for p in rules['degrees'] for axis in rules['axes']}
        directional=metrics.get('directional')
        require(isinstance(directional,list),'Campaign directional rows are missing')
        for row in directional:
            require(isinstance(row,dict),'Invalid directional row')
            if row.get('problem')!=rules['problem'] or row.get('n')!=rules['n']:continue
            key=(row.get('p'),row.get('axis'))
            if key not in required:continue
            require(key not in indexed,'Duplicate supplemental case: '+str(key))
            require(all(isinstance(row[k],int) and not isinstance(row[k],bool) for k in ('p','axis','n')),
                    'Supplemental case identifiers must be integers')
            indexed[key]=row
        for key in sorted(required-indexed.keys()):report['failures'].append('Missing supplemental case p='+str(key[0])+' axis='+str(key[1]))
        for (p,axis),row in sorted(indexed.items()):
            label=f'shu-osher p={p} axis={axis} n={rules["n"]}'
            try:
                require(row['time']==rules['time'] and row['reference_kind']=='independent-fv',label+' wrong time/reference kind')
                for name in ('error_l1','conservation_defect','min_density','min_pressure','transverse','axis_difference'):
                    require(isinstance(row.get(name),(int,float)) and not isinstance(row.get(name),bool)
                            and math.isfinite(row[name]),label+' nonfinite/missing '+name)
                path=campaign/'arrays'/f'shu-osher-p{p}-a{axis}-n{rules["n"]}.npz'
                with np.load(path,allow_pickle=False) as data:
                    config=json.loads(str(data['config']));diag=json.loads(str(data['diagnostics']))
                    q=np.array(data['q']);coeff=np.array(data['coeff']);times=np.array(data['step_times'])
                    xe,ye=np.array(data['x_edges']),np.array(data['y_edges'])
                expected_shape=(rules['n'],2) if axis==0 else (2,rules['n'])
                expected_bounds=[-5.,5.,0.,1.] if axis==0 else [0.,1.,-5.,5.]
                require(config['degree']==p and (config['nx'],config['ny'])==expected_shape
                        and list(config['bounds'])==expected_bounds and config['boundary']=='outflow'
                        and config['limiter']=='tvb' and config.get('gamma',1.4)==1.4,label+' raw configuration mismatch')
                require(config['time']==rules['time'] and abs(diag['final_time']-rules['time'])<=1e-12,
                        label+' raw final-time mismatch')
                require(q.shape==expected_shape+(4,) and coeff.shape==expected_shape+(p+1,p+1,4)
                        and np.all(np.isfinite(q)) and np.all(np.isfinite(coeff)),label+' raw state invalid')
                require(np.array_equal(q,coeff[:,:,0,0,:]),label+' raw average/modal mismatch')
                require(times.ndim==1 and len(times)>=2 and abs(times[0])<=1e-14
                        and abs(times[-1]-rules['time'])<=1e-12 and np.all(np.diff(times)>0)
                        and len(times)-1==diag['steps']==diag['recorded_step_count'],label+' actual step history mismatch')
                require(xe.shape==(expected_shape[0]+1,) and ye.shape==(expected_shape[1]+1,)
                        and np.all(np.diff(xe)>0) and np.all(np.diff(ye)>0)
                        and np.allclose(xe[[0,-1]],expected_bounds[:2],rtol=0,atol=1e-13)
                        and np.allclose(ye[[0,-1]],expected_bounds[2:],rtol=0,atol=1e-13),label+' raw physical edges invalid')
                edges=xe if axis==0 else ye;centers=(edges[:-1]+edges[1:])/2
                require(np.allclose(np.diff(edges),10/rules['n'],atol=1e-13,rtol=0),label+' nonuniform target grid')
                profile=q[...,0].mean(axis=1-axis);expected=remap_density(ref,refedges,edges)
                global_l1=float(np.sum(abs(profile-expected))/np.sum(abs(expected)))
                require(np.isclose(global_l1,row['error_l1'],rtol=2e-11,atol=2e-14),label+' global density metric not bound to raw state')
                measured=resolution_metrics(profile,expected,centers,rules['region_normal_coordinate'])
                failures=[]
                if measured['relative_l1_density']>rules['max_relative_l1_density']:failures.append('ROI relative L1 exceeds '+str(rules['max_relative_l1_density']))
                if measured['demeaned_standard_deviation_ratio']<rules['min_demeaned_standard_deviation_ratio']:failures.append('ROI standard-deviation ratio below '+str(rules['min_demeaned_standard_deviation_ratio']))
                if measured['pearson_correlation']<rules['min_pearson_correlation']:failures.append('ROI Pearson correlation below '+str(rules['min_pearson_correlation']))
                record=dict(p=p,axis=axis,n=rules['n'],time=rules['time'],region=rules['region_normal_coordinate'],
                    global_relative_l1_density=global_l1,metrics=measured,passed=not failures,failures=failures,
                    raw_array_sha256=digest(path))
                report['cases'].append(record)
                report['failures'] += [label+': '+failure for failure in failures]
            except (ValueError,OSError,KeyError,TypeError,IndexError) as exc:
                report['failures'].append(label+': '+str(exc))
        report['diagnostic_checks']=len(report['cases'])
        report['passed']=not report['failures'] and len(report['cases'])==len(required)
    except (ValueError,OSError,KeyError,TypeError,IndexError) as exc:
        report['failures'].append(str(exc))
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign',required=True,type=Path)
    parser.add_argument('--solver',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    report=evaluate_resolution(args.campaign,args.solver)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
    return 0 if report['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
