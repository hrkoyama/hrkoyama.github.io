"""Compare saved diagnostic records across IEEE754 reduction implementations.

Only named *derived output* fields may differ by <=64 double-precision eps
relative. Inputs, coordinates, identities, hashes, verdicts and field sets must
match exactly. This comparison never determines scientific acceptance: the
unchanged scientific evaluator must independently pass before it is called.
"""
import math
import sys

RELATIVE_ROUNDOFF_LIMIT = 64*sys.float_info.epsilon
DERIVED_METRICS = frozenset({
    'relative_l1_density', 'max_absolute_density_difference',
    'demeaned_standard_deviation_ratio', 'pearson_correlation',
    'candidate_mean', 'reference_mean', 'candidate_standard_deviation',
    'reference_standard_deviation'})


def _derived(path):
    return (len(path) == 3 and path[0] == 'cases' and isinstance(path[1], int)
            and path[2] == 'global_relative_l1_density') or (
        len(path) == 4 and path[0] == 'cases' and isinstance(path[1], int)
        and path[2] == 'metrics' and path[3] in DERIVED_METRICS)


def compare_waveform_records(saved, recomputed):
    changes = []
    compared_outputs = []

    def fail(path, reason):
        raise ValueError('Saved diagnostic record mismatch at '+repr(path)+': '+reason)

    def walk(a, b, path=()):
        if type(a) is not type(b):
            fail(path, 'type changed')
        if isinstance(a, dict):
            if set(a) != set(b):
                fail(path, 'field set changed')
            for key in sorted(a):
                walk(a[key], b[key], path+(key,))
        elif isinstance(a, list):
            if len(a) != len(b):
                fail(path, 'list length changed')
            for i, (x, y) in enumerate(zip(a, b)):
                walk(x, y, path+(i,))
        elif isinstance(a, float):
            if not math.isfinite(a) or not math.isfinite(b):
                fail(path, 'nonfinite float')
            if _derived(path):
                difference = abs(a-b)
                scale = max(abs(a), abs(b))
                relative = difference/scale if scale else 0.
                if relative > RELATIVE_ROUNDOFF_LIMIT:
                    fail(path, 'derived output exceeds64eps relative roundoff limit')
                row = dict(path=list(path), saved=a, recomputed=b,
                           absolute_difference=difference, relative_difference=relative)
                compared_outputs.append(row)
                if a != b:
                    changes.append(row)
            elif a != b:
                fail(path, 'input or non-allowlisted float changed')
        elif a != b:
            fail(path, 'exact value changed')

    walk(saved, recomputed)
    return dict(passed=True, comparison='named-derived-diagnostic-roundoff-only',
                relative_limit=RELATIVE_ROUNDOFF_LIMIT, absolute_floor=0.,
                scientific_thresholds_modified=False, exact_inputs_hashes_ids_and_verdicts=True,
                derived_scalars_compared=len(compared_outputs), changed_scalar_count=len(changes),
                maximum_absolute_difference=max((x['absolute_difference'] for x in compared_outputs), default=0.),
                maximum_relative_difference=max((x['relative_difference'] for x in compared_outputs), default=0.),
                changed_fields=changes)
