"""Independent, frozen acceptance evaluator for the 2D RKDG demonstration.

The evaluator imports no candidate solver. Metrics may be calculated for any
candidate implementing the documented coefficient/output contract. The pinned
criteria are checked before any result can receive a passing verdict.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
from typing import Any

import numpy as np
from numpy.polynomial.legendre import leggauss, legvander

CRITERIA_PATH = Path(__file__).with_name("acceptance.json")
PINNED_CRITERIA_SHA256 = "7219904b7460efa32f1f1ea03b6cd729e9e3b200e7c60643d0cfa08ec866d4af"
_SHA = re.compile(r"^[0-9a-f]{64}$")


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def field_errors(actual, reference, weights=None):
    """Volume-normalized L1/L2 and sampled Linf, without solver imports.

    Pass quadrature weights including cell Jacobians if domains or cells have
    unequal measure. Linf is the maximum on the evaluation points, not a proven
    continuous supremum.
    """
    actual, reference = np.broadcast_arrays(np.asarray(actual, float), np.asarray(reference, float))
    if not np.all(np.isfinite(actual)) or not np.all(np.isfinite(reference)):
        raise ValueError("Error fields must be finite")
    error = np.abs(actual - reference)
    weights = np.ones(error.shape) if weights is None else np.broadcast_to(np.asarray(weights, float), error.shape)
    if not np.all(np.isfinite(weights)) or np.any(weights < 0) or not weights.sum() > 0:
        raise ValueError("Weights must be finite, nonnegative, with positive sum")
    return {"l1": float(np.sum(weights * error) / weights.sum()),
            "l2": float(np.sqrt(np.sum(weights * error**2) / weights.sum())),
            "linf": float(np.max(error))}


def relative_l1(actual, reference, weights=None):
    """L1 difference / L1 reference, with no arbitrary small denominator floor."""
    actual, reference = np.broadcast_arrays(np.asarray(actual, float), np.asarray(reference, float))
    weights = np.ones(actual.shape) if weights is None else np.broadcast_to(np.asarray(weights, float), actual.shape)
    errors = field_errors(actual, reference, weights)
    normalizer = float(np.sum(weights * np.abs(reference)) / weights.sum())
    if normalizer <= 0:
        raise ValueError("Relative L1 needs a nonzero reference")
    return errors["l1"] / normalizer


def modal_density_errors(coefficients, exact, bounds=(0., 1., 0., 1.), time=0., nq=None):
    """Independently reconstruct Legendre Qp modes and integrate density error.

    coefficients axes: nx,ny,i,j,conserved-variable (rho,rho*u,rho*v,E).
    exact(x,y,time) must return conserved states, or exact density of shape x.
    A 2p+4 Gauss rule is the default; this is separate from solver quadrature.
    """
    c = np.asarray(coefficients, float)
    if c.ndim != 5 or c.shape[2] != c.shape[3] or c.shape[-1] != 4:
        raise ValueError("Expected coefficients (nx,ny,p+1,p+1,4)")
    nx, ny, modes, _, _ = c.shape
    nq = 2 * (modes - 1) + 4 if nq is None else nq
    if not isinstance(nq, int) or nq < modes + 1:
        raise ValueError("Evaluation quadrature must exceed polynomial degree")
    z, w = leggauss(nq)
    basis = legvander(z, modes - 1)
    rho = np.einsum("xyij,ai,bj->xyab", c[..., 0], basis, basis, optimize=True)
    xmin, xmax, ymin, ymax = bounds
    x1 = xmin + (np.arange(nx)[:, None] + .5 + .5*z[None, :]) * (xmax-xmin)/nx
    y1 = ymin + (np.arange(ny)[:, None] + .5 + .5*z[None, :]) * (ymax-ymin)/ny
    x = np.broadcast_to(x1[:, None, :, None], rho.shape)
    y = np.broadcast_to(y1[None, :, None, :], rho.shape)
    reference = np.asarray(exact(x, y, time), float)
    if reference.shape == rho.shape + (4,):
        reference = reference[..., 0]
    return field_errors(rho, reference, w[None,None,:,None] * w[None,None,None,:])


def conservative_restrict(reference, target_shape):
    """Uniform-cell average remap using overlap areas, including noninteger ratios.

    Reference and target share their physical bounds. This is not pointwise
    interpolation; it preserves the reference integral to floating precision.
    Any trailing field axes are retained.
    """
    result = np.asarray(reference, float)
    if not np.all(np.isfinite(result)):
        raise ValueError("Reference must be finite")
    if len(target_shape) > result.ndim:
        raise ValueError("Too many target axes")
    for axis, target_n in enumerate(target_shape):
        if not isinstance(target_n, (int,np.integer)) or isinstance(target_n, bool) or target_n < 1:
            raise ValueError("Target counts must be positive integers")
        source_n = result.shape[axis]
        fine = np.linspace(0., 1., source_n + 1)
        coarse = np.linspace(0., 1., int(target_n) + 1)
        overlap = np.maximum(0., np.minimum(coarse[1:,None],fine[None,1:]) - np.maximum(coarse[:-1,None],fine[None,:-1])) * target_n
        result = np.moveaxis(np.tensordot(overlap, result, axes=(1,axis)), 0, axis)
    return result


def conservation_defect(initial_integral, final_integral, integrated_outflow):
    """max_j |Ufinal-Uinitial+outflow| / max(1,|Ui|,|Uf|,|outflow|)."""
    initial, final, outflow = np.broadcast_arrays(np.asarray(initial_integral,float),
                                                  np.asarray(final_integral,float),
                                                  np.asarray(integrated_outflow,float))
    if initial.shape != (4,) or not np.all(np.isfinite([initial,final,outflow])):
        raise ValueError("Finite four-component integrals are required")
    scale = np.maximum.reduce([np.ones(4),np.abs(initial),np.abs(final),np.abs(outflow)])
    return float(np.max(np.abs(final-initial+outflow)/scale))


def _number(value):
    return isinstance(value, (int,float,np.integer,np.floating)) and not isinstance(value,(bool,np.bool_)) and math.isfinite(float(value))


def evaluate_smooth_control(rows, degree=1, criteria_path=CRITERIA_PATH):
    """Apply the SAME smooth criteria to measured deliberately faulty runs.

    Returns rejected=True only for complete, well-formed numerical evidence
    that violates a scientific acceptance condition. Missing runs or malformed
    metadata do not count as successfully detecting an implementation fault.
    """
    path=Path(criteria_path)
    if sha256_file(path)!=PINNED_CRITERIA_SHA256:
        return {"valid_evidence":False,"rejected":False,"reasons":["Frozen criteria hash changed"],"observed_orders":[]}
    rule=json.loads(path.read_text())["smooth"]
    invalid=[];failures=[];observed=[];indexed={}
    if degree not in (1,2,3) or isinstance(degree,bool):
        return {"valid_evidence":False,"rejected":False,"reasons":["Control degree must be 1, 2, or 3"],"observed_orders":[]}
    if not isinstance(rows,list):rows=[];invalid.append("Control smooth evidence must be a list")
    for row in rows:
        if not isinstance(row,dict):invalid.append("Control row must be an object");continue
        n=row.get("n")
        if not isinstance(n,int) or isinstance(n,bool) or n not in rule["levels"] or row.get("p")!=degree:
            invalid.append("Control has an unexpected degree/grid case");continue
        if n in indexed:invalid.append("Control contains duplicate grid level");continue
        indexed[n]=row
        if not _number(row.get("time")) or not math.isclose(row["time"],rule["time"],rel_tol=0.,abs_tol=1e-12):invalid.append("Control has wrong final time")
        if row.get("velocity")!=rule["velocity"]:invalid.append("Control has wrong advection velocity")
        error=row.get("errors",{})
        if not isinstance(error,dict) or any(not _number(error.get(norm)) or error[norm]<=0 for norm in rule["norms"]):invalid.append("Control errors must be finite and positive")
        defect=row.get("conservation_defect")
        if not _number(defect) or defect<0:invalid.append("Control lacks a finite conservation defect")
        elif defect>rule["max_normalized_conservation_defect"]:failures.append(f"Control n={n} conservation defect exceeds fixed limit")
    if set(indexed)!=set(rule["levels"]):invalid.append("Control must contain all four fixed grid levels")
    if invalid:
        return {"valid_evidence":False,"rejected":False,"reasons":invalid,"observed_orders":[]}
    for norm in rule["norms"]:
        error=[indexed[n]["errors"][norm] for n in rule["levels"]]
        values=[math.log(a/b)/math.log(nb/na) for a,b,na,nb in zip(error,error[1:],rule["levels"],rule["levels"][1:])]
        observed.append({"p":degree,"norm":norm,"levels":rule["levels"],"errors":error,"orders":values})
        if rule["all_levels_decrease"] and any(a<=b for a,b in zip(error,error[1:])):failures.append(f"Control {norm} error does not decrease on every level")
        minimum=degree+1-rule["order_margin"][norm]
        if min(values[-rule["order_pairs"]:])<minimum:failures.append(f"Control {norm} observed order below {minimum}")
    return {"valid_evidence":True,"rejected":bool(failures),"reasons":failures,"observed_orders":observed}


def evaluate_metrics(metrics: dict[str, Any], criteria_path=CRITERIA_PATH,
                     expected_solver_sha256=None):
    """Return all failures; missing, duplicate, extra and nonfinite cases fail.

    This does not execute a solver. The campaign runner must bind generated
    metrics to actual source/data hashes and save the raw arrays and commands.
    """
    failures, orders = [], []
    raw = Path(criteria_path).read_bytes()
    criteria_sha = hashlib.sha256(raw).hexdigest()
    if criteria_sha != PINNED_CRITERIA_SHA256:
        return {"passed": False, "failures": ["Frozen acceptance.json hash changed"],
                "criteria_sha256": criteria_sha, "observed_orders": []}
    rules = json.loads(raw)
    if not isinstance(metrics,dict):
        return {"passed":False,"failures":["Metrics must be an object"],"criteria_sha256":criteria_sha,"observed_orders":[]}
    if metrics.get("schema_version") != rules["schema_version"]:
        failures.append("schema_version must be 1")
    if metrics.get("criteria_sha256") != criteria_sha:
        failures.append("metrics criteria_sha256 does not match frozen acceptance.json")
    solver_sha = metrics.get("solver_sha256", "")
    if not isinstance(solver_sha,str) or not _SHA.fullmatch(solver_sha):
        failures.append("solver_sha256 must be a lowercase SHA256 digest")
    if expected_solver_sha256 is not None and solver_sha != expected_solver_sha256:
        failures.append("solver source hash does not match the audited candidate")
    reference_sha = metrics.get("reference_sha256")
    if not isinstance(reference_sha,dict) or not reference_sha or any(not isinstance(v,str) or not _SHA.fullmatch(v) for v in reference_sha.values()):
        failures.append("reference_sha256 must contain independently stored reference SHA256 digests")

    def check_finite(value, path="metrics"):
        if isinstance(value,dict):
            for key, item in value.items(): check_finite(item, path+"."+str(key))
        elif isinstance(value,list):
            for key, item in enumerate(value): check_finite(item, path+"["+str(key)+"]")
        elif isinstance(value,(int,float,np.integer,np.floating)) and not isinstance(value,(bool,np.bool_)) and not math.isfinite(float(value)):
            failures.append(path+" is nonfinite")
    check_finite(metrics)

    def rows_for(section, keys, expected):
        rows = metrics.get(section)
        if not isinstance(rows,list):
            failures.append(section+" must be a list")
            return {}
        indexed = {}
        for row in rows:
            if not isinstance(row,dict):
                failures.append(section+" contains a non-object row"); continue
            key = tuple(row.get(k) for k in keys)
            integer_fields = {"p", "n", "ny", "axis", "factor"}
            if any(k in integer_fields and (not isinstance(row.get(k),(int,np.integer)) or isinstance(row.get(k),(bool,np.bool_))) for k in keys):
                failures.append(section+" case identifiers require integers"); continue
            try:
                if key not in expected:
                    failures.append(section+" unexpected or incomplete case "+str(key)); continue
                if key in indexed:
                    failures.append(section+" duplicate case "+str(key)); continue
                indexed[key] = row
            except TypeError:
                failures.append(section+" malformed case identifier")
        for key in sorted(expected - indexed.keys(),key=str):
            failures.append(section+" missing case "+str(key))
        return indexed

    def num(row, name, label, low=None, high=None, strict_low=False):
        value = row.get(name)
        if not _number(value):
            failures.append(label+" missing/nonfinite numeric "+name); return None
        value=float(value)
        if low is not None and (value <= low if strict_low else value < low):
            failures.append(label+" "+name+" below required lower bound "+str(low))
        if high is not None and value > high:
            failures.append(label+" "+name+" exceeds "+str(high))
        return value

    def at_time(row, expected, label):
        value = num(row,"time",label)
        if value is not None and not math.isclose(value,expected,rel_tol=0.,abs_tol=1e-12):
            failures.append(label+" wrong final time")

    degrees=rules["degrees"]
    smooth_rule=rules["smooth"]
    smooth=rows_for("smooth",("p","n"),{(p,n) for p in degrees for n in smooth_rule["levels"]})
    for (p,n),row in smooth.items():
        label=f"smooth p={p} n={n}"
        at_time(row,smooth_rule["time"],label)
        if row.get("velocity") != smooth_rule["velocity"]: failures.append(label+" wrong advection velocity")
        num(row,"conservation_defect",label,0,smooth_rule["max_normalized_conservation_defect"])
        errors=row.get("errors",{})
        if not isinstance(errors,dict): errors={}
        for norm in smooth_rule["norms"]: num(errors,norm,label,0,strict_low=True)
    for p in degrees:
        levels=smooth_rule["levels"]
        for norm in smooth_rule["norms"]:
            err=[]
            for n in levels:
                item=smooth.get((p,n),{}).get("errors",{})
                err.append(item.get(norm) if isinstance(item,dict) else None)
            if all(_number(e) and e>0 for e in err):
                observed=[math.log(err[i]/err[i+1])/math.log(levels[i+1]/levels[i]) for i in range(len(levels)-1)]
                orders.append({"p":p,"norm":norm,"levels":levels,"errors":err,"orders":observed})
                if smooth_rule["all_levels_decrease"] and any(a<=b for a,b in zip(err,err[1:])):
                    failures.append(f"smooth p={p} {norm} errors do not decrease on every level")
                minimum=p+1-smooth_rule["order_margin"][norm]
                if min(observed[-smooth_rule["order_pairs"]:]) < minimum:
                    failures.append(f"smooth p={p} {norm} observed order below {minimum}")

    dr=rules["directional"]
    directional=rows_for("directional",("problem","p","axis","n"),
                         {(problem,p,axis,n) for problem in dr["problems"] for p in degrees for axis in dr["axes"] for n in dr["levels"]})
    for (problem,p,axis,n),row in directional.items():
        label=f"{problem} p={p} axis={axis} n={n}"
        at_time(row,dr["time"][problem],label)
        if row.get("reference_kind")!=dr["reference_kind"][problem]:failures.append(label+" wrong reference_kind")
        num(row,"error_l1",label,0,dr["max_finest_error_l1"][problem] if n==max(dr["levels"]) else None)
        for metric in ("transverse","axis_difference"):num(row,metric,label,0,dr["max_"+metric])
        num(row,"conservation_defect",label,0,dr["max_normalized_conservation_defect"])
        num(row,"min_density",label,rules["minimum_density"],strict_low=True)
        num(row,"min_pressure",label,rules["minimum_pressure"],strict_low=True)
    for problem in dr["problems"]:
        for p in degrees:
            for axis in dr["axes"]:
                err=[directional.get((problem,p,axis,n),{}).get("error_l1") for n in dr["levels"]]
                if all(_number(e) for e in err) and err[-1]>dr["max_fine_to_coarse_error_ratio"]*err[0]:
                    failures.append(f"{problem} p={p} axis={axis} reference error grows beyond fixed grid-refinement allowance")

    mr=rules["double_mach"]
    dmr=rows_for("double_mach",("p","ny"),{(p,n) for p in degrees for n in mr["levels"]})
    for (p,n),row in dmr.items():
        label=f"double-mach p={p} ny={n}"
        at_time(row,mr["time"],label)
        if row.get("reference_kind")!=mr["reference_kind"]:failures.append(label+" wrong reference_kind")
        num(row,"error_l1",label,0,mr["max_finest_error_l1"] if n==max(mr["levels"]) else None)
        num(row,"reference_grid_change_l1",label,0,mr["max_reference_grid_change_l1"])
        num(row,"conservation_defect",label,0,mr["max_normalized_conservation_defect"])
        num(row,"min_density",label,rules["minimum_density"],strict_low=True)
        num(row,"min_pressure",label,rules["minimum_pressure"],strict_low=True)
    for p in degrees:
        err=[dmr.get((p,n),{}).get("error_l1") for n in mr["levels"]]
        if all(_number(e) for e in err) and err[-1]>mr["max_fine_to_coarse_error_ratio"]*err[0]:
            failures.append(f"double-mach p={p} reference error grows beyond fixed grid-refinement allowance")

    tr=rules["temporal"]
    temporal=rows_for("temporal",("factor",),{(f,) for f in tr["dt_refinement_factors"]})
    temporal_errors=[];dts=[];reference_dts=[]
    for factor in tr["dt_refinement_factors"]:
        row=temporal.get((factor,),{});label=f"temporal factor={factor}"
        if row.get("p")!=tr["degree"] or row.get("n")!=tr["n"]:failures.append(label+" wrong spatial discretization")
        at_time(row,tr["time"],label)
        temporal_errors.append(num(row,"error_l2",label,0,strict_low=True))
        dts.append(num(row,"dt",label,0,strict_low=True))
        reference_dts.append(num(row,"reference_dt",label,0,strict_low=True))
    if all(e is not None for e in temporal_errors):
        ratios=[a/b for a,b in zip(temporal_errors,temporal_errors[1:])]
        if min(ratios)<tr["min_successive_error_ratio"]:failures.append("temporal refinement errors do not show the required fourth-order trend")
    if all(v is not None for v in dts+reference_dts):
        for f,dt,ref in zip(tr["dt_refinement_factors"],dts,reference_dts):
            if not math.isclose(dt*f,dts[0],rel_tol=1e-10,abs_tol=1e-15):failures.append("temporal dt factors are inconsistent")
            if not math.isclose(ref,dts[0]/tr["reference_refinement_factor"],rel_tol=1e-10,abs_tol=1e-15):failures.append("temporal reference_dt is inconsistent")

    controls=rows_for("negative_controls",("name",),{(n,) for n in rules["negative_controls"]["required"]})
    for (name,),row in controls.items():
        control=evaluate_smooth_control(row.get("smooth"),degree=1,criteria_path=criteria_path)
        if not control["valid_evidence"]:failures.append(name+" lacks complete measured smooth evidence: "+"; ".join(control["reasons"]))
        if not control["rejected"]:failures.append(name+" faulty solver was not rejected by fixed smooth criteria")
        if row.get("rejected") is not True:failures.append(name+" faulty solver was not rejected")
        evidence_sha=row.get("evidence_sha256","")
        if not isinstance(evidence_sha,str) or not _SHA.fullmatch(evidence_sha):failures.append(name+" requires its preserved run-evidence SHA256")
        if not isinstance(row.get("reasons"),list) or not row["reasons"] or not all(isinstance(r,str) and r.strip() for r in row["reasons"]):
            failures.append(name+" requires recorded rejection reasons")
    return {"passed":not failures,"failures":failures,"criteria_sha256":criteria_sha,
            "solver_sha256":solver_sha,"observed_orders":orders,
            "case_counts":{k:len(metrics.get(k,[])) if isinstance(metrics.get(k),list) else 0 for k in ("smooth","directional","double_mach","temporal","negative_controls")},
            "scope":rules["scope"]}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("metrics",type=Path)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--solver",type=Path,help="Candidate module used by the recorded campaign; verifies source SHA")
    args=parser.parse_args()
    metrics=json.loads(args.metrics.read_text())
    result=evaluate_metrics(metrics,expected_solver_sha256=sha256_file(args.solver) if args.solver else None)
    output=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n"
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(output)
    print(output,end="")
    return 0 if result["passed"] else 1


if __name__=="__main__":
    raise SystemExit(main())
