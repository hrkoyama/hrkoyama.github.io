#!/usr/bin/env python3
"""Publishable, versioned RKDG agent kit with explicit known reflection failure.

This new packager leaves the earlier demonstration ZIP and its historical
packager unchanged. It verifies saved results; it does not run a PDE solver.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
RELEASE = '2026-11-23-r1'
BASE_URL = 'https://hrkoyama.github.io'
KIT_URL = BASE_URL+'/numerical-methods-atlas/agent-kits/rkdg2d/'
ARCHIVE_URL = BASE_URL+'/code/rkdg2d/'+RELEASE+'/atlas-rkdg-agent-kit.zip'
SOURCE_SHA = '4ed984a01c42fe9bb657c09c61361b086682d6aa611e9f478bf996c0b29b81d4'
REFLECTION_SHA = 'ab7986e1eaf768f63fb239bf5a8d766d4c4fc5778389bdc42b5eb294594bf18a'
REFLECTION_RUNNER_SHA = 'ae05c5362ee996091a21c553e0a400c9234148e066cb9c37cfe9b0ff98fb462e'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def module(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT/relative)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def verify_reflection():
    """Recompute reflection comparison scalars from all twelve frozen arrays."""
    require(sha(ROOT/'scripts/run_rkdg_reflection.py') == REFLECTION_RUNNER_SHA,
            'Historical reflection runner changed')
    require(sha(ROOT/'validation/rkdg/reflection-acceptance.json') == REFLECTION_SHA,
            'Frozen reflection criteria changed')
    rules = json.loads((ROOT/'validation/rkdg/reflection-acceptance.json').read_text())
    path = ROOT/'outputs/rkdg-2026-11-23/x-reflection/verdict.json'
    record = json.loads(path.read_text())
    require(record['solver_sha256'] == SOURCE_SHA and record['runner_sha256'] == REFLECTION_RUNNER_SHA,
            'Reflection source binding mismatch')
    require(record['criteria_sha256'] == REFLECTION_SHA and len(record['cases']) == 6,
            'Reflection criteria/case binding mismatch')
    reflection = module('_release_reflection', 'scripts/run_rkdg_reflection.py')
    cases, checked = [], set()
    for row in record['cases']:
        key = row['problem'], row['p']
        require(key not in checked, 'Duplicate reflection case')
        checked.add(key)
        arrays = []
        for direction in ('forward', 'reverse'):
            relative = Path(row[direction+'_npz'])
            require(not relative.is_absolute() and '..' not in relative.parts,
                    'Unsafe reflection path')
            array_path = ROOT/relative
            require(sha(array_path) == row[direction+'_npz_sha256'], 'Corrupt reflection array')
            arrays.append(array_path)
        with np.load(arrays[0], allow_pickle=False) as f:
            forward = np.array(f['coeff'])
        with np.load(arrays[1], allow_pickle=False) as f:
            reverse = np.array(f['coeff']); saved_mapped = np.array(f['mapped_coeff'])
            require(str(f['solver_sha256']) == SOURCE_SHA and str(f['criteria_sha256']) == REFLECTION_SHA,
                    'Reverse-array internal source binding mismatch')
            times = np.array(f['step_times'])
        mapped = reflection.reflect_coefficients(reverse)
        require(np.array_equal(mapped, saved_mapped) and np.all(np.isfinite(mapped)),
                'Reverse array mapping/nonfinite error')
        rho, ref = mapped[:, :, 0, 0, 0], forward[:, :, 0, 0, 0]
        measured = dict(scaled_modal_max=reflection.scaled_modal_max(mapped, forward),
                        density_average_relative_l1=float(np.sum(abs(rho-ref))/np.sum(abs(ref))),
                        density_average_scaled_linf=float(np.max(abs(rho-ref))/max(1., np.max(abs(ref)))))
        for field, value in measured.items():
            require(np.isclose(value, row[field], rtol=1e-12, atol=1e-22),
                    'Reflection scalar differs from frozen record: '+field)
        failing = [name for name in ('initial_scaled_modal_max', 'scaled_modal_max',
                   'density_average_relative_l1', 'density_average_scaled_linf',
                   'normalized_boundary_flux_conservation') if row[name] > rules['limits'][name]]
        require(row['passed'] == (not failing) and len(times)-1 == row['steps']
                and np.all(np.diff(times) > 0), 'Reflection verdict/step history mismatch')
        cases.append(dict(problem=key[0], degree=key[1], passed=row['passed'], measured=measured))
    require(checked == {(problem, p) for problem in rules['problems'] for p in (1, 2, 3)},
            'Missing reflection case')
    require(not record['passed'] and sum(c['passed'] for c in cases) == 5
            and [(c['problem'], c['degree']) for c in cases if not c['passed']] == [('shu-osher', 3)],
            'Expected known reflection failure changed; review as a new release')
    return dict(integrity_passed=True, qualification_passed=False, passed_cases=5, total_cases=6,
                baseline_only=True, candidate_sha256=SOURCE_SHA, criteria_sha256=REFLECTION_SHA,
                raw_arrays_checked=12, verdict_sha256=sha(path), cases=cases,
                pde_rerun_by_packager=False)


def build(output, public_assets):
    require(not output.exists(), 'Refusing to overwrite immutable archive')
    legacy = module('_release_legacy_packager', 'scripts/package_rkdg_demo.py')
    files = legacy.prepare_files(final=True)
    files.pop('SHA256SUMS.txt')
    reflection = verify_reflection()

    def add(relative):
        path = ROOT/relative
        require(path.is_file() and not path.is_symlink(), 'Missing/nonregular release file '+str(relative))
        files[str(relative)] = path.read_bytes()

    for relative in ('scripts/package_rkdg_agent_release.py', 'scripts/run_rkdg_smoke.py',
                     'scripts/run_rkdg_reflection.py', 'scripts/plot_rkdg_reflection.py',
                     'scripts/plot_rkdg_forward_reverse.py', 'scripts/plot_rkdg_reflection_reversed.py',
                     'scripts/plot_rkdg_forward_reverse_p.py',
                     'outputs/rkdg-agent-release-2026-11-23/smoke.json'):
        add(relative)
    for path in sorted((ROOT/'outputs/rkdg-2026-11-23/x-reflection').rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add(path.relative_to(ROOT))
    files['README.txt'] = (ROOT/'agent-kits/rkdg2d/README-release.txt').read_bytes()
    files['requirements-verified.txt'] = b'numpy==2.0.2\n'
    files['requirements-tests-verified.txt'] = b'pytest==8.4.2\n'
    state = json.loads(files['BUILD-STATE.json'])
    state.update(kind='versioned-agent-code-and-fixed-test-release', release=RELEASE,
                 overall_all_supplemental_qualifications_passed=False,
                 reflection_supplement=reflection,
                 current_entry='agent-kits/rkdg2d/TESTSET.md',
                 current_entry_en='agent-kits/rkdg2d/TESTSET-en.md')
    files['BUILD-STATE.json'] = (json.dumps(state, ensure_ascii=False, indent=2)+'\n').encode()
    release = dict(schema_version=1, release=RELEASE, kit_url=KIT_URL, archive_url=ARCHIVE_URL,
                   candidate='agent-kits/rkdg2d/generated/rkdg2d.py', candidate_sha256=SOURCE_SHA,
                   original_48_passed=True, waveform_4_passed=True,
                   reflection_6_passed=False, reflection_passed_count=5,
                   reflection_baseline_only=True,
                   smoke_criteria_sha256=sha(ROOT/'validation/rkdg/smoke-acceptance.json'),
                   python_minimum='3.9', tested_python='3.9.6', tested_numpy='2.0.2',
                   license='MIT', history_note='accepted/ and assembly-notes are historical v2; current source is explicitly pinned above')
    files['RELEASE.json'] = (json.dumps(release, ensure_ascii=False, indent=2)+'\n').encode()
    checks = []
    for name, data in sorted(files.items()):
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts, 'Unsafe ZIP member')
        require(not any(part in {'.git', '.venv', 'retreat-poster-2026', 'atlas-search-publisher',
                                 'Downloads', 'node_modules'} for part in path.parts), 'Private package path')
        require(path.suffix.lower() not in {'.pptx', '.ttf', '.otf', '.dylib', '.so'}, 'Forbidden artifact')
        require(path.suffix.lower() != '.pdf' or name.startswith(('outputs/rkdg-2026-11-23/figures-v3/',
                'outputs/rkdg-2026-11-23/x-reflection/figures/')), 'Unexpected PDF')
        checks.append(hashlib.sha256(data).hexdigest()+'  '+name)
    files['SHA256SUMS.txt'] = ('\n'.join(checks)+'\n').encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as stream:
        with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name, data in sorted(files.items()):
                info = zipfile.ZipInfo('atlas-rkdg-agent-kit/'+name, date_time=(2026, 11, 23, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
    release.update(archive_sha256=sha(output), archive_bytes=output.stat().st_size,
                   archive_file_count=len(files), archive_root='atlas-rkdg-agent-kit',
                   checksum_url=ARCHIVE_URL+'.sha256',
                   entry_ja=KIT_URL+'TESTSET.md', entry_en=KIT_URL+'TESTSET-en.md',
                   commands=dict(smoke='python scripts/run_rkdg_smoke.py --output outputs/fresh-smoke.json',
                   saved_original='python validation/rkdg/evaluate.py outputs/rkdg-2026-11-23/accepted-v3/metrics.json --solver agent-kits/rkdg2d/generated/rkdg2d.py --output outputs/saved-verdict.json',
                   saved_waveform='python validation/rkdg/resolution.py --campaign outputs/rkdg-2026-11-23/accepted-v3 --solver agent-kits/rkdg2d/generated/rkdg2d.py --output outputs/saved-resolution-verdict.json'),
                   reflection_supplement=reflection)
    release['archive'] = dict(url=ARCHIVE_URL, sha256=release['archive_sha256'],
                              bytes=release['archive_bytes'], root_directory='atlas-rkdg-agent-kit')
    release['guides'] = {
        'ja': dict(url=KIT_URL+'TESTSET.md', sha256=sha(ROOT/'agent-kits/rkdg2d/TESTSET.md')),
        'en': dict(url=KIT_URL+'TESTSET-en.md', sha256=sha(ROOT/'agent-kits/rkdg2d/TESTSET-en.md'))}
    public_assets.mkdir(parents=True, exist_ok=True)
    for name in ('TESTSET.md', 'TESTSET-en.md'):
        (public_assets/name).write_bytes((ROOT/'agent-kits/rkdg2d'/name).read_bytes())
    (public_assets/'public-manifest.json').write_text(json.dumps(release, ensure_ascii=False, indent=2)+'\n')
    (public_assets/'atlas-rkdg-agent-kit.zip.sha256').write_text(release['archive_sha256']+'  atlas-rkdg-agent-kit.zip\n')
    return release


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'output/code/atlas-rkdg-agent-kit-2026-11-23-r1.zip')
    parser.add_argument('--public-assets', type=Path, default=ROOT/'outputs/rkdg-agent-release-2026-11-23/public-assets')
    parser.add_argument('--verify-only', action='store_true',
                        help='Verify saved evidence integrity only; do not build ZIP or rerun PDEs')
    args = parser.parse_args()
    if args.verify_only:
        legacy = module('_release_verify_legacy', 'scripts/package_rkdg_demo.py')
        result = dict(kind='saved-evidence-integrity-verification', integrity_passed=True,
                      original48_and_waveform4=legacy.verify_final(),
                      reflection_supplement=verify_reflection(), new_pde_runs=0,
                      all_supplemental_qualifications_passed=False)
        print(json.dumps(result, ensure_ascii=False))
        return
    result = build(args.output.resolve(), args.public_assets.resolve())
    print(json.dumps(dict(archive=str(args.output), sha256=result['archive_sha256'],
                          bytes=result['archive_bytes'], file_count=result['archive_file_count'],
                          original48_passed=True, waveform4_passed=True, reflection_passed='5/6',
                          public_assets=str(args.public_assets))))


if __name__ == '__main__':
    main()
